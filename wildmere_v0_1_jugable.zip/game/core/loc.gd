extends Node
## Localizacion: todos los textos visibles pasan por Loc.t(clave). Idiomas: es, en, fr.

signal language_changed

const LANGS := ["es", "en", "fr"]
const LANG_NAMES := {"es": "Español", "en": "English", "fr": "Français"}

const T := {
	"title": {"es": "Wildmere", "en": "Wildmere", "fr": "Wildmere"},
	"subtitle": {"es": "RPG de aventura y mundo abierto", "en": "Open-world adventure RPG", "fr": "RPG d'aventure en monde ouvert"},
	"play": {"es": "Jugar", "en": "Play", "fr": "Jouer"},
	"settings": {"es": "Ajustes", "en": "Settings", "fr": "Réglages"},
	"credits": {"es": "Créditos", "en": "Credits", "fr": "Crédits"},
	"quit": {"es": "Salir", "en": "Quit", "fr": "Quitter"},
	"back": {"es": "Volver", "en": "Back", "fr": "Retour"},
	"language": {"es": "Idioma", "en": "Language", "fr": "Langue"},
	"sound": {"es": "Sonido", "en": "Sound", "fr": "Son"},
	"calibrate": {"es": "Calibrar joystick", "en": "Calibrate joystick", "fr": "Calibrer le joystick"},
	"calib_up": {"es": "Arrastra el dedo hacia ARRIBA y suéltalo", "en": "Drag your finger UP and release", "fr": "Glissez le doigt vers le HAUT puis relâchez"},
	"calib_right": {"es": "Ahora arrástralo hacia la DERECHA", "en": "Now drag it to the RIGHT", "fr": "Maintenant vers la DROITE"},
	"calib_retry": {"es": "No se detectó bien. Hazlo en línea recta", "en": "Not detected. Drag in a straight line", "fr": "Non détecté. Glissez en ligne droite"},
	"calib_done": {"es": "Listo. Ejes invertidos:", "en": "Done. Inverted axes:", "fr": "Terminé. Axes inversés :"},
	"calib_ok": {"es": "Aceptar", "en": "OK", "fr": "OK"},
	"calib_cancel": {"es": "Cancelar", "en": "Cancel", "fr": "Annuler"},
	"test_controls": {"es": "Prueba de controles", "en": "Controls test", "fr": "Test des commandes"},
	"test_hint": {"es": "Mueve el cuadro con el joystick o con WASD / flechas", "en": "Move the square with the joystick or WASD / arrows", "fr": "Déplacez le carré avec le joystick ou WASD / flèches"},
	"test_joy": {"es": "Joystick", "en": "Joystick", "fr": "Joystick"},
	"test_move": {"es": "Movimiento", "en": "Movement", "fr": "Mouvement"},
	"worlds": {"es": "Mundos", "en": "Worlds", "fr": "Mondes"},
	"no_worlds": {"es": "Aún no tienes mundos. ¡Crea uno!", "en": "No worlds yet. Create one!", "fr": "Aucun monde. Créez-en un !"},
	"create_world": {"es": "Crear mundo", "en": "Create world", "fr": "Créer un monde"},
	"next": {"es": "Siguiente", "en": "Next", "fr": "Suivant"},
	"world_name": {"es": "Nombre del mundo", "en": "World name", "fr": "Nom du monde"},
	"seed": {"es": "Semilla (opcional)", "en": "Seed (optional)", "fr": "Graine (facultatif)"},
	"delete_confirm": {"es": "¿Borrar?", "en": "Delete?", "fr": "Supprimer ?"},
	"minutes": {"es": "%d min", "en": "%d min", "fr": "%d min"},
	"default_world": {"es": "Mundo %d", "en": "World %d", "fr": "Monde %d"},
	"max_worlds": {"es": "Límite de mundos alcanzado", "en": "World limit reached", "fr": "Limite de mondes atteinte"},
	"load_error": {"es": "No se pudo leer el guardado", "en": "Could not read the save", "fr": "Sauvegarde illisible"},
	"char_title": {"es": "Crea tu personaje", "en": "Create your character", "fr": "Créez votre personnage"},
	"char_name": {"es": "Nombre del personaje", "en": "Character name", "fr": "Nom du personnage"},
	"char_appearance": {"es": "Apariencia", "en": "Appearance", "fr": "Apparence"},
	"char_style": {"es": "Estilo inicial (puedes cambiarlo jugando)", "en": "Starting style (you can change it later)", "fr": "Style de départ (modifiable en jouant)"},
	"enter_world": {"es": "Entrar al mundo", "en": "Enter the world", "fr": "Entrer dans le monde"},
	"style_adventurer": {"es": "Aventurero", "en": "Adventurer", "fr": "Aventurier"},
	"style_warrior": {"es": "Guerrero", "en": "Warrior", "fr": "Guerrier"},
	"style_mage": {"es": "Mago", "en": "Mage", "fr": "Mage"},
	"style_archer": {"es": "Arquero", "en": "Archer", "fr": "Archer"},
	"style_adventurer_desc": {"es": "Sin clase fija: espada, arco y mucha libertad.", "en": "No fixed class: sword, bow and plenty of freedom.", "fr": "Sans classe fixe : épée, arc et grande liberté."},
	"style_warrior_desc": {"es": "Más vida, espada fuerte y escudo.", "en": "More health, strong sword and shield.", "fr": "Plus de vie, épée puissante et bouclier."},
	"style_mage_desc": {"es": "Mucha magia: fuego, hielo y curación. Bastón.", "en": "Lots of magic: fire, ice and healing. Staff.", "fr": "Beaucoup de magie : feu, glace et soin. Bâton."},
	"style_archer_desc": {"es": "Rápido, con arco y muchas flechas.", "en": "Fast, with a bow and plenty of arrows.", "fr": "Rapide, avec un arc et beaucoup de flèches."},
	"credits_creator": {"es": "Creador", "en": "Creator", "fr": "Créateur"},
	"credits_social": {"es": "Plataformas oficiales", "en": "Official platforms", "fr": "Plateformes officielles"},
	"credits_third": {"es": "Recursos de terceros", "en": "Third-party resources", "fr": "Ressources tierces"},
	"credits_note": {"es": "Los créditos se ampliarán con cada recurso que se incorpore.", "en": "Credits will grow with every resource added.", "fr": "Les crédits s'étendront à chaque ressource ajoutée."},
	"tbc": {"es": "por confirmar", "en": "to be confirmed", "fr": "à confirmer"},
	"cred_local": {"es": "Los recursos marcados 'por confirmar' se usan solo en pruebas locales.", "en": "Resources marked 'to be confirmed' are used for local testing only.", "fr": "Les ressources 'à confirmer' servent uniquement aux tests locaux."},
	"hud_hp": {"es": "Vida", "en": "HP", "fr": "Vie"},
	"hud_mp": {"es": "Maná", "en": "MP", "fr": "Mana"},
	"hud_food": {"es": "Hambre", "en": "Food", "fr": "Faim"},
	"hud_gold": {"es": "Oro", "en": "Gold", "fr": "Or"},
	"btn_dash": {"es": "Esquiva", "en": "Dash", "fr": "Esquive"},
	"btn_interact": {"es": "Usar", "en": "Use", "fr": "Agir"},
	"btn_inventory": {"es": "Mochila", "en": "Bag", "fr": "Sac"},
	"pause": {"es": "Pausa", "en": "Paused", "fr": "Pause"},
	"resume": {"es": "Continuar", "en": "Resume", "fr": "Reprendre"},
	"save": {"es": "Guardar", "en": "Save", "fr": "Sauvegarder"},
	"saved": {"es": "Partida guardada", "en": "Game saved", "fr": "Partie sauvegardée"},
	"save_failed": {"es": "Error al guardar", "en": "Save failed", "fr": "Échec de la sauvegarde"},
	"main_menu": {"es": "Menú principal", "en": "Main menu", "fr": "Menu principal"},
	"inv_empty": {"es": "La mochila está vacía", "en": "The bag is empty", "fr": "Le sac est vide"},
	"res_equipped": {"es": "equipado", "en": "equipped", "fr": "équipé"},
	"res_used": {"es": "usado", "en": "used", "fr": "utilisé"},
	"res_learned": {"es": "hechizo aprendido", "en": "spell learned", "fr": "sort appris"},
	"res_already_known": {"es": "ya lo conocías", "en": "already known", "fr": "déjà connu"},
	"spell_fireball": {"es": "Bola de fuego", "en": "Fireball", "fr": "Boule de feu"},
	"spell_ice": {"es": "Lanza de hielo", "en": "Ice spike", "fr": "Pointe de glace"},
	"spell_heal": {"es": "Curación", "en": "Heal", "fr": "Soin"},
	"quest_mushrooms": {"es": "Setas: derrota hongos", "en": "Mushrooms: defeat fungi", "fr": "Champignons : vainquez-les"},
	"quest_new": {"es": "Misión nueva: hongos molestos", "en": "New quest: pesky mushrooms", "fr": "Nouvelle quête : champignons"},
	"quest_done": {"es": "Misión completada: +30 oro", "en": "Quest complete: +30 gold", "fr": "Quête terminée : +30 or"},
	"need_bow": {"es": "No tienes arco", "en": "You have no bow", "fr": "Vous n'avez pas d'arc"},
	"need_arrows": {"es": "No tienes flechas", "en": "No arrows left", "fr": "Plus de flèches"},
	"need_shield": {"es": "No tienes escudo", "en": "You have no shield", "fr": "Vous n'avez pas de bouclier"},
	"no_mana": {"es": "Sin maná", "en": "Not enough mana", "fr": "Pas assez de mana"},
	"nothing_here": {"es": "Aquí no hay nada", "en": "Nothing here", "fr": "Rien ici"},
	"bush_empty": {"es": "Aún no hay frutos", "en": "No fruit yet", "fr": "Pas encore de fruits"},
	"chest_empty": {"es": "El cofre está vacío", "en": "The chest is empty", "fr": "Le coffre est vide"},
	"miniboss_down": {"es": "¡Guardián derrotado!", "en": "Guardian defeated!", "fr": "Gardien vaincu !"},
	"boss_summon": {"es": "¡El demonio invoca ayuda!", "en": "The demon calls for help!", "fr": "Le démon appelle à l'aide !"},
	"boss_win": {"es": "¡Jefe final derrotado!", "en": "Final boss defeated!", "fr": "Boss final vaincu !"},
	"died": {"es": "Has caído...", "en": "You fell...", "fr": "Vous êtes tombé..."},
	"hint_start": {"es": "Explora. El pueblo está al noreste", "en": "Explore. The village is to the northeast", "fr": "Explorez. Le village est au nord-est"},
	"item_sword": {"es": "Espada", "en": "Sword", "fr": "Épée"},
	"item_sword2": {"es": "Espada de guerra", "en": "War sword", "fr": "Épée de guerre"},
	"item_staff": {"es": "Bastón", "en": "Staff", "fr": "Bâton"},
	"item_bow": {"es": "Arco", "en": "Bow", "fr": "Arc"},
	"item_shield": {"es": "Escudo", "en": "Shield", "fr": "Bouclier"},
	"item_arrow": {"es": "Flechas", "en": "Arrows", "fr": "Flèches"},
	"item_potion_hp": {"es": "Poción de vida", "en": "Health potion", "fr": "Potion de vie"},
	"item_potion_mp": {"es": "Poción de maná", "en": "Mana potion", "fr": "Potion de mana"},
	"item_apple": {"es": "Manzana", "en": "Apple", "fr": "Pomme"},
	"item_meat": {"es": "Carne", "en": "Meat", "fr": "Viande"},
	"item_tome_ice": {"es": "Tomo de hielo", "en": "Ice tome", "fr": "Tome de glace"},
	"item_tome_heal": {"es": "Tomo de curación", "en": "Healing tome", "fr": "Tome de soin"},
	"npc_elder": {"es": "Anciano", "en": "Elder", "fr": "Ancien"},
	"npc_healer": {"es": "Curandera", "en": "Healer", "fr": "Guérisseuse"},
	"elder_1": {"es": "Bienvenido, viajero. Este mundo es grande y cambia para cada aventurero.", "en": "Welcome, traveler. This world is vast and changes for every adventurer.", "fr": "Bienvenue, voyageur. Ce monde est vaste et change pour chaque aventurier."},
	"elder_2": {"es": "Unos hongos molestos rondan las tierras salvajes. Derrota a tres y te recompensaré.", "en": "Pesky mushrooms roam the wilds. Defeat three and I will reward you.", "fr": "Des champignons rôdent dans la nature. Vainquez-en trois et je vous récompenserai."},
	"elder_progress": {"es": "Llevas %d de 3 hongos. ¡Sigue así!", "en": "You have beaten %d of 3 mushrooms. Keep going!", "fr": "Vous avez battu %d champignons sur 3. Continuez !"},
	"elder_done": {"es": "¡Lo lograste! Toma oro y pociones de maná por tu ayuda.", "en": "You did it! Take gold and mana potions for your help.", "fr": "Bravo ! Prenez de l'or et des potions de mana."},
	"elder_after": {"es": "Gracias de nuevo. Ahora el mundo es tuyo.", "en": "Thanks again. Now the world is yours.", "fr": "Merci encore. Le monde est à vous."},
	"elder_gate": {"es": "Una puerta oscura se alza al %s, a unos %d pasos. Allí duerme el jefe final.", "en": "A dark gate stands to the %s, about %d steps away. The final boss sleeps there.", "fr": "Une porte sombre se dresse au %s, à environ %d pas. Le boss final y dort."},
	"healer_1": {"es": "Descansa. Tus heridas y tu magia se han recuperado.", "en": "Rest. Your wounds and your magic are restored.", "fr": "Reposez-vous. Vos blessures et votre magie sont restaurées."},
	"dir_e": {"es": "este", "en": "east", "fr": "l'est"},
	"dir_se": {"es": "sureste", "en": "southeast", "fr": "sud-est"},
	"dir_s": {"es": "sur", "en": "south", "fr": "sud"},
	"dir_sw": {"es": "suroeste", "en": "southwest", "fr": "sud-ouest"},
	"dir_w": {"es": "oeste", "en": "west", "fr": "l'ouest"},
	"dir_nw": {"es": "noroeste", "en": "northwest", "fr": "nord-ouest"},
	"dir_n": {"es": "norte", "en": "north", "fr": "nord"},
	"dir_ne": {"es": "noreste", "en": "northeast", "fr": "nord-est"},
}

var lang := "es"


func _ready() -> void:
	lang = str(Settings.data.get("lang", "es"))
	if not LANGS.has(lang):
		lang = "es"


func t(key: String) -> String:
	if not T.has(key):
		return key
	var entry: Dictionary = T[key]
	return str(entry.get(lang, entry.get("en", key)))


func set_language(l: String) -> void:
	if not LANGS.has(l):
		return
	lang = l
	Settings.set_value("lang", l)
	language_changed.emit()


func next_language() -> void:
	set_language(LANGS[(LANGS.find(lang) + 1) % LANGS.size()])
