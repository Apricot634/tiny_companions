extends Node
## Estado de la partida: personaje, inventario, progreso y guardado por mundos (hasta 8).
## Guardado atomico con copia .bak (SaveIO). Cada mundo guarda su semilla, asi el terreno se regenera igual.

signal changed

const SaveIO := preload("res://core/save_io.gd")
const Items := preload("res://data/items.gd")
const Appearances := preload("res://data/appearances.gd")

const MAX_WORLDS := 8
const SAVE_VERSION := 2
const RESPAWN_SECONDS := 900.0
const START_POS := Vector2(8, 8)

var active := false
var current_slot := 0
var world_name := ""
var world_seed := 0
var player_name := "Heroe"
var appearance := 1
var style := "adventurer"
var hp := 100.0
var max_hp := 100.0
var mp := 30.0
var max_mp := 30.0
var hunger := 100.0
var gold := 0
var inventory := {}
var weapon := "sword"
var spells: Array = ["fireball"]
var spell_index := 0
var pos := START_POS
var dimension := "overworld"          # overworld | dungeon:<id> | boss
var return_pos := START_POS
var depleted := {}                    # id -> game_time (criaturas muertas, arbustos recogidos)
var opened := {}                      # cofres abiertos
var quests := {"mushrooms": {"state": 0, "count": 0}}
var boss_defeated := false
var play_seconds := 0.0
var game_time := 0.0
var paused_flag := false
var _emit_t := 0.0
var _autosave_t := 0.0


func slot_path(slot: int, kind: String = "") -> String:
	return "user://wildmere_world_%d%s.json" % [slot, kind]


# ------------------------------------------------------------ creacion
func _free_slot() -> int:
	for s in range(1, MAX_WORLDS + 1):
		if not FileAccess.file_exists(slot_path(s)) and not FileAccess.file_exists(slot_path(s, ".bak")):
			return s
	return 0


func new_world(wname: String, seed_text: String, skin: int, style_id: String, pname: String) -> bool:
	var slot := _free_slot()
	if slot == 0:
		return false
	current_slot = slot
	randomize()
	var t := seed_text.strip_edges()
	if t == "":
		world_seed = randi() % 2000000000
	elif t.is_valid_int():
		world_seed = absi(int(t)) % 2000000000
	else:
		world_seed = absi(t.hash()) % 2000000000
	world_name = wname.strip_edges()
	if world_name == "":
		world_name = "Mundo %d" % slot
	player_name = pname.strip_edges()
	if player_name == "":
		player_name = "Heroe"
	appearance = skin
	style = style_id if Appearances.STYLES.has(style_id) else "adventurer"
	var st: Dictionary = Appearances.STYLES[style]
	max_hp = float(st["hp"])
	max_mp = float(st["mp"])
	hp = max_hp
	mp = max_mp
	hunger = 100.0
	gold = 0
	inventory = {}
	var kit: Dictionary = st["items"]
	for k in kit.keys():
		inventory[k] = int(kit[k])
	weapon = str(st["weapon"])
	spells = (st["spells"] as Array).duplicate()
	spell_index = 0
	pos = START_POS
	return_pos = START_POS
	dimension = "overworld"
	depleted = {}
	opened = {}
	quests = {"mushrooms": {"state": 0, "count": 0}}
	boss_defeated = false
	play_seconds = 0.0
	game_time = 0.0
	active = true
	save_game()
	return true


# ------------------------------------------------------------ inventario
func has_item(id: String) -> bool:
	return int(inventory.get(id, 0)) > 0


func item_count(id: String) -> int:
	return int(inventory.get(id, 0))


func add_item(id: String, n: int = 1) -> void:
	inventory[id] = int(inventory.get(id, 0)) + n
	changed.emit()


func remove_item(id: String, n: int = 1) -> bool:
	if int(inventory.get(id, 0)) < n:
		return false
	inventory[id] = int(inventory[id]) - n
	if int(inventory[id]) <= 0:
		inventory.erase(id)
	changed.emit()
	return true


func heal(amount: float) -> void:
	hp = minf(max_hp, hp + amount)
	changed.emit()


## Usa o equipa un objeto. Devuelve la clave de mensaje para mostrar ("" si no hay).
func use_item(id: String) -> String:
	if not Items.ITEMS.has(id) or not has_item(id):
		return ""
	var it: Dictionary = Items.ITEMS[id]
	match str(it["kind"]):
		"weapon":
			weapon = id
			changed.emit()
			return "equipped"
		"consumable":
			remove_item(id, 1)
			if it.has("heal"):
				hp = minf(max_hp, hp + float(it["heal"]))
			if it.has("mana"):
				mp = minf(max_mp, mp + float(it["mana"]))
			if it.has("food"):
				hunger = minf(100.0, hunger + float(it["food"]))
			changed.emit()
			return "used"
		"tome":
			var sp := str(it["spell"])
			remove_item(id, 1)
			if not spells.has(sp):
				spells.append(sp)
				changed.emit()
				return "learned"
			return "already_known"
	return ""


func is_depleted(id: String) -> bool:
	if not depleted.has(id):
		return false
	if game_time - float(depleted[id]) > RESPAWN_SECONDS:
		depleted.erase(id)
		return false
	return true


func mark_depleted(id: String) -> void:
	depleted[id] = game_time


# ------------------------------------------------------------ bucle
func _process(delta: float) -> void:
	if not active:
		return
	play_seconds += delta
	game_time += delta
	hunger = maxf(0.0, hunger - 0.04 * delta)
	mp = minf(max_mp, mp + 1.6 * delta)
	if hunger <= 0.0:
		hp = maxf(1.0, hp - 0.6 * delta)
	elif hunger > 50.0 and hp > 0.0:
		hp = minf(max_hp, hp + 0.35 * delta)
	_emit_t += delta
	if _emit_t >= 0.2:
		_emit_t = 0.0
		changed.emit()
	_autosave_t += delta
	if _autosave_t >= 45.0:
		_autosave_t = 0.0
		save_game()


# ------------------------------------------------------------ guardado
func to_dict() -> Dictionary:
	return {
		"version": SAVE_VERSION, "saved_unix": Time.get_unix_time_from_system(),
		"world_name": world_name, "seed": world_seed, "player_name": player_name,
		"appearance": appearance, "style": style, "hp": hp, "max_hp": max_hp, "mp": mp, "max_mp": max_mp,
		"hunger": hunger, "gold": gold, "inventory": inventory, "weapon": weapon, "spells": spells,
		"spell_index": spell_index, "pos": [pos.x, pos.y], "return_pos": [return_pos.x, return_pos.y],
		"dimension": dimension, "depleted": depleted, "opened": opened, "quests": quests,
		"boss_defeated": boss_defeated, "play_seconds": play_seconds, "game_time": game_time,
	}


func _read_slot(slot: int) -> Dictionary:
	var d := SaveIO.read_json_safe(slot_path(slot))
	if d.has("seed") and d.has("appearance"):
		return d
	return {}


func list_worlds() -> Array:
	var out: Array = []
	for s in range(1, MAX_WORLDS + 1):
		var d := _read_slot(s)
		if d.is_empty():
			continue
		out.append({"slot": s, "name": str(d.get("world_name", "Mundo %d" % s)),
			"player": str(d.get("player_name", "?")), "style": str(d.get("style", "adventurer")),
			"skin": int(d.get("appearance", 1)), "play_seconds": float(d.get("play_seconds", 0.0))})
	return out


func has_save() -> bool:
	return not list_worlds().is_empty()


func save_game() -> bool:
	if not active or current_slot <= 0:
		return false
	return SaveIO.write_json_atomic(slot_path(current_slot), to_dict())


func load_game(slot: int) -> bool:
	var d := _read_slot(slot)
	if d.is_empty():
		return false
	current_slot = slot
	world_name = str(d.get("world_name", "Mundo"))
	world_seed = int(d["seed"])
	player_name = str(d.get("player_name", "Heroe"))
	appearance = int(d["appearance"])
	style = str(d.get("style", "adventurer"))
	if not Appearances.STYLES.has(style):
		style = "adventurer"
	max_hp = float(d.get("max_hp", 100.0))
	max_mp = float(d.get("max_mp", 30.0))
	hp = clampf(float(d.get("hp", max_hp)), 1.0, max_hp)
	mp = clampf(float(d.get("mp", max_mp)), 0.0, max_mp)
	hunger = clampf(float(d.get("hunger", 100.0)), 0.0, 100.0)
	gold = int(d.get("gold", 0))
	inventory = {}
	var inv: Dictionary = d.get("inventory", {})
	for k in inv.keys():
		if Items.ITEMS.has(str(k)):
			inventory[str(k)] = int(inv[k])
	weapon = str(d.get("weapon", "sword"))
	if not Items.ITEMS.has(weapon):
		weapon = "sword"
	spells = []
	for s in d.get("spells", ["fireball"]):
		spells.append(str(s))
	spell_index = int(d.get("spell_index", 0))
	var pp: Array = d.get("pos", [8.0, 8.0])
	pos = Vector2(float(pp[0]), float(pp[1]))
	var rp: Array = d.get("return_pos", [8.0, 8.0])
	return_pos = Vector2(float(rp[0]), float(rp[1]))
	dimension = str(d.get("dimension", "overworld"))
	depleted = d.get("depleted", {})
	opened = d.get("opened", {})
	quests = d.get("quests", {"mushrooms": {"state": 0, "count": 0}})
	boss_defeated = bool(d.get("boss_defeated", false))
	play_seconds = float(d.get("play_seconds", 0.0))
	game_time = float(d.get("game_time", 0.0))
	active = true
	return true


func delete_world(slot: int) -> void:
	for path in [slot_path(slot), slot_path(slot, ".bak"), slot_path(slot, ".tmp")]:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	if current_slot == slot:
		active = false


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if active:
			save_game()
