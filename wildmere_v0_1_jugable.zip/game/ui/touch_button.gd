extends Control
## Boton tactil circular con multitoque real (se puede mover con el joystick y pulsar a la vez).
## En PC responde al raton. Señales: pressed (al tocar) y released (al soltar).

signal pressed
signal released

var label := ""
var icon: Texture2D = null
var radius := 26.0
var held := false
var cooldown := 0.0               # 0..1, atenuacion mientras recarga
var dim := false                  # true = deshabilitado visualmente
var _idx := -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	custom_minimum_size = Vector2(radius * 2.0, radius * 2.0)
	size = custom_minimum_size


func set_radius(r: float) -> void:
	radius = r
	custom_minimum_size = Vector2(r * 2.0, r * 2.0)
	size = custom_minimum_size
	queue_redraw()


func _local(p: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * p


func _hit(local_p: Vector2) -> bool:
	return local_p.distance_to(Vector2(radius, radius)) <= radius + 8.0


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if DisplayServer.is_touchscreen_available():
		if event is InputEventScreenTouch:
			var lp := _local(event.position)
			if event.pressed and _idx == -1 and _hit(lp):
				_idx = event.index
				_press()
			elif not event.pressed and event.index == _idx:
				_idx = -1
				_release()
	else:
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			var lp := _local(event.position)
			if event.pressed and _idx == -1 and _hit(lp):
				_idx = 99
				_press()
			elif not event.pressed and _idx == 99:
				_idx = -1
				_release()


func _press() -> void:
	held = true
	queue_redraw()
	pressed.emit()


func _release() -> void:
	held = false
	queue_redraw()
	released.emit()


func cancel() -> void:
	if held:
		_idx = -1
		_release()


func _draw() -> void:
	var c := Vector2(radius, radius)
	var fill := Color(0.16, 0.19, 0.3, 0.72)
	if held:
		fill = Color(0.35, 0.4, 0.62, 0.85)
	if dim:
		fill = Color(0.1, 0.1, 0.12, 0.6)
	draw_circle(c, radius, fill)
	draw_arc(c, radius - 1.0, 0.0, TAU, 28, Color(0.94, 0.78, 0.35, 0.9), 2.0)
	if icon != null:
		var sz := radius * 1.15
		draw_texture_rect(icon, Rect2(c - Vector2(sz, sz) / 2.0 - Vector2(0, 4 if label != "" else 0), Vector2(sz, sz)), false)
	if label != "":
		var font := ThemeDB.fallback_font
		var fs := 11
		var w := font.get_string_size(label, HORIZONTAL_ALIGNMENT_CENTER, -1, fs).x
		draw_string(font, Vector2(c.x - w / 2.0, radius * 2.0 - 7.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.95))
	if cooldown > 0.0:
		draw_circle(c, radius - 2.0, Color(0, 0, 0, 0.55 * cooldown))
