extends CanvasLayer
## Interfaz de juego: barras, botones tactiles de combate, inventario, dialogos, pausa y avisos.

signal action_attack
signal action_bow
signal action_spell
signal action_block(is_on: bool)
signal action_dash
signal action_interact
signal action_cycle

const WildTheme := preload("res://ui/wild_theme.gd")
const Joystick := preload("res://ui/virtual_joystick.gd")
const TouchButton := preload("res://ui/touch_button.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")

var world = null
var ui: Control
var joystick
var bars := {}
var name_label: Label
var gold_label: Label
var spell_label: Label
var quest_label: Label
var toast_label: Label
var btns := {}
var interact_btn
var inv_overlay: Control
var inv_grid: GridContainer
var inv_info: Label
var dlg_panel: PanelContainer
var dlg_name: Label
var dlg_text: Label
var pause_overlay: Control
var pause_title: Label
var pause_btns := {}
var volume_label: Label
var fade: ColorRect
var msg_label: Label
var _toast_t := 0.0
var _msg_t := 0.0
var _dlg_lines: Array = []
var _dlg_i := 0
var _dlg_cb: Callable
var dialogue_open := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	ui = Control.new()
	ui.theme = WildTheme.make(11)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	joystick = Joystick.new()
	ui.add_child(joystick)
	_build_status()
	_build_buttons()
	_build_top_buttons()
	_build_toast()
	_build_dialogue()
	_build_inventory()
	_build_pause()
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.resized.connect(_layout)
	Loc.language_changed.connect(_refresh_texts)
	GameState.changed.connect(_refresh)
	_layout()
	_refresh_texts()


# ------------------------------------------------------------ construccion
func _bar(parent: Control, key: String, color: Color) -> void:
	var row := HBoxContainer.new()
	var lbl := Label.new()
	lbl.custom_minimum_size = Vector2(34, 0)
	lbl.add_theme_font_size_override("font_size", 10)
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(96, 9)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.show_percentage = false
	bar.max_value = 100.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(2)
	bar.add_theme_stylebox_override("fill", fill)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.05, 0.06, 0.1, 0.85)
	bg.set_corner_radius_all(2)
	bar.add_theme_stylebox_override("background", bg)
	row.add_child(lbl)
	row.add_child(bar)
	parent.add_child(row)
	bars[key] = {"bar": bar, "label": lbl}


func _build_status() -> void:
	var panel := PanelContainer.new()
	ui.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	panel.add_child(vb)
	name_label = Label.new()
	vb.add_child(name_label)
	_bar(vb, "hp", Color8(220, 70, 70))
	_bar(vb, "mp", Color8(80, 140, 240))
	_bar(vb, "food", Color8(230, 160, 60))
	var row := HBoxContainer.new()
	gold_label = Label.new()
	spell_label = Label.new()
	row.add_child(gold_label)
	row.add_child(spell_label)
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 10)
	quest_label = Label.new()
	quest_label.add_theme_font_size_override("font_size", 10)
	quest_label.add_theme_constant_override("outline_size", 3)
	quest_label.add_theme_color_override("font_outline_color", Color.BLACK)
	quest_label.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	quest_label.position = Vector2(12, 112)
	ui.add_child(quest_label)


func _tb(id: String, label: String, r: float, icon_path: String = "") -> Control:
	var b = TouchButton.new()
	b.label = label
	b.radius = r
	if icon_path != "":
		b.icon = load(icon_path)
	ui.add_child(b)
	b.set_radius(r)
	btns[id] = b
	return b


func _build_buttons() -> void:
	var a = _tb("attack", "", 34.0, "res://assets/items/sword.png")
	a.pressed.connect(func(): action_attack.emit())
	var bw = _tb("bow", "", 24.0, "res://assets/items/bow.png")
	bw.pressed.connect(func(): action_bow.emit())
	var sp = _tb("spell", "", 24.0, "res://assets/items/staff.png")
	sp.pressed.connect(func(): action_spell.emit())
	var sh = _tb("block", "", 24.0, "res://assets/items/shield.png")
	sh.pressed.connect(func(): action_block.emit(true))
	sh.released.connect(func(): action_block.emit(false))
	var dh = _tb("dash", "", 22.0)
	dh.pressed.connect(func(): action_dash.emit())
	var cy = _tb("cycle", "", 16.0)
	cy.pressed.connect(func(): action_cycle.emit())
	interact_btn = _tb("interact", "", 26.0)
	interact_btn.pressed.connect(func(): action_interact.emit())
	interact_btn.visible = false


func _build_top_buttons() -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	ui.add_child(row)
	var inv := Button.new()
	inv.focus_mode = Control.FOCUS_NONE
	inv.custom_minimum_size = Vector2(70, 32)
	inv.pressed.connect(_on_inventory_button)
	var pb := Button.new()
	pb.focus_mode = Control.FOCUS_NONE
	pb.custom_minimum_size = Vector2(36, 32)
	pb.text = "II"
	pb.pressed.connect(_on_pause_button)
	row.add_child(inv)
	row.add_child(pb)
	row.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 10)
	row.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	btns["inv_top"] = inv


func _build_toast() -> void:
	toast_label = Label.new()
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.add_theme_font_size_override("font_size", 13)
	toast_label.add_theme_constant_override("outline_size", 4)
	toast_label.add_theme_color_override("font_outline_color", Color8(30, 24, 10))
	toast_label.add_theme_color_override("font_color", Color.WHITE)
	toast_label.modulate.a = 0.0
	ui.add_child(toast_label)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	toast_label.offset_top = 52
	toast_label.offset_bottom = 74
	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg_label.add_theme_font_size_override("font_size", 22)
	msg_label.add_theme_constant_override("outline_size", 6)
	msg_label.add_theme_color_override("font_outline_color", Color8(30, 24, 10))
	msg_label.add_theme_color_override("font_color", Color8(255, 220, 120))
	msg_label.modulate.a = 0.0
	ui.add_child(msg_label)
	msg_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	msg_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	msg_label.offset_top = -60
	msg_label.offset_bottom = -30


func _build_dialogue() -> void:
	dlg_panel = PanelContainer.new()
	dlg_panel.visible = false
	ui.add_child(dlg_panel)
	var vb := VBoxContainer.new()
	dlg_panel.add_child(vb)
	dlg_name = Label.new()
	dlg_name.add_theme_color_override("font_color", WildTheme.GOLD)
	dlg_text = Label.new()
	dlg_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dlg_text.custom_minimum_size = Vector2(380, 44)
	vb.add_child(dlg_name)
	vb.add_child(dlg_text)
	dlg_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 14)
	dlg_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	dlg_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	var tap := Button.new()
	tap.flat = true
	tap.focus_mode = Control.FOCUS_NONE
	tap.pressed.connect(_advance_dialogue)
	dlg_panel.add_child(tap)
	tap.modulate.a = 0.0


func _build_inventory() -> void:
	inv_overlay = ColorRect.new()
	(inv_overlay as ColorRect).color = Color(0, 0, 0, 0.6)
	inv_overlay.visible = false
	ui.add_child(inv_overlay)
	inv_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	inv_overlay.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	panel.add_child(vb)
	var title := Label.new()
	title.name = "InvTitle"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", WildTheme.GOLD)
	vb.add_child(title)
	inv_grid = GridContainer.new()
	inv_grid.columns = 4
	inv_grid.add_theme_constant_override("h_separation", 6)
	inv_grid.add_theme_constant_override("v_separation", 6)
	vb.add_child(inv_grid)
	inv_info = Label.new()
	inv_info.custom_minimum_size = Vector2(300, 18)
	inv_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(inv_info)
	var close := Button.new()
	close.name = "InvClose"
	close.focus_mode = Control.FOCUS_NONE
	close.custom_minimum_size = Vector2(0, 30)
	close.pressed.connect(close_inventory)
	vb.add_child(close)


func _build_pause() -> void:
	pause_overlay = ColorRect.new()
	(pause_overlay as ColorRect).color = Color(0, 0, 0, 0.6)
	pause_overlay.visible = false
	ui.add_child(pause_overlay)
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	pause_overlay.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 5)
	vb.custom_minimum_size = Vector2(190, 0)
	panel.add_child(vb)
	pause_title = Label.new()
	pause_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_title.add_theme_color_override("font_color", WildTheme.GOLD)
	vb.add_child(pause_title)
	var defs := {"resume": _on_resume, "save": _on_save, "language": _on_language, "calibrate": _on_calibrate, "main_menu": _on_main_menu}
	for id in defs.keys():
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 32)
		b.focus_mode = Control.FOCUS_NONE
		var cb: Callable = defs[id]
		b.pressed.connect(cb)
		vb.add_child(b)
		pause_btns[id] = b
	volume_label = Label.new()
	vb.add_child(volume_label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.1
	slider.value = float(Settings.data["volume"])
	slider.custom_minimum_size = Vector2(0, 20)
	slider.value_changed.connect(_on_volume)
	vb.add_child(slider)


# ------------------------------------------------------------ distribucion
func _layout() -> void:
	var s := ui.size
	var c := Vector2(s.x - 82.0, s.y - 82.0)
	_place("attack", c)
	_place("bow", c + Vector2(-70, 20))
	_place("spell", c + Vector2(-48, -52))
	_place("block", c + Vector2(22, -74))
	_place("dash", c + Vector2(-112, -30))
	_place("cycle", c + Vector2(-86, -88))
	_place("interact", c + Vector2(-22, -126))
	quest_label.position = Vector2(12, 116)


func _place(id: String, center_pos: Vector2) -> void:
	var b = btns[id]
	b.position = center_pos - Vector2(b.radius, b.radius)


# ------------------------------------------------------------ textos y estado
func _refresh_texts() -> void:
	bars["hp"]["label"].text = Loc.t("hud_hp")
	bars["mp"]["label"].text = Loc.t("hud_mp")
	bars["food"]["label"].text = Loc.t("hud_food")
	btns["dash"].label = Loc.t("btn_dash")
	btns["interact"].label = Loc.t("btn_interact")
	btns["inv_top"].text = Loc.t("btn_inventory")
	btns["dash"].queue_redraw()
	btns["interact"].queue_redraw()
	pause_title.text = Loc.t("pause")
	pause_btns["resume"].text = Loc.t("resume")
	pause_btns["save"].text = Loc.t("save")
	pause_btns["language"].text = "%s: %s" % [Loc.t("language"), Loc.LANG_NAMES[Loc.lang]]
	pause_btns["calibrate"].text = Loc.t("calibrate")
	pause_btns["main_menu"].text = Loc.t("main_menu")
	volume_label.text = Loc.t("sound")
	inv_overlay.find_child("InvTitle", true, false).text = Loc.t("btn_inventory")
	inv_overlay.find_child("InvClose", true, false).text = Loc.t("back")
	_refresh()
	_refresh_quest()


func _refresh() -> void:
	if not GameState.active:
		return
	name_label.text = "%s" % GameState.player_name
	(bars["hp"]["bar"] as ProgressBar).value = GameState.hp / maxf(1.0, GameState.max_hp) * 100.0
	(bars["mp"]["bar"] as ProgressBar).value = GameState.mp / maxf(1.0, GameState.max_mp) * 100.0
	(bars["food"]["bar"] as ProgressBar).value = GameState.hunger
	gold_label.text = "%s: %d" % [Loc.t("hud_gold"), GameState.gold]
	var sid := ""
	if not GameState.spells.is_empty():
		sid = str(GameState.spells[GameState.spell_index % GameState.spells.size()])
	spell_label.text = Loc.t("spell_" + sid) if sid != "" else ""
	btns["spell"].dim = (sid == "")
	btns["bow"].dim = not GameState.has_item("bow")
	btns["block"].dim = not GameState.has_item("shield")
	if inv_overlay.visible:
		_rebuild_inventory()
	_refresh_quest()


func _refresh_quest() -> void:
	var q: Dictionary = GameState.quests.get("mushrooms", {"state": 0, "count": 0})
	var st: int = int(q.get("state", 0))
	if st == 1:
		quest_label.text = "%s: %d/3" % [Loc.t("quest_mushrooms"), int(q.get("count", 0))]
	elif st == 2:
		quest_label.text = ""
	else:
		quest_label.text = ""


func process_cooldowns(p) -> void:
	btns["attack"].cooldown = clampf(p.attack_cd / 0.42, 0.0, 1.0)
	btns["bow"].cooldown = clampf(p.bow_cd / 0.55, 0.0, 1.0)
	btns["spell"].cooldown = clampf(p.spell_cd / 1.2, 0.0, 1.0)
	btns["dash"].cooldown = clampf(p.dash_cd / 0.9, 0.0, 1.0)
	for k in ["attack", "bow", "spell", "dash"]:
		btns[k].queue_redraw()


func set_interact(show_btn: bool) -> void:
	interact_btn.visible = show_btn


# ------------------------------------------------------------ avisos
func toast(key: String) -> void:
	toast_label.text = Loc.t(key)
	_toast_t = 2.2


func toast_text(text: String) -> void:
	toast_label.text = text
	_toast_t = 2.2


func big_message(key: String) -> void:
	msg_label.text = Loc.t(key)
	_msg_t = 3.5


func do_fade() -> void:
	fade.color = Color(0, 0, 0, 1)
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 0.0, 0.5)


func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		toast_label.modulate.a = clampf(_toast_t / 0.5, 0.0, 1.0)
	if _msg_t > 0.0:
		_msg_t -= delta
		msg_label.modulate.a = clampf(_msg_t / 0.8, 0.0, 1.0)


# ------------------------------------------------------------ dialogos
func show_dialogue(speaker: String, lines: Array, cb: Callable = Callable()) -> void:
	_dlg_lines = lines
	_dlg_i = 0
	_dlg_cb = cb
	dlg_name.text = speaker
	dlg_panel.visible = true
	dialogue_open = true
	_show_line()


func _show_line() -> void:
	dlg_text.text = str(_dlg_lines[_dlg_i])
	Audio.play("dialog")


func _advance_dialogue() -> void:
	if not dialogue_open:
		return
	_dlg_i += 1
	if _dlg_i >= _dlg_lines.size():
		dlg_panel.visible = false
		dialogue_open = false
		if _dlg_cb.is_valid():
			_dlg_cb.call()
	else:
		_show_line()


# ------------------------------------------------------------ inventario
func _on_inventory_button() -> void:
	Audio.play("open")
	open_inventory()


func open_inventory() -> void:
	if get_tree().paused:
		return
	get_tree().paused = true
	inv_overlay.visible = true
	_rebuild_inventory()


func close_inventory() -> void:
	Audio.play("back")
	inv_overlay.visible = false
	get_tree().paused = false


func _rebuild_inventory() -> void:
	for c in inv_grid.get_children():
		c.queue_free()
	for id in Items.ORDER:
		if not GameState.has_item(id):
			continue
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(66, 50)
		b.icon = load(Items.icon_path(id))
		b.expand_icon = false
		b.text = "x%d" % GameState.item_count(id)
		if id == GameState.weapon:
			b.modulate = Color(1, 0.88, 0.45)
		b.pressed.connect(_on_item_pressed.bind(id))
		inv_grid.add_child(b)
	if inv_grid.get_child_count() == 0:
		inv_info.text = Loc.t("inv_empty")


func _on_item_pressed(id: String) -> void:
	var res := GameState.use_item(id)
	if res != "":
		Audio.play("heal" if res == "used" else "confirm")
		inv_info.text = "%s: %s" % [Loc.t("item_" + id), Loc.t("res_" + res)]
		if world != null:
			world.player.refresh_weapon()
	else:
		inv_info.text = Loc.t("item_" + id)
	_rebuild_inventory()


# ------------------------------------------------------------ pausa
func _on_pause_button() -> void:
	Audio.play("click")
	set_paused(true)


func set_paused(v: bool) -> void:
	if inv_overlay.visible:
		return
	if get_tree().paused == v:
		return
	get_tree().paused = v
	pause_overlay.visible = v
	joystick.reset()
	for k in ["attack", "bow", "spell", "block", "dash", "cycle", "interact"]:
		btns[k].cancel()
	Audio.play("open" if v else "back")
	if v:
		GameState.save_game()


func _on_resume() -> void:
	set_paused(false)


func _on_save() -> void:
	if GameState.save_game():
		Audio.play("confirm")
		toast("saved")
	else:
		Audio.play("error")
		toast("save_failed")


func _on_language() -> void:
	Audio.play("toggle")
	Loc.next_language()


func _on_volume(v: float) -> void:
	Settings.set_value("volume", v)


func _on_calibrate() -> void:
	Audio.play("click")
	var c := Calib.new()
	ui.add_child(c)
	c.setup({"title": Loc.t("calibrate"), "up": Loc.t("calib_up"), "right": Loc.t("calib_right"),
		"retry": Loc.t("calib_retry"), "done": Loc.t("calib_done"), "ok": Loc.t("calib_ok"),
		"cancel": Loc.t("calib_cancel")}, _on_calibrated)


func _on_calibrated(ix: bool, iy: bool) -> void:
	Settings.data["joy_invert_x"] = ix
	Settings.data["joy_invert_y"] = iy
	Settings.save_settings()


func _on_main_menu() -> void:
	GameState.save_game()
	GameState.active = false
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if inv_overlay.visible:
			close_inventory()
		else:
			set_paused(not get_tree().paused)
		get_viewport().set_input_as_handled()
		return
	if get_tree().paused:
		return
	if dialogue_open:
		if event.is_action_pressed("interact") or event.is_action_pressed("act_attack"):
			_advance_dialogue()
		return
	if event.is_action_pressed("act_attack"):
		action_attack.emit()
	elif event.is_action_pressed("act_bow"):
		action_bow.emit()
	elif event.is_action_pressed("act_spell"):
		action_spell.emit()
	elif event.is_action_pressed("act_dash"):
		action_dash.emit()
	elif event.is_action_pressed("act_cycle"):
		action_cycle.emit()
	elif event.is_action_pressed("interact"):
		action_interact.emit()
	elif event.is_action_pressed("inventory"):
		open_inventory()
	if event.is_action_pressed("act_block"):
		action_block.emit(true)
	elif event.is_action_released("act_block"):
		action_block.emit(false)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if inv_overlay.visible:
			close_inventory()
		else:
			set_paused(not get_tree().paused)
