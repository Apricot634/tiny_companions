extends Node
## Prueba automatica. Ejecutar: godot --headless --path . -- --autotest
## Imprime "AUTOTEST OK" o "AUTOTEST FAIL" y termina con codigo 0 / 1.

const SaveIO := preload("res://core/save_io.gd")
const CreditsData := preload("res://core/credits_data.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const T := preload("res://data/tiles.gd")
const Terrain := preload("res://world/terrain.gd")
const DungeonGen := preload("res://world/dungeon_gen.gd")
const Species := preload("res://data/species.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")
const Appearances := preload("res://data/appearances.gd")
const FxData := preload("res://data/fx_data.gd")
const TouchButton := preload("res://ui/touch_button.gd")

var ok := true
var _cal := {"x": false, "y": false}
var _presses := 0


func _check(cond: bool, label: String) -> void:
	if cond:
		print("  ok   ", label)
	else:
		print("  FAIL ", label)
		ok = false


func run() -> void:
	await get_tree().process_frame
	_test_save_io()
	_test_loc()
	_test_assets()
	_test_terrain()
	_test_dungeons()
	_test_game_state()
	await _test_menu()
	await _test_touch_button_and_joystick()
	await _test_world()
	print("AUTOTEST ", "OK" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)


# ------------------------------------------------------------ base
func _test_save_io() -> void:
	var p := "user://autotest_save.json"
	for suffix in ["", ".bak", ".tmp"]:
		if FileAccess.file_exists(p + suffix):
			DirAccess.remove_absolute(p + suffix)
	_check(SaveIO.write_json_atomic(p, {"v": 1}), "guardar v1")
	_check(SaveIO.write_json_atomic(p, {"v": 2}), "guardar v2 (crea copia .bak)")
	var f := FileAccess.open(p, FileAccess.WRITE)
	f.store_string("{esto no es json")
	f.close()
	_check(int(SaveIO.read_json_safe(p).get("v", 0)) == 1, "archivo danado -> recupera copia .bak")


func _scan_loc_keys(dir_path: String, found: Dictionary) -> void:
	var d := DirAccess.open(dir_path)
	if d == null:
		return
	for sub in d.get_directories():
		if sub.begins_with(".") or sub == "assets" or sub == "tests":
			continue
		_scan_loc_keys(dir_path.path_join(sub), found)
	for f in d.get_files():
		if f.ends_with(".gd"):
			var txt := FileAccess.get_file_as_string(dir_path.path_join(f))
			var rx := RegEx.new()
			rx.compile("Loc\\.t\\(\"([a-z_0-9]+)\"\\)")
			for m in rx.search_all(txt):
				found[m.get_string(1)] = true
			var rx2 := RegEx.new()
			rx2.compile("toast\\(\"([a-z_0-9]+)\"\\)")
			for m in rx2.search_all(txt):
				found[m.get_string(1)] = true
			var rx3 := RegEx.new()
			rx3.compile("big_message\\(\"([a-z_0-9]+)\"\\)")
			for m in rx3.search_all(txt):
				found[m.get_string(1)] = true


func _test_loc() -> void:
	var all_ok := true
	for key in Loc.T.keys():
		for l in Loc.LANGS:
			if str(Loc.T[key].get(l, "")) == "":
				print("  falta traduccion: ", key, " ", l)
				all_ok = false
	_check(all_ok, "todas las claves tienen es/en/fr")
	var found := {}
	_scan_loc_keys("res://", found)
	for id in Items.ITEMS.keys():
		found["item_" + str(id)] = true
	for id in Spells.SPELLS.keys():
		found["spell_" + str(id)] = true
	for id in Appearances.STYLE_IDS:
		found["style_" + str(id)] = true
		found["style_%s_desc" % str(id)] = true
	var missing: Array = []
	for k in found.keys():
		if not Loc.T.has(str(k)):
			missing.append(k)
	if not missing.is_empty():
		print("  claves de texto sin definir: ", missing)
	_check(missing.is_empty(), "todo texto usado en el codigo esta definido (%d claves)" % found.size())
	for l in Loc.LANGS:
		Loc.set_language(l)
	Loc.set_language("es")


func _test_assets() -> void:
	var bad: Array = []
	for sid in ["mushroom", "wolf", "boar", "fox", "deer", "bunny", "blood", "demon"]:
		var data := Species.get_species(sid)
		if data.is_empty():
			bad.append(sid)
			continue
		for an in data["anims"].keys():
			var a: Dictionary = data["anims"][an]
			if not ResourceLoader.exists(str(a["tex"])):
				bad.append(str(a["tex"]))
				continue
			var tex: Texture2D = load(str(a["tex"]))
			if tex.get_width() < int(a["n"]) * int(a["fw"]) or tex.get_height() < (int(a["row"]) + 1) * int(a["fh"]):
				bad.append("%s %s fuera de la hoja (%dx%d)" % [sid, an, tex.get_width(), tex.get_height()])
	_check(bad.is_empty(), "especies: texturas y fotogramas dentro de las hojas")
	if not bad.is_empty():
		print("  ", bad)
	var bad2: Array = []
	for id in Items.ITEMS.keys():
		if not ResourceLoader.exists(Items.icon_path(str(id))):
			bad2.append(id)
	for fx in FxData.FX.keys():
		if not ResourceLoader.exists("res://assets/fx/%s.png" % fx):
			bad2.append(fx)
	for s in Appearances.SKINS:
		if not ResourceLoader.exists(Appearances.SHEET % s):
			bad2.append("skin %d" % s)
	_check(bad2.is_empty(), "iconos, efectos y personajes existen")
	if not bad2.is_empty():
		print("  ", bad2)
	var tiles_tex: Texture2D = load(T.ATLAS)
	_check(tiles_tex.get_height() >= 14 * 16 and tiles_tex.get_width() >= 64, "atlas de terreno tiene 14 filas x 4 variantes")


# ------------------------------------------------------------ mundo
func _sample_stats(seed_value: int) -> Dictionary:
	var ter := Terrain.new(seed_value)
	var counts := {}
	var total := 0
	var sig := 0
	for y in range(-120, 121, 4):
		for x in range(-120, 121, 4):
			var t := ter.tile_at(x, y)
			counts[t] = int(counts.get(t, 0)) + 1
			total += 1
			sig = (sig * 31 + t) % 1000000007
	counts["total"] = total
	counts["sig"] = sig
	return counts


func _test_terrain() -> void:
	var a := _sample_stats(12345)
	var a2 := _sample_stats(12345)
	var b := _sample_stats(98765)
	_check(int(a["sig"]) == int(a2["sig"]), "misma semilla = mismo terreno")
	_check(int(a["sig"]) != int(b["sig"]), "semillas distintas = terreno distinto")
	for st in [a, b]:
		var total: float = float(st["total"])
		var water: float = (float(st.get(T.DEEP, 0)) + float(st.get(T.WATER, 0))) / total
		var forest: float = float(st.get(T.FOREST, 0)) / total
		var desert: float = float(st.get(T.DESERT, 0)) / total
		var mountain: float = (float(st.get(T.STONE, 0)) + float(st.get(T.GRAVEL, 0))) / total
		print("  info  agua %.0f%%  bosque %.0f%%  desierto %.0f%%  montana %.0f%%" % [water * 100.0, forest * 100.0, desert * 100.0, mountain * 100.0])
		_check(water > 0.02 and water < 0.8, "biomas: proporcion de agua razonable")
		_check(forest + desert + mountain > 0.05, "biomas: hay mas de un tipo de terreno")
	var ter := Terrain.new(777)
	_check(not T.is_solid(ter.tile_at(0, 0)) and not T.is_solid(ter.tile_at(4, 4)) and not T.is_solid(ter.tile_at(-4, 4)), "la zona de inicio es transitable")
	var v := ter.village_in_cell(Vector2i(0, -1))
	_check(not v.is_empty(), "hay una aldea cerca del inicio")
	var objs := ter.chunk_objects(0, -1)
	var houses := 0
	var npcs := 0
	for o in objs:
		if o["type"] == "house":
			houses += 1
		if o["type"] == "npc":
			npcs += 1
	_check(houses >= 1 and npcs >= 1, "la aldea tiene casas y habitantes (casas %d, npc %d)" % [houses, npcs])
	var g := ter.boss_gate_tile()
	_check(not T.is_solid(ter.tile_at(g.x, g.y)), "la puerta del jefe esta en tierra firme")
	_check(Vector2(g.x, g.y).length() > 60.0, "la puerta del jefe esta lejos del inicio")
	var ter2 := Terrain.new(778)
	_check(ter.boss_gate_tile() != ter2.boss_gate_tile(), "la puerta del jefe cambia entre mundos")
	var creatures := 0
	for cx in range(-3, 4):
		for cy in range(-3, 4):
			creatures += ter.chunk_creatures(cx, cy).size()
	_check(creatures > 5, "hay vida: %d criaturas en 49 chunks" % creatures)


func _test_dungeons() -> void:
	var d1 := DungeonGen.new()
	d1.generate(111, "t1")
	var d2 := DungeonGen.new()
	d2.generate(222, "t2")
	_check(d1.tiles != d2.tiles, "cuevas: semillas distintas = mapas distintos")
	_check(d1.reachable(d1.start, d1.exit_tile), "cueva: la salida es alcanzable")
	var c0: Dictionary = d1.chests[0]
	_check(d1.reachable(d1.start, Vector2i(int(c0["tx"]), int(c0["ty"]))), "cueva: el cofre es alcanzable")
	_check(d1.spawns.size() > 0, "cueva: tiene enemigos")
	var b1 := DungeonGen.new()
	b1.boss_arena()
	var b2 := DungeonGen.new()
	b2.boss_arena()
	_check(b1.tiles == b2.tiles and b1.boss_spawn == b2.boss_spawn, "arena del jefe final: identica siempre")
	_check(b1.reachable(b1.start, b1.boss_spawn), "arena del jefe: el jefe es alcanzable")


func _test_game_state() -> void:
	_check(GameState.new_world("Test A", "42", 3, "mage", "Mara"), "crear mundo")
	var slot := GameState.current_slot
	_check(GameState.has_item("staff") and GameState.spells.size() == 3, "estilo mago: baston y 3 hechizos")
	GameState.hp = 10.0
	GameState.add_item("potion_hp", 1)
	GameState.use_item("potion_hp")
	_check(GameState.hp > 10.0, "usar pocion cura")
	GameState.gold = 77
	GameState.pos = Vector2(100, 50)
	GameState.mark_depleted("x1")
	_check(GameState.save_game(), "guardar partida")
	GameState.gold = 0
	GameState.depleted = {}
	_check(GameState.load_game(slot) and GameState.gold == 77 and GameState.player_name == "Mara", "cargar partida")
	_check(GameState.is_depleted("x1"), "estado de criaturas/objetos se conserva")
	var seed_a := GameState.world_seed
	GameState.new_world("Test B", "42", 1, "warrior", "Ro")
	_check(GameState.world_seed == seed_a, "misma semilla escrita = mismo mundo")
	var slot_b := GameState.current_slot
	_check(slot_b != slot, "mundos en ranuras independientes")
	GameState.delete_world(slot_b)
	GameState.delete_world(slot)
	_check(not FileAccess.file_exists(GameState.slot_path(slot)), "borrar mundo")


# ------------------------------------------------------------ interfaz
func _test_menu() -> void:
	var menu: Control = load("res://scenes/main_menu.tscn").instantiate()
	get_tree().root.add_child(menu)
	await get_tree().process_frame
	_check(menu.screens.size() == 6, "menu: 6 pantallas (principal, mundos, crear, personaje, ajustes, creditos)")
	_check(menu.link_buttons.size() == 5, "creditos: 5 plataformas del creador")
	var urls_ok := true
	for i in 5:
		if str(menu.link_buttons[i].get_meta("url")) != str(CreditsData.LINKS[i]["url"]):
			urls_ok = false
		if menu.link_buttons[i].icon == null:
			urls_ok = false
	_check(urls_ok, "creditos: enlaces e iconos pixel art correctos")
	menu._go("settings")
	_check(menu.screens["settings"].visible and not menu.screens["main"].visible, "navegar a ajustes")
	menu._on_pick_style("mage")
	menu._on_pick_skin(9)
	_check(menu.sel_style == "mage" and menu.sel_skin == 9, "creacion de personaje: apariencia y estilo")
	Loc.set_language("fr")
	_check(menu.style_buttons["mage"].text == "Mage" and menu.style_buttons["warrior"].text == "Guerrier", "menu se traduce al cambiar idioma")
	Loc.set_language("es")
	menu.queue_free()
	await get_tree().process_frame


func _on_pressed() -> void:
	_presses += 1


func _touch_mouse(node: Node, pressed: bool, pos: Vector2) -> void:
	var e := InputEventMouseButton.new()
	e.button_index = MOUSE_BUTTON_LEFT
	e.pressed = pressed
	e.position = pos
	node._input(e)


func _on_cal(ix: bool, iy: bool) -> void:
	_cal["x"] = ix
	_cal["y"] = iy


func _test_touch_button_and_joystick() -> void:
	GameState.new_world("Test C", "", 1, "adventurer", "T")
	var hud = load("res://ui/hud.gd").new()
	get_tree().root.add_child(hud)
	await get_tree().process_frame
	var b = TouchButton.new()
	hud.ui.add_child(b)
	b.set_radius(30.0)
	b.position = Vector2(100, 100)
	b.pressed.connect(_on_pressed)
	await get_tree().process_frame
	_touch_mouse(b, true, b.get_global_transform_with_canvas() * Vector2(30, 30))
	_touch_mouse(b, false, Vector2.ZERO)
	_check(_presses == 1, "boton tactil emite 'pressed' al tocarlo")
	var joy = hud.joystick
	var vp: Vector2 = joy.get_viewport_rect().size
	var o := Vector2(60.0, vp.y - 60.0)
	var e1 := InputEventScreenTouch.new()
	e1.index = 0
	e1.position = o
	e1.pressed = true
	joy._input(e1)
	var e2 := InputEventScreenDrag.new()
	e2.index = 0
	e2.position = o + Vector2(30, 0)
	joy._input(e2)
	_check(Controls.joy.x > 0.5 and absf(Controls.joy.y) < 0.2, "joystick: derecha = X positiva")
	e2.position = o + Vector2(0, -30)
	joy._input(e2)
	_check(Controls.joy.y < -0.5, "joystick: arriba = Y negativa")
	e1.pressed = false
	joy._input(e1)
	_check(Controls.joy == Vector2.ZERO, "joystick: soltar vuelve a cero")
	var c = Calib.new()
	hud.ui.add_child(c)
	c.setup({}, _on_cal)
	c.feed(Vector2(0, 80))
	c.feed(Vector2(-80, 0))
	_check(_cal["y"] == true and _cal["x"] == true, "calibracion detecta ejes invertidos")
	c.queue_free()
	hud.queue_free()
	await get_tree().process_frame
	GameState.delete_world(GameState.current_slot)


func _test_world() -> void:
	GameState.new_world("Test W", "2024", 5, "warrior", "Wren")
	var slot := GameState.current_slot
	GameState.add_item("bow", 1)
	GameState.add_item("arrow", 5)
	var world: Node2D = load("res://scenes/game_world.tscn").instantiate()
	get_tree().root.add_child(world)
	for i in 4:
		await get_tree().process_frame
	_check(world.player != null and world.chunk_view.chunks.size() >= 9, "mundo: jugador y %d chunks cargados" % world.chunk_view.chunks.size())
	_check(not world.chunk_view.is_blocked_px(world.player.position), "el jugador aparece en un lugar libre")
	# movimiento con colision
	var p0: Vector2 = world.player.position
	world.move_entity(world.player, Vector2(10, 0), 4.0)
	_check(world.player.position.x >= p0.x, "movimiento del jugador")
	# criatura y combate cuerpo a cuerpo
	world.player.facing = Vector2.RIGHT
	var wolf = world.spawn_creature({"species": "wolf", "tx": floori(p0.x / 16.0) + 1, "ty": floori(p0.y / 16.0), "id": "test_wolf"})
	wolf.position = world.player.position + Vector2(14, 0)
	var hp0: float = wolf.hp
	world.player.do_attack()
	_check(wolf.hp < hp0, "espada: la criatura recibe dano")
	# arco
	var arrows0 := GameState.item_count("arrow")
	world.player.do_bow()
	_check(GameState.item_count("arrow") == arrows0 - 1, "arco: consume una flecha")
	# hechizos
	var mp0 := GameState.mp
	world.player.do_spell()
	_check(GameState.mp < mp0, "hechizo: consume mana")
	GameState.hp = 20.0
	GameState.spell_index = 2
	GameState.mp = 50.0
	world.player.spell_cd = 0.0
	world.player.do_spell()
	_check(GameState.hp > 20.0, "hechizo de curacion")
	GameState.spell_index = 0
	# escudo
	GameState.add_item("shield", 1)
	world.player.set_block(true)
	_check(world.player.blocking, "escudo: se activa")
	world.player.set_block(false)
	# dano al jugador y muerte
	GameState.hp = 100.0
	world.player.invuln = 0.0
	world.player.take_damage(10.0, world.player.position + Vector2(10, 0))
	_check(GameState.hp < 100.0, "el jugador recibe dano")
	# matar criatura -> botin
	var gold0 := GameState.gold
	wolf.take_damage(9999.0, world.player.position)
	await get_tree().process_frame
	_check(wolf.dead and GameState.is_depleted("test_wolf") and GameState.gold > gold0, "criatura derrotada: botin y estado guardado")
	# dialogo y mision
	world._talk("elder")
	_check(world.hud.dialogue_open, "dialogo con el anciano")
	for i in 5:
		world.hud._advance_dialogue()
	_check(int(GameState.quests["mushrooms"]["state"]) == 1, "mision aceptada al terminar el dialogo")
	# cueva
	var pos_before: Vector2 = world.player.position
	GameState.return_pos = pos_before
	world._change_dimension("dungeon:cave_test")
	for i in 3:
		await get_tree().process_frame
	_check(world.source.finite and GameState.dimension == "dungeon:cave_test", "entrar a una cueva")
	_check(not world.chunk_view.is_blocked_px(world.player.position), "dentro de la cueva el jugador esta en suelo libre")
	var chest: Dictionary = world.source.chests[0]
	world.player.position = Vector2(int(chest["tx"]) * 16 + 8, int(chest["ty"]) * 16 + 16)
	world.chunk_view.load_around(world.player.position, 1)
	await get_tree().process_frame
	var it: Dictionary = world.chunk_view.nearest_interactable(world.player.position, 26.0)
	_check(not it.is_empty() and it["type"] == "chest", "cofre detectado como interactuable")
	var gold1 := GameState.gold
	world.interact()
	_check(GameState.gold > gold1 and GameState.opened.has(str(chest["id"])), "abrir cofre da recompensa")
	world._exit_dimension()
	for i in 3:
		await get_tree().process_frame
	_check(GameState.dimension == "overworld" and not world.source.finite, "salir de la cueva vuelve al mundo")
	# jefe final
	world._change_dimension("boss")
	for i in 3:
		await get_tree().process_frame
	var boss = null
	for c in get_tree().get_nodes_in_group("creatures"):
		if c.species_id == "demon":
			boss = c
	_check(boss != null, "arena del jefe: el jefe final aparece")
	if boss != null:
		boss.take_damage(99999.0, boss.position)
		await get_tree().process_frame
		_check(GameState.boss_defeated, "jefe final derrotado queda registrado")
	# descarga de chunks al alejarse
	world._enter_dimension("overworld", Vector2(8, 8))
	for i in 3:
		await get_tree().process_frame
	var n0: int = world.chunk_view.chunks.size()
	world.player.position = Vector2(8 + 256 * 12, 8)
	for i in 30:
		await get_tree().process_frame
	_check(world.chunk_view.chunks.size() <= 25 and n0 > 0, "chunks lejanos se descargan (%d en memoria)" % world.chunk_view.chunks.size())
	# guardar y cargar con el mundo abierto
	_check(GameState.save_game() and GameState.load_game(slot), "guardar/cargar con el mundo en marcha")
	world.queue_free()
	await get_tree().process_frame
	GameState.delete_world(slot)
