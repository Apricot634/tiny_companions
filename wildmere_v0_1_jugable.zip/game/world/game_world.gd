extends Node2D
## Escena de juego: mundo abierto por chunks, cuevas, arena del jefe final, combate y aldeas.

const Terrain := preload("res://world/terrain.gd")
const DungeonGen := preload("res://world/dungeon_gen.gd")
const ChunkViewScript := preload("res://world/chunk_view.gd")
const PlayerScript := preload("res://entities/player.gd")
const CreatureScript := preload("res://entities/creature.gd")
const FxScript := preload("res://entities/fx_sprite.gd")
const ProjScript := preload("res://entities/projectile.gd")
const HudScript := preload("res://ui/hud.gd")
const Spells := preload("res://data/spells.gd")
const Species := preload("res://data/species.gd")

const DIRS := ["dir_e", "dir_se", "dir_s", "dir_sw", "dir_w", "dir_nw", "dir_n", "dir_ne"]

var terrain
var source
var chunk_view
var entities: Node2D
var player
var cam: Camera2D
var hud
var _respawn_t := -1.0
var _hint_t := 0.0


func _ready() -> void:
	get_tree().paused = false
	if not GameState.active:
		GameState.new_world("Prueba", "", 1, "adventurer", "Heroe")
	terrain = Terrain.new(GameState.world_seed)
	chunk_view = ChunkViewScript.new()
	add_child(chunk_view)
	entities = Node2D.new()
	entities.y_sort_enabled = true
	add_child(entities)
	player = PlayerScript.new()
	player.world = self
	entities.add_child(player)
	cam = Camera2D.new()
	cam.zoom = Vector2(2, 2)
	cam.position = Vector2(0, -8)
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 9.0
	player.add_child(cam)
	cam.make_current()
	hud = HudScript.new()
	hud.world = self
	add_child(hud)
	hud.action_attack.connect(player.do_attack)
	hud.action_bow.connect(player.do_bow)
	hud.action_spell.connect(player.do_spell)
	hud.action_block.connect(player.set_block)
	hud.action_dash.connect(player.do_dash)
	hud.action_interact.connect(interact)
	hud.action_cycle.connect(cycle_spell)
	var dim: String = GameState.dimension
	var p: Vector2 = GameState.pos
	if dim != "overworld" and dim != "boss" and not dim.begins_with("dungeon:"):
		dim = "overworld"
	_enter_dimension(dim, p)
	hud.toast("hint_start")


# ------------------------------------------------------------ dimensiones
func _dungeon_seed(id: String) -> int:
	return absi(id.hash() ^ GameState.world_seed) % 2000000000


func _enter_dimension(dim: String, pos_px: Vector2) -> void:
	chunk_view.clear_all()
	for c in entities.get_children():
		if c != player:
			c.queue_free()
	GameState.dimension = dim
	if dim == "overworld":
		source = terrain
	elif dim == "boss":
		var b = DungeonGen.new()
		b.boss_arena()
		source = b
	else:
		var d = DungeonGen.new()
		var id := dim.substr(8)
		d.generate(_dungeon_seed(id), id)
		source = d
	chunk_view.setup(source, entities, self)
	var p := pos_px
	if source.finite and (dim == "boss" or not _walkable_px(p)):
		p = source.start_pos()
	if dim == "overworld":
		p = _safe_pos(p)
	player.position = p
	GameState.pos = p
	if source.finite:
		cam.limit_left = 0
		cam.limit_top = 0
		cam.limit_right = source.w * 16
		cam.limit_bottom = source.h * 16
	else:
		cam.limit_left = -10000000
		cam.limit_top = -10000000
		cam.limit_right = 10000000
		cam.limit_bottom = 10000000
	chunk_view.load_around(p, 1)
	cam.reset_smoothing()
	hud.do_fade()


func _walkable_px(p: Vector2) -> bool:
	return not chunk_view.is_blocked_px(p)


## Evita aparecer dentro de agua, rocas u objetos.
func _safe_pos(p: Vector2) -> Vector2:
	chunk_view.load_around(p, 1)
	if _walkable_px(p) and _walkable_px(p + Vector2(4, 0)) and _walkable_px(p + Vector2(-4, 0)):
		return p
	for r in range(1, 30):
		for k in 8:
			var a := k * PI / 4.0
			var q := p + Vector2(cos(a), sin(a)) * r * 8.0
			if _walkable_px(q) and _walkable_px(q + Vector2(4, 0)) and _walkable_px(q + Vector2(-4, 0)):
				return q
	return p


func _change_dimension(dim: String) -> void:
	hud.toast_text("")
	var start_pos := Vector2.ZERO
	_enter_dimension(dim, start_pos)
	GameState.save_game()


func _exit_dimension() -> void:
	_enter_dimension("overworld", GameState.return_pos)
	GameState.save_game()


# ------------------------------------------------------------ bucle
func _process(delta: float) -> void:
	chunk_view.update(player.position)
	hud.process_cooldowns(player)
	_hint_t -= delta
	if _hint_t <= 0.0:
		_hint_t = 0.15
		var it: Dictionary = chunk_view.nearest_interactable(player.position, 26.0)
		hud.set_interact(not it.is_empty() and not hud.dialogue_open)
	if _respawn_t >= 0.0:
		_respawn_t -= delta
		if _respawn_t < 0.0:
			_respawn()


func input_locked() -> bool:
	return hud.dialogue_open or _respawn_t >= 0.0


func player_dead() -> bool:
	return player.dead


# ------------------------------------------------------------ movimiento y consultas
func move_entity(e: Node2D, delta_v: Vector2, r: float) -> void:
	var p := e.position
	var nx := Vector2(p.x + delta_v.x, p.y)
	if _can_stand(nx, r):
		p = nx
	var ny := Vector2(p.x, p.y + delta_v.y)
	if _can_stand(ny, r):
		p = ny
	e.position = p


func _can_stand(p: Vector2, r: float) -> bool:
	return not (chunk_view.is_blocked_px(p) or chunk_view.is_blocked_px(p + Vector2(r, 0)) \
		or chunk_view.is_blocked_px(p + Vector2(-r, 0)) or chunk_view.is_blocked_px(p + Vector2(0, -r * 0.5)))


func creature_at(p: Vector2, r: float):
	for c in get_tree().get_nodes_in_group("creatures"):
		if c.body_center().distance_to(p) < r + c.radius:
			return c
	return null


func creatures_in_cone(origin: Vector2, dir: Vector2, reach: float) -> Array:
	var out: Array = []
	for c in get_tree().get_nodes_in_group("creatures"):
		var to: Vector2 = c.position - origin
		var d := to.length()
		if d <= reach + c.radius and (d < 12.0 or to.normalized().dot(dir) > 0.25):
			out.append(c)
	return out


func area_damage(center: Vector2, r: float, dmg: float) -> void:
	for c in get_tree().get_nodes_in_group("creatures"):
		if c.body_center().distance_to(center) <= r + c.radius:
			c.take_damage(dmg, center, 80.0)


func damage_player(amount: float, from_pos: Vector2) -> void:
	player.take_damage(amount, from_pos)


# ------------------------------------------------------------ creacion de entidades
func spawn_creature(c: Dictionary) -> Node2D:
	var sid := str(c["species"])
	if Species.get_species(sid).is_empty():
		return null
	var cr = CreatureScript.new()
	cr.setup(sid, str(c["id"]), self)
	cr.position = Vector2(int(c["tx"]) * 16 + 8, int(c["ty"]) * 16 + 12)
	entities.add_child(cr)
	return cr


func spawn_fx(id: String, pos: Vector2, rot: float = 0.0, scl: float = 1.0, loop_seconds: float = -1.0) -> Node:
	var f = FxScript.new()
	f.setup(id, pos, rot, scl, loop_seconds)
	f.z_index = 4
	entities.add_child(f)
	return f


func spawn_projectile(kind: String, pos: Vector2, dir: Vector2, dmg: float, radius: float = 26.0) -> void:
	var p = ProjScript.new()
	p.world = self
	p.kind = kind
	p.position = pos
	p.dir = dir.normalized()
	p.dmg = dmg
	p.radius = radius
	p.speed = 240.0 if kind == "arrow" else 190.0
	entities.add_child(p)


# ------------------------------------------------------------ eventos
func on_creature_killed(c) -> void:
	GameState.mark_depleted(c.cid)
	var drops: Dictionary = c.data.get("drops", {})
	var got_gold := 0
	for k in drops.keys():
		if str(k) == "gold":
			got_gold = int(drops[k])
			GameState.gold += got_gold
		elif randf() < float(drops[k]):
			GameState.add_item(str(k), 1)
	if got_gold > 0:
		hud.toast_text("+%d %s" % [got_gold, Loc.t("hud_gold")])
	if c.species_id == "mushroom":
		var q: Dictionary = GameState.quests["mushrooms"]
		if int(q["state"]) == 1:
			q["count"] = mini(3, int(q["count"]) + 1)
	if c.species_id == "demon":
		GameState.boss_defeated = true
		hud.big_message("boss_win")
		spawn_fx("big_explosion", c.position, 0.0, 1.0)
		Audio.play("death")
	elif bool(c.data.get("mini_boss", false)):
		hud.toast("miniboss_down")
	GameState.changed.emit()


func on_player_died() -> void:
	hud.big_message("died")
	Audio.play("death")
	_respawn_t = 2.6


func _respawn() -> void:
	GameState.hp = GameState.max_hp * 0.5
	GameState.hunger = maxf(GameState.hunger, 40.0)
	GameState.gold = GameState.gold / 2
	player.dead = false
	player.sprite.modulate = Color.WHITE
	_enter_dimension("overworld", Vector2(232, -120))
	GameState.save_game()


func cycle_spell() -> void:
	if GameState.spells.size() <= 1:
		return
	GameState.spell_index = (GameState.spell_index + 1) % GameState.spells.size()
	Audio.play("toggle")
	GameState.changed.emit()
	hud.toast("spell_" + str(GameState.spells[GameState.spell_index]))


# ------------------------------------------------------------ interacciones
func interact() -> void:
	if hud.dialogue_open or input_locked():
		return
	var it: Dictionary = chunk_view.nearest_interactable(player.position, 26.0)
	if it.is_empty():
		hud.toast("nothing_here")
		return
	match str(it["type"]):
		"npc":
			_talk(str(it["role"]))
		"cave":
			GameState.return_pos = it["pos"]
			Audio.play("open")
			_change_dimension("dungeon:" + str(it["id"]))
		"boss_gate":
			GameState.return_pos = it["pos"]
			Audio.play("open")
			_change_dimension("boss")
		"exit":
			Audio.play("back")
			_exit_dimension()
		"chest":
			_open_chest(it)
		"shrub":
			_gather(it)


func _gather(it: Dictionary) -> void:
	var id := str(it["id"])
	if GameState.is_depleted(id):
		hud.toast("bush_empty")
		return
	GameState.mark_depleted(id)
	var n := randi_range(1, 3)
	GameState.add_item("apple", n)
	var fruit: Node = (it["node"] as Node).get_node_or_null("Fruit")
	if fruit != null:
		fruit.visible = false
	hud.toast_text("+%d %s" % [n, Loc.t("item_apple")])
	Audio.play("collect")


func _open_chest(it: Dictionary) -> void:
	var id := str(it["id"])
	if GameState.opened.has(id):
		hud.toast("chest_empty")
		return
	GameState.opened[id] = true
	var node = it["node"]
	if node != null:
		(node as CanvasItem).modulate = Color(0.5, 0.5, 0.5, 0.8)
	var h := absi(id.hash())
	var gold := 15 + h % 40
	GameState.gold += gold
	var extra := "potion_hp"
	if not GameState.spells.has("ice"):
		extra = "tome_ice"
	elif not GameState.spells.has("heal"):
		extra = "tome_heal"
	elif h % 2 == 0:
		extra = "potion_mp"
	GameState.add_item(extra, 1)
	GameState.add_item("arrow", 8)
	hud.toast_text("+%d %s, %s, +8 %s" % [gold, Loc.t("hud_gold"), Loc.t("item_" + extra), Loc.t("item_arrow")])
	Audio.play("pickup")


func _gate_hint() -> String:
	var g: Vector2i = terrain.boss_gate_tile()
	var v := Vector2(g.x, g.y)
	var idx := posmod(roundi(v.angle() / (PI / 4.0)), 8)
	return Loc.t("elder_gate") % [Loc.t(DIRS[idx]), int(roundf(v.length() / 10.0)) * 10]


func _talk(role: String) -> void:
	Audio.play("dialog")
	if role == "healer":
		GameState.hp = GameState.max_hp
		GameState.mp = GameState.max_mp
		GameState.changed.emit()
		spawn_fx("holy_heal", player.position, 0.0, 0.6)
		hud.show_dialogue(Loc.t("npc_healer"), [Loc.t("healer_1")])
		return
	var q: Dictionary = GameState.quests["mushrooms"]
	var st := int(q["state"])
	var lines: Array = []
	var cb := Callable()
	if st == 0:
		lines = [Loc.t("elder_1"), Loc.t("elder_2"), _gate_hint()]
		cb = _accept_quest
	elif st == 1:
		if int(q["count"]) >= 3:
			lines = [Loc.t("elder_done")]
			cb = _finish_quest
		else:
			lines = [Loc.t("elder_progress") % int(q["count"])]
	else:
		lines = [Loc.t("elder_after"), _gate_hint()]
	hud.show_dialogue(Loc.t("npc_elder"), lines, cb)


func _accept_quest() -> void:
	GameState.quests["mushrooms"]["state"] = 1
	hud.toast("quest_new")
	GameState.changed.emit()


func _finish_quest() -> void:
	GameState.quests["mushrooms"]["state"] = 2
	GameState.gold += 30
	GameState.add_item("potion_mp", 2)
	hud.toast("quest_done")
	Audio.play("pickup")
	GameState.changed.emit()
