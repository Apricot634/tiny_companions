extends Node2D
## Carga y descarga de chunks alrededor del jugador (sistema de sectores).
## Cada chunk = CHUNK x CHUNK tiles. Se dibuja como una sola textura (sin un nodo por tile), y sus
## objetos y criaturas se crean al cargarlo y se liberan al descargarlo. Solo existe en memoria lo cercano.

const T := preload("res://data/tiles.gd")
const NpcScript := preload("res://entities/npc.gd")
const CHUNK := 16
const PX := 256

var source = null                 # Terrain o DungeonGen (misma interfaz)
var entities: Node2D
var world = null                  # GameWorld (para crear criaturas)
var radius := 2
var chunks := {}                  # Vector2i -> {sprite, nodes, blocked, tiles}
var blocked := {}                 # Vector2i(tile) -> cantidad de bloqueos
var interactables: Array = []     # [{type, pos, id, node, role, key}]
var _atlas: Image = null
var _tex_cache := {}


func setup(src, entities_node: Node2D, world_ref) -> void:
	source = src
	entities = entities_node
	world = world_ref
	if _atlas == null:
		var tex: Texture2D = load(T.ATLAS)
		_atlas = tex.get_image()
		if _atlas.is_compressed():
			_atlas.decompress()
		_atlas.convert(Image.FORMAT_RGBA8)


func clear_all() -> void:
	for key in chunks.keys():
		_unload_chunk(key)
	chunks.clear()
	blocked.clear()
	interactables.clear()


func _tex(path: String) -> Texture2D:
	if not _tex_cache.has(path):
		_tex_cache[path] = load(path)
	return _tex_cache[path]


func chunk_of(px: Vector2) -> Vector2i:
	return Vector2i(floori(px.x / PX), floori(px.y / PX))


func _in_bounds(key: Vector2i) -> bool:
	if not source.finite:
		return true
	var x0: int = key.x * CHUNK
	var y0: int = key.y * CHUNK
	return x0 < source.w and y0 < source.h and x0 + CHUNK > 0 and y0 + CHUNK > 0


## Carga todo lo cercano de golpe (inicio de partida o cambio de dimension).
func load_around(center_px: Vector2, rad: int = 1) -> void:
	var c := chunk_of(center_px)
	for dy in range(-rad, rad + 1):
		for dx in range(-rad, rad + 1):
			var key := Vector2i(c.x + dx, c.y + dy)
			if not chunks.has(key) and _in_bounds(key):
				_load_chunk(key)


## Llamar cada fotograma: descarga lo lejano y carga como maximo un chunk nuevo.
func update(center_px: Vector2) -> void:
	var c := chunk_of(center_px)
	for key in chunks.keys():
		if absi(key.x - c.x) > radius + 1 or absi(key.y - c.y) > radius + 1:
			_unload_chunk(key)
			chunks.erase(key)
	var best := Vector2i.ZERO
	var best_d := 9999
	var found := false
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			var key := Vector2i(c.x + dx, c.y + dy)
			if chunks.has(key) or not _in_bounds(key):
				continue
			var d := absi(dx) + absi(dy)
			if d < best_d:
				best_d = d
				best = key
				found = true
	if found:
		_load_chunk(best)


# ------------------------------------------------------------ tiles
func tile_cached(tx: int, ty: int) -> int:
	var key := Vector2i(floori(float(tx) / CHUNK), floori(float(ty) / CHUNK))
	if chunks.has(key):
		var tiles: PackedByteArray = chunks[key]["tiles"]
		var lx := tx - key.x * CHUNK
		var ly := ty - key.y * CHUNK
		return tiles[ly * CHUNK + lx]
	return source.tile_at(tx, ty)


func is_blocked_tile(tx: int, ty: int) -> bool:
	return T.is_solid(tile_cached(tx, ty)) or blocked.has(Vector2i(tx, ty))


func is_blocked_px(p: Vector2) -> bool:
	return is_blocked_tile(floori(p.x / 16.0), floori(p.y / 16.0))


# ------------------------------------------------------------ carga / descarga
func _load_chunk(key: Vector2i) -> void:
	var img := Image.create(PX, PX, false, Image.FORMAT_RGBA8)
	var tiles := PackedByteArray()
	tiles.resize(CHUNK * CHUNK)
	for ly in CHUNK:
		for lx in CHUNK:
			var tx: int = key.x * CHUNK + lx
			var ty: int = key.y * CHUNK + ly
			var tid: int = source.tile_at(tx, ty)
			tiles[ly * CHUNK + lx] = tid
			var variant: int = absi(tx * 73 + ty * 31 + tx * ty) % 4
			img.blit_rect(_atlas, Rect2i(variant * 16, tid * 16, 16, 16), Vector2i(lx * 16, ly * 16))
	var spr := Sprite2D.new()
	spr.texture = ImageTexture.create_from_image(img)
	spr.centered = false
	spr.position = Vector2(key.x * PX, key.y * PX)
	spr.z_index = -10
	add_child(spr)
	var entry := {"sprite": spr, "nodes": [], "blocked": [], "tiles": tiles}
	chunks[key] = entry
	for o in source.chunk_objects(key.x, key.y):
		_spawn_object(key, entry, o)
	for c in source.chunk_creatures(key.x, key.y):
		if world != null and not GameState.is_depleted(str(c["id"])):
			var node: Node2D = world.spawn_creature(c)
			if node != null:
				entry["nodes"].append(node)


func _unload_chunk(key: Vector2i) -> void:
	var entry: Dictionary = chunks[key]
	(entry["sprite"] as Sprite2D).queue_free()
	for n in entry["nodes"]:
		if is_instance_valid(n):
			n.queue_free()
	for t in entry["blocked"]:
		var cnt: int = int(blocked.get(t, 0)) - 1
		if cnt <= 0:
			blocked.erase(t)
		else:
			blocked[t] = cnt
	var keep: Array = []
	for it in interactables:
		if it["key"] != key:
			keep.append(it)
	interactables = keep


func _block(entry: Dictionary, tx: int, ty: int) -> void:
	var t := Vector2i(tx, ty)
	blocked[t] = int(blocked.get(t, 0)) + 1
	entry["blocked"].append(t)


func _sprite(path: String, pos: Vector2, foot: bool = true) -> Sprite2D:
	var s := Sprite2D.new()
	var tex := _tex(path)
	s.texture = tex
	s.centered = false
	if foot:
		s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height() + 3.0)
	s.position = pos
	entities.add_child(s)
	return s


func _spawn_object(key: Vector2i, entry: Dictionary, o: Dictionary) -> void:
	var tx: int = int(o["tx"])
	var ty: int = int(o["ty"])
	var foot := Vector2(tx * 16 + 8, ty * 16 + 15)
	var typ := str(o["type"])
	var variant: int = int(o.get("variant", 0))
	var node: Node2D = null
	match typ:
		"tree":
			node = _sprite("res://assets/props/tree%d.png" % (variant + 1), foot)
			_block(entry, tx, ty)
		"shrub":
			node = _sprite("res://assets/props/shrub%d.png" % (variant + 1), foot)
			var fruit := Sprite2D.new()
			fruit.texture = _tex("res://assets/items/apple.png")
			fruit.position = Vector2(-8, -44)
			fruit.name = "Fruit"
			fruit.visible = not GameState.is_depleted(str(o["id"]))
			node.add_child(fruit)
			_block(entry, tx, ty)
			interactables.append({"type": "shrub", "pos": foot, "id": str(o["id"]), "node": node, "key": key, "role": ""})
		"rock":
			node = _sprite("res://assets/props/rock.png", foot)
			_block(entry, tx, ty)
		"cactus":
			node = _sprite("res://assets/props/cactus.png", foot)
			_block(entry, tx, ty)
		"house":
			node = _sprite("res://assets/houses/house%d.png" % (variant + 1), foot)
			for hx in range(tx - 2, tx + 3):
				for hy in range(ty - 2, ty + 1):
					_block(entry, hx, hy)
		"npc":
			var npc: Node2D = NpcScript.new()
			npc.role = str(o.get("role", "elder"))
			npc.position = foot
			entities.add_child(npc)
			node = npc
			_block(entry, tx, ty)
			interactables.append({"type": "npc", "pos": foot, "id": str(o["id"]), "node": npc, "key": key, "role": npc.role})
		"cave":
			node = _sprite("res://assets/props/cave.png", foot)
			_block(entry, tx, ty)
			_block(entry, tx - 1, ty)
			interactables.append({"type": "cave", "pos": foot + Vector2(0, 8), "id": str(o["id"]), "node": node, "key": key, "role": ""})
		"boss_gate":
			node = _sprite("res://assets/props/boss_gate.png", foot)
			_block(entry, tx, ty)
			interactables.append({"type": "boss_gate", "pos": foot + Vector2(0, 8), "id": "boss_gate", "node": node, "key": key, "role": ""})
		"chest":
			node = _sprite("res://assets/props/chest.png", foot)
			_block(entry, tx, ty)
			if GameState.opened.has(str(o["id"])):
				node.modulate = Color(0.5, 0.5, 0.5, 0.8)
			interactables.append({"type": "chest", "pos": foot, "id": str(o["id"]), "node": node, "key": key, "role": ""})
		"crystal":
			node = _sprite("res://assets/props/crystal.png", foot)
		"exit":
			interactables.append({"type": "exit", "pos": Vector2(tx * 16 + 8, ty * 16 + 12), "id": "exit", "node": null, "key": key, "role": ""})
	if node != null:
		entry["nodes"].append(node)


func nearest_interactable(pos: Vector2, max_dist: float) -> Dictionary:
	var best := {}
	var best_d := max_dist
	for it in interactables:
		var d: float = pos.distance_to(it["pos"])
		if d < best_d:
			best_d = d
			best = it
	return best
