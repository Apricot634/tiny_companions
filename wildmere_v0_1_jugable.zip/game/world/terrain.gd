extends RefCounted
## Generador del mundo abierto. Todo es determinista a partir de la semilla del mundo:
## misma semilla = mismo mundo; semillas distintas = mundos distintos.
## Interfaz comun con DungeonGen: tile_at, chunk_objects, chunk_creatures, start_pos, finite.

const T := preload("res://data/tiles.gd")
const CHUNK := 16
const CELL := 48                 # tamano (en tiles) de las celdas de aldeas y cuevas
const VILLAGE_RADIUS := 14

var world_seed: int
var finite := false
var _elev := FastNoiseLite.new()
var _moist := FastNoiseLite.new()
var _temp := FastNoiseLite.new()
var _river := FastNoiseLite.new()
var _village_cache := {}
var _cave_cache := {}
var _gate_tile := Vector2i.ZERO


func _init(seed_value: int) -> void:
	world_seed = seed_value
	_setup(_elev, seed_value, 0.011, 4)
	_setup(_moist, seed_value + 101, 0.016, 3)
	_setup(_temp, seed_value + 202, 0.008, 2)
	_setup(_river, seed_value + 303, 0.012, 1)
	_gate_tile = _find_gate()


func _setup(n: FastNoiseLite, s: int, freq: float, octaves: int) -> void:
	n.seed = s
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = freq
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = octaves


func start_pos() -> Vector2:
	return Vector2(0.0, 0.0)


# ------------------------------------------------------------ hashing
func _hash(a: int, b: int, c: int) -> int:
	var h: int = (world_seed * 73856093) ^ (a * 19349663) ^ (b * 83492791) ^ (c * 2654435761)
	h = (h ^ (h >> 13)) * 1274126177
	return (h ^ (h >> 16)) & 0x7fffffff


func _rng(a: int, b: int, c: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = _hash(a, b, c)
	return r


# ------------------------------------------------------------ terreno
func elevation(tx: int, ty: int) -> float:
	var e := _elev.get_noise_2d(tx, ty)
	var d := sqrt(float(tx * tx + ty * ty))
	if d < 34.0:
		var k := clampf((d - 12.0) / 22.0, 0.0, 1.0)
		e = lerpf(0.1, e, k)
	return e


func tile_at(tx: int, ty: int) -> int:
	var e := elevation(tx, ty)
	var d := sqrt(float(tx * tx + ty * ty))
	if e < -0.36:
		return T.DEEP
	if e < -0.2:
		return T.WATER
	if d > 16.0 and e < 0.4 and absf(_river.get_noise_2d(tx, ty)) < 0.03:
		return T.WATER
	if e < -0.12:
		return T.SAND
	if e > 0.46:
		return T.STONE
	if e > 0.36:
		return T.GRAVEL
	var v := village_at_tile(tx, ty)
	if not v.is_empty():
		var dx: int = tx - int(v["tx"])
		var dy: int = ty - int(v["ty"])
		if (absi(dx) <= 1 or absi(dy) <= 1) and absi(dx) <= VILLAGE_RADIUS and absi(dy) <= VILLAGE_RADIUS:
			return T.PATH
		return T.GRASS
	var m := _moist.get_noise_2d(tx, ty)
	var t := _temp.get_noise_2d(tx, ty)
	if t > 0.22 and m < 0.05 and d > 30.0:
		return T.DESERT
	if m > 0.1 and d > 12.0:
		return T.FOREST
	return T.GRASS


# ------------------------------------------------------------ aldeas y cuevas
func _cell_of(tx: int, ty: int) -> Vector2i:
	return Vector2i(floori(float(tx) / CELL), floori(float(ty) / CELL))


## Devuelve {} o {tx, ty, id} si el tile pertenece a una aldea.
func village_at_tile(tx: int, ty: int) -> Dictionary:
	var c := _cell_of(tx, ty)
	var v := village_in_cell(c)
	if v.is_empty():
		return v
	if absi(tx - int(v["tx"])) <= VILLAGE_RADIUS + 1 and absi(ty - int(v["ty"])) <= VILLAGE_RADIUS + 1:
		return v
	return {}


func village_in_cell(c: Vector2i) -> Dictionary:
	if _village_cache.has(c):
		return _village_cache[c]
	var out := {}
	if c == Vector2i(0, -1):
		out = {"tx": 14, "ty": -10, "id": "v_0_m1"}
	else:
		var r := _rng(c.x, c.y, 11)
		if r.randf() < 0.5:
			var tx := c.x * CELL + r.randi_range(16, CELL - 16)
			var ty := c.y * CELL + r.randi_range(16, CELL - 16)
			var e := elevation(tx, ty)
			var m := _moist.get_noise_2d(tx, ty)
			if e > -0.05 and e < 0.3 and m < 0.3:
				out = {"tx": tx, "ty": ty, "id": "v_%d_%d" % [c.x, c.y]}
	_village_cache[c] = out
	return out


func cave_in_cell(c: Vector2i) -> Dictionary:
	if _cave_cache.has(c):
		return _cave_cache[c]
	var out := {}
	if c == Vector2i(-1, 0):
		out = {"tx": -16, "ty": 14, "id": "cave_m1_0"}
	else:
		var r := _rng(c.x, c.y, 23)
		if r.randf() < 0.45:
			var tx := c.x * CELL + r.randi_range(6, CELL - 6)
			var ty := c.y * CELL + r.randi_range(6, CELL - 6)
			var t := tile_at(tx, ty)
			if T.is_land(t) and t != T.PATH and t != T.SAND:
				var v := village_in_cell(c)
				if v.is_empty() or Vector2(tx - int(v["tx"]), ty - int(v["ty"])).length() > 20.0:
					out = {"tx": tx, "ty": ty, "id": "cave_%d_%d" % [c.x, c.y]}
	_cave_cache[c] = out
	return out


## Posicion (en tiles) de la puerta al jefe final: distinta en cada mundo, siempre en tierra firme.
func boss_gate_tile() -> Vector2i:
	return _gate_tile


func _find_gate() -> Vector2i:
	var r := _rng(7, 7, 7)
	var base := r.randf() * TAU
	var dist := 80
	while dist < 260:
		for k in 12:
			var a := base + k * 0.52
			var tx := roundi(cos(a) * dist)
			var ty := roundi(sin(a) * dist)
			var ok := true
			for ox in range(-1, 2):
				for oy in range(-1, 2):
					var t := tile_at(tx + ox, ty + oy)
					if not (t == T.GRASS or t == T.FOREST or t == T.DESERT or t == T.GRAVEL):
						ok = false
			if ok:
				return Vector2i(tx, ty)
		dist += 8
	return Vector2i(120, 0)


# ------------------------------------------------------------ objetos por chunk
## Cada objeto: {type, tx, ty, variant, id}. Tipos: tree, shrub, rock, cactus, house, npc, cave, boss_gate.
func chunk_objects(cx: int, cy: int) -> Array:
	var out: Array = []
	var r := _rng(cx, cy, 1)
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	var used: Array = []
	var gate := _gate_tile
	if gate.x >= x0 and gate.x < x0 + CHUNK and gate.y >= y0 and gate.y < y0 + CHUNK:
		out.append({"type": "boss_gate", "tx": gate.x, "ty": gate.y, "variant": 0, "id": "boss_gate"})
		used.append(gate)
	var c := _cell_of(x0 + 8, y0 + 8)
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var cc := Vector2i(c.x + dx, c.y + dy)
			var cave := cave_in_cell(cc)
			if not cave.is_empty():
				var ct := Vector2i(int(cave["tx"]), int(cave["ty"]))
				if ct.x >= x0 and ct.x < x0 + CHUNK and ct.y >= y0 and ct.y < y0 + CHUNK:
					out.append({"type": "cave", "tx": ct.x, "ty": ct.y, "variant": 0, "id": str(cave["id"])})
					used.append(ct)
			var v := village_in_cell(cc)
			if not v.is_empty():
				_village_objects(v, x0, y0, out, used)
	for i in 16:
		var tx := x0 + r.randi_range(0, CHUNK - 1)
		var ty := y0 + r.randi_range(0, CHUNK - 1)
		var roll := r.randf()
		var d := sqrt(float(tx * tx + ty * ty))
		if d < 5.0 or not village_at_tile(tx, ty).is_empty():
			continue
		var p := Vector2i(tx, ty)
		var near := false
		for u in used:
			if absi(u.x - p.x) <= 1 and absi(u.y - p.y) <= 1:
				near = true
		if near:
			continue
		var t := tile_at(tx, ty)
		var typ := ""
		var variant := r.randi_range(0, 1)
		if t == T.FOREST:
			if roll < 0.5:
				typ = "tree"
			elif roll < 0.58:
				typ = "shrub"
			elif roll < 0.62:
				typ = "rock"
		elif t == T.GRASS:
			if roll < 0.1:
				typ = "tree"
			elif roll < 0.15:
				typ = "shrub"
			elif roll < 0.19:
				typ = "rock"
		elif t == T.DESERT:
			if roll < 0.12:
				typ = "cactus"
			elif roll < 0.18:
				typ = "rock"
		elif t == T.GRAVEL:
			if roll < 0.2:
				typ = "rock"
		if typ != "":
			used.append(p)
			out.append({"type": typ, "tx": tx, "ty": ty, "variant": variant, "id": "o_%d_%d_%d" % [cx, cy, i]})
	return out


func _village_objects(v: Dictionary, x0: int, y0: int, out: Array, used: Array) -> void:
	var vx: int = int(v["tx"])
	var vy: int = int(v["ty"])
	var houses := [Vector2i(-9, -4), Vector2i(9, -4), Vector2i(-9, 9)]
	var i := 0
	for h in houses:
		var tx: int = vx + h.x
		var ty: int = vy + h.y
		if tx >= x0 and tx < x0 + CHUNK and ty >= y0 and ty < y0 + CHUNK:
			out.append({"type": "house", "tx": tx, "ty": ty, "variant": i % 3, "id": "%s_h%d" % [str(v["id"]), i]})
			used.append(Vector2i(tx, ty))
		i += 1
	var npcs := [["elder", Vector2i(3, 3)], ["healer", Vector2i(-4, 3)]]
	for n in npcs:
		var off: Vector2i = n[1]
		var tx: int = vx + off.x
		var ty: int = vy + off.y
		if tx >= x0 and tx < x0 + CHUNK and ty >= y0 and ty < y0 + CHUNK:
			out.append({"type": "npc", "tx": tx, "ty": ty, "variant": 0, "role": str(n[0]), "id": "%s_%s" % [str(v["id"]), str(n[0])]})
			used.append(Vector2i(tx, ty))


# ------------------------------------------------------------ criaturas por chunk
func chunk_creatures(cx: int, cy: int) -> Array:
	var out: Array = []
	var r := _rng(cx, cy, 2)
	var count := r.randi_range(0, 3)
	for i in count:
		var tx := cx * CHUNK + r.randi_range(1, CHUNK - 2)
		var ty := cy * CHUNK + r.randi_range(1, CHUNK - 2)
		var d := sqrt(float(tx * tx + ty * ty))
		if d < 10.0 or not village_at_tile(tx, ty).is_empty():
			continue
		var t := tile_at(tx, ty)
		var roll := r.randf()
		var sp := ""
		var hostile_ok := d > 36.0
		if t == T.FOREST:
			if roll < 0.3:
				sp = "deer"
			elif roll < 0.5:
				sp = "boar" if hostile_ok else "bunny"
			elif roll < 0.8:
				sp = "mushroom" if hostile_ok else "fox"
			else:
				sp = "wolf" if hostile_ok else "deer"
		elif t == T.GRASS:
			if roll < 0.35:
				sp = "bunny"
			elif roll < 0.6:
				sp = "deer"
			elif roll < 0.8:
				sp = "fox"
			else:
				sp = "wolf" if hostile_ok else "bunny"
		elif t == T.DESERT:
			sp = "fox" if roll < 0.6 else ("wolf" if hostile_ok else "fox")
		elif t == T.GRAVEL:
			sp = "wolf" if hostile_ok else "fox"
		if sp != "":
			out.append({"species": sp, "tx": tx, "ty": ty, "id": "c_%d_%d_%d" % [cx, cy, i]})
	return out
