extends RefCounted
## Cuevas y mazmorras. Dos modos:
##  - generate(seed): mazmorra procedural (distinta en cada mundo y cueva).
##  - boss_arena(): arena del jefe final, IDENTICA en todos los mundos.
## Interfaz comun con Terrain: tile_at, chunk_objects, chunk_creatures, start_pos, finite.

const T := preload("res://data/tiles.gd")
const CHUNK := 16

var finite := true
var w := 64
var h := 64
var tiles := PackedInt32Array()
var rooms: Array = []
var start := Vector2i.ZERO
var exit_tile := Vector2i.ZERO
var chests: Array = []        # [{tx, ty, id}]
var spawns: Array = []        # [{species, tx, ty, id}]
var is_boss := false
var boss_spawn := Vector2i.ZERO
var dungeon_id := ""


func tile_at(tx: int, ty: int) -> int:
	if tx < 0 or ty < 0 or tx >= w or ty >= h:
		return T.DWALL
	return tiles[ty * w + tx]


func start_pos() -> Vector2:
	return Vector2(start.x * 16 + 8, start.y * 16 + 8)


func _fill(v: int) -> void:
	tiles = PackedInt32Array()
	tiles.resize(w * h)
	for i in tiles.size():
		tiles[i] = v


func _carve(r: Rect2i, tile: int) -> void:
	for y in range(r.position.y, r.end.y):
		for x in range(r.position.x, r.end.x):
			if x > 0 and y > 0 and x < w - 1 and y < h - 1:
				tiles[y * w + x] = tile


func generate(seed_value: int, id: String) -> void:
	dungeon_id = id
	is_boss = false
	w = 64
	h = 64
	_fill(T.DWALL)
	var r := RandomNumberGenerator.new()
	r.seed = seed_value
	rooms = []
	var tries := 0
	while rooms.size() < 8 and tries < 80:
		tries += 1
		var rw := r.randi_range(6, 12)
		var rh := r.randi_range(6, 11)
		var rx := r.randi_range(2, w - rw - 3)
		var ry := r.randi_range(2, h - rh - 3)
		var cand := Rect2i(rx, ry, rw, rh)
		var ok := true
		for other in rooms:
			if cand.grow(3).intersects(other):
				ok = false
		if ok:
			rooms.append(cand)
	for rm in rooms:
		_carve(rm, T.DFLOOR)
	for i in range(rooms.size() - 1):
		var a: Rect2i = rooms[i]
		var b: Rect2i = rooms[i + 1]
		var ca := a.position + a.size / 2
		var cb := b.position + b.size / 2
		_carve(Rect2i(mini(ca.x, cb.x), ca.y - 1, absi(cb.x - ca.x) + 2, 3), T.DFLOOR)
		_carve(Rect2i(cb.x - 1, mini(ca.y, cb.y), 3, absi(cb.y - ca.y) + 2), T.DFLOOR)
	var first: Rect2i = rooms[0]
	start = first.position + first.size / 2
	exit_tile = start
	tiles[exit_tile.y * w + exit_tile.x] = T.STAIRS
	start = Vector2i(start.x, start.y + 1)
	chests = []
	spawns = []
	var last: Rect2i = rooms[rooms.size() - 1]
	var lc := last.position + last.size / 2
	chests.append({"tx": lc.x, "ty": lc.y, "id": "%s_chest_a" % id})
	if rooms.size() > 3:
		var mid: Rect2i = rooms[rooms.size() / 2]
		chests.append({"tx": mid.position.x + 1, "ty": mid.position.y + 1, "id": "%s_chest_b" % id})
	for i in range(1, rooms.size()):
		var rm: Rect2i = rooms[i]
		var n := r.randi_range(2, 4)
		for k in n:
			var sx := r.randi_range(rm.position.x + 1, rm.end.x - 2)
			var sy := r.randi_range(rm.position.y + 1, rm.end.y - 2)
			var sp := "mushroom" if r.randf() < 0.65 else "wolf"
			spawns.append({"species": sp, "tx": sx, "ty": sy, "id": "%s_c%d_%d" % [id, i, k]})
	if r.randf() < 0.7:
		spawns.append({"species": "blood", "tx": lc.x + 2, "ty": lc.y + 2, "id": "%s_miniboss" % id})


## Arena del jefe final: fija, no depende de la semilla del mundo.
func boss_arena() -> void:
	dungeon_id = "boss"
	is_boss = true
	w = 40
	h = 30
	_fill(T.DWALL)
	_carve(Rect2i(2, 2, 36, 25), T.BFLOOR)
	for p in [Vector2i(9, 8), Vector2i(29, 8), Vector2i(9, 18), Vector2i(29, 18)]:
		_carve(Rect2i(p.x, p.y, 2, 2), T.DWALL)
	_carve(Rect2i(2, 2, 3, 3), T.LAVA)
	_carve(Rect2i(35, 2, 3, 3), T.LAVA)
	exit_tile = Vector2i(20, 26)
	tiles[exit_tile.y * w + exit_tile.x] = T.STAIRS
	tiles[exit_tile.y * w + exit_tile.x - 1] = T.STAIRS
	start = Vector2i(20, 24)
	boss_spawn = Vector2i(20, 6)
	rooms = [Rect2i(2, 2, 36, 25)]
	chests = []
	spawns = []


func chunk_objects(cx: int, cy: int) -> Array:
	var out: Array = []
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	if exit_tile.x >= x0 and exit_tile.x < x0 + CHUNK and exit_tile.y >= y0 and exit_tile.y < y0 + CHUNK:
		out.append({"type": "exit", "tx": exit_tile.x, "ty": exit_tile.y, "variant": 0, "id": "exit"})
	for c in chests:
		if int(c["tx"]) >= x0 and int(c["tx"]) < x0 + CHUNK and int(c["ty"]) >= y0 and int(c["ty"]) < y0 + CHUNK:
			out.append({"type": "chest", "tx": int(c["tx"]), "ty": int(c["ty"]), "variant": 0, "id": str(c["id"])})
	if is_boss:
		if boss_spawn.x >= x0 and boss_spawn.x < x0 + CHUNK and boss_spawn.y >= y0 and boss_spawn.y < y0 + CHUNK:
			out.append({"type": "crystal", "tx": boss_spawn.x, "ty": boss_spawn.y - 4, "variant": 0, "id": "boss_crystal"})
	return out


func chunk_creatures(cx: int, cy: int) -> Array:
	var out: Array = []
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	for s in spawns:
		if int(s["tx"]) >= x0 and int(s["tx"]) < x0 + CHUNK and int(s["ty"]) >= y0 and int(s["ty"]) < y0 + CHUNK:
			out.append(s)
	if is_boss and boss_spawn.x >= x0 and boss_spawn.x < x0 + CHUNK and boss_spawn.y >= y0 and boss_spawn.y < y0 + CHUNK:
		out.append({"species": "demon", "tx": boss_spawn.x, "ty": boss_spawn.y, "id": "boss_demon"})
	return out


## Comprobacion de conectividad (usada por la prueba automatica).
func reachable(from_t: Vector2i, to_t: Vector2i) -> bool:
	var seen := {}
	var queue: Array = [from_t]
	seen[from_t] = true
	while not queue.is_empty():
		var cur: Vector2i = queue.pop_back()
		if cur == to_t:
			return true
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var nx: Vector2i = cur + d
			if not seen.has(nx) and not T.is_solid(tile_at(nx.x, nx.y)):
				seen[nx] = true
				queue.append(nx)
	return false
