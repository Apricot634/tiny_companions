extends Node2D
## Habitante de la aldea. Roles: elder (anciano), healer (curandera).

const Appearances := preload("res://data/appearances.gd")
const SKIN_BY_ROLE := {"elder": 4, "healer": 5}

var role := "elder"
var sprite: Sprite2D
var _t := 0.0


func _ready() -> void:
	sprite = Sprite2D.new()
	sprite.texture = load(Appearances.SHEET % int(SKIN_BY_ROLE.get(role, 4)))
	sprite.hframes = 3
	sprite.vframes = 4
	sprite.centered = false
	sprite.offset = Vector2(-8, -19)
	sprite.frame = Appearances.ROW_DOWN * 3 + 1
	add_child(sprite)


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0, 0, 0, 0.25))


func _process(delta: float) -> void:
	_t += delta
	var p = get_tree().get_first_node_in_group("player")
	var row := Appearances.ROW_DOWN
	if p != null:
		var d: Vector2 = p.position - position
		if d.length() < 70.0:
			if absf(d.x) > absf(d.y):
				row = Appearances.ROW_RIGHT if d.x > 0.0 else Appearances.ROW_LEFT
			else:
				row = Appearances.ROW_DOWN if d.y > 0.0 else Appearances.ROW_UP
	sprite.frame = row * 3 + 1
	sprite.position.y = -absf(sin(_t * 2.0)) * 0.6
