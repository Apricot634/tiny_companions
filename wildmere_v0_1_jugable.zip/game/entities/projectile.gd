extends Node2D
## Proyectil del jugador: flecha o bola de fuego.

var world = null
var dir := Vector2.RIGHT
var speed := 230.0
var dmg := 8.0
var kind := "arrow"
var radius := 26.0
var life := 1.1
var _t := 0.0
var _arrow_tex: Texture2D = null


func _ready() -> void:
	if kind == "arrow":
		_arrow_tex = load("res://assets/props/arrow.png")
		rotation = dir.angle()
	z_index = 3


func _process(delta: float) -> void:
	_t += delta
	life -= delta
	var step := dir * speed * delta
	position += step
	if kind == "fireball":
		queue_redraw()
	if world == null:
		queue_free()
		return
	if world.chunk_view.is_blocked_px(position):
		_impact(null)
		return
	var c = world.creature_at(position, 5.0)
	if c != null:
		_impact(c)
		return
	if life <= 0.0:
		if kind == "fireball":
			_impact(null)
		else:
			queue_free()


func _impact(target) -> void:
	if kind == "arrow":
		if target != null:
			target.take_damage(dmg, position - dir * 4.0, 50.0)
		world.spawn_fx("arrow_impact", position, 0.0, 0.6)
	else:
		world.area_damage(position, radius, dmg)
		world.spawn_fx("fireball_impact", position + Vector2(0, 6), 0.0, 0.55)
	queue_free()


func _draw() -> void:
	if kind == "arrow":
		if _arrow_tex != null:
			draw_texture(_arrow_tex, Vector2(-7, -3))
		return
	var f := 1.0 + 0.15 * sin(_t * 30.0)
	draw_circle(Vector2.ZERO, 6.0 * f, Color(1.0, 0.45, 0.1, 0.55))
	draw_circle(Vector2.ZERO, 4.0 * f, Color(1.0, 0.7, 0.2, 0.9))
	draw_circle(Vector2.ZERO, 2.0, Color(1.0, 0.95, 0.7, 1.0))
	draw_circle(-dir * 6.0, 3.0, Color(1.0, 0.4, 0.1, 0.4))
