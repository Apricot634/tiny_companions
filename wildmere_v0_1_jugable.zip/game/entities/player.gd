extends Node2D
## Jugador: movimiento, espada, arco, hechizos, escudo y esquiva. Arma visible en la mano.

const Appearances := preload("res://data/appearances.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")

var world = null
var facing := Vector2.DOWN
var sprite: Sprite2D
var weapon_spr: Sprite2D
var shield_spr: Sprite2D
var moving := false
var dead := false
var blocking := false
var attack_cd := 0.0
var bow_cd := 0.0
var spell_cd := 0.0
var dash_t := 0.0
var dash_cd := 0.0
var invuln := 0.0
var speed := 80.0
var _anim_t := 0.0
var _swing_t := 0.0
var _flash := 0.0
var _bow_show := 0.0
var _behind := false
var _slash_t := 0.0
var _slash_dir := Vector2.DOWN


func _ready() -> void:
	add_to_group("player")
	sprite = Sprite2D.new()
	sprite.texture = load(Appearances.SHEET % GameState.appearance)
	sprite.hframes = 3
	sprite.vframes = 4
	sprite.centered = false
	sprite.offset = Vector2(-8, -19)
	sprite.frame = 1
	add_child(sprite)
	weapon_spr = Sprite2D.new()
	add_child(weapon_spr)
	shield_spr = Sprite2D.new()
	shield_spr.texture = load(Items.icon_path("shield"))
	shield_spr.visible = false
	add_child(shield_spr)
	speed = float(Appearances.STYLES[GameState.style]["speed"])
	refresh_weapon()


func refresh_weapon() -> void:
	var wid: String = GameState.weapon
	if Items.ITEMS.has(wid):
		weapon_spr.texture = load(Items.icon_path(wid))


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0, 0, 0, 0.25))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if blocking:
		draw_arc(Vector2(0, -9), 13.0, facing.angle() - 1.0, facing.angle() + 1.0, 10, Color(0.5, 0.85, 1.0, 0.9), 2.0)
	if _slash_t > 0.0:
		var a := _slash_dir.angle()
		var k := _slash_t / 0.18
		draw_arc(Vector2(0, -9), 18.0, a - 1.1, a + 1.1, 14, Color(1, 1, 1, k * 0.9), 3.0)
		draw_arc(Vector2(0, -9), 22.0, a - 0.9, a + 0.9, 14, Color(0.8, 0.9, 1, k * 0.5), 2.0)


func _process(delta: float) -> void:
	if dead:
		return
	attack_cd = maxf(0.0, attack_cd - delta)
	bow_cd = maxf(0.0, bow_cd - delta)
	spell_cd = maxf(0.0, spell_cd - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	invuln = maxf(0.0, invuln - delta)
	_swing_t = maxf(0.0, _swing_t - delta)
	_bow_show = maxf(0.0, _bow_show - delta)
	if _slash_t > 0.0:
		_slash_t = maxf(0.0, _slash_t - delta)
		queue_redraw()
	if _flash > 0.0:
		_flash -= delta
		if _flash <= 0.0:
			sprite.modulate = Color.WHITE
	var move := Vector2.ZERO
	if not world.input_locked():
		move = Controls.get_move()
	var spd := speed
	if blocking:
		spd *= 0.5
	if dash_t > 0.0:
		dash_t -= delta
		move = facing
		spd = 220.0
	moving = move.length() > 0.1
	if moving:
		if dash_t <= 0.0:
			facing = move.normalized()
		world.move_entity(self, move.limit_length(1.0) * spd * delta, 4.0)
		_anim_t += delta
	else:
		_anim_t = 0.0
	GameState.pos = position
	_update_visuals()


func _row_for_facing() -> int:
	if absf(facing.x) > absf(facing.y):
		return Appearances.ROW_RIGHT if facing.x > 0.0 else Appearances.ROW_LEFT
	return Appearances.ROW_DOWN if facing.y > 0.0 else Appearances.ROW_UP


func _update_visuals() -> void:
	var cols := [1, 0, 1, 2]
	var col := 1
	if moving:
		col = cols[int(_anim_t * 8.0) % 4]
	sprite.frame = _row_for_facing() * 3 + col
	var base := facing * 8.0 + Vector2(0, -8)
	var show_bow := _bow_show > 0.0
	if show_bow:
		weapon_spr.texture = load(Items.icon_path("bow"))
	elif weapon_spr.texture != null:
		weapon_spr.texture = load(Items.icon_path(GameState.weapon))
	var rot := facing.angle() + PI / 4.0
	if _swing_t > 0.0:
		rot += lerpf(0.9, -0.9, 1.0 - _swing_t / 0.22)
	weapon_spr.rotation = rot
	weapon_spr.position = base
	weapon_spr.scale = Vector2(0.8, 0.8)
	shield_spr.visible = blocking
	shield_spr.position = facing * 7.0 + Vector2(0, -8)
	var behind := facing.y < -0.5
	if behind != _behind:
		_behind = behind
		move_child(weapon_spr, 0 if behind else get_child_count() - 1)
	if blocking:
		queue_redraw()


# ------------------------------------------------------------ acciones
func do_attack() -> void:
	if dead or blocking or attack_cd > 0.0 or world.input_locked():
		return
	attack_cd = 0.42
	_swing_t = 0.22
	_slash_t = 0.18
	_slash_dir = facing
	var wid: String = GameState.weapon
	var dmg: float = float(Items.ITEMS[wid]["dmg"]) if Items.ITEMS.has(wid) else 4.0
	var hits: Array = world.creatures_in_cone(position, facing, 30.0)
	for c in hits:
		c.take_damage(dmg, position, 70.0)
	Audio.play("attack")


func do_bow() -> void:
	if dead or blocking or bow_cd > 0.0 or world.input_locked():
		return
	if not GameState.has_item("bow"):
		world.hud.toast("need_bow")
		Audio.play("error")
		return
	if not GameState.has_item("arrow"):
		world.hud.toast("need_arrows")
		Audio.play("error")
		return
	GameState.remove_item("arrow", 1)
	bow_cd = 0.55
	_bow_show = 0.3
	world.spawn_projectile("arrow", position + Vector2(0, -8) + facing * 8.0, facing, 9.0)
	Audio.play("attack")


func do_spell() -> void:
	if dead or blocking or spell_cd > 0.0 or world.input_locked():
		return
	if GameState.spells.is_empty():
		return
	var sid: String = GameState.spells[GameState.spell_index % GameState.spells.size()]
	var sp: Dictionary = Spells.SPELLS[sid]
	if GameState.mp < float(sp["mana"]):
		world.hud.toast("no_mana")
		Audio.play("error")
		return
	GameState.mp -= float(sp["mana"])
	spell_cd = float(sp["cooldown"])
	_swing_t = 0.22
	var bonus := 1.5 if GameState.weapon == "staff" else 1.0
	match str(sp["kind"]):
		"projectile":
			world.spawn_projectile("fireball", position + Vector2(0, -8) + facing * 8.0, facing, float(sp["dmg"]) * bonus, float(sp["radius"]))
		"ground":
			var tgt := position + facing * float(sp["range"])
			world.spawn_fx(str(sp["fx"]), tgt, 0.0, 0.7)
			var timer := get_tree().create_timer(0.45)
			timer.timeout.connect(_ice_hit.bind(tgt, float(sp["dmg"]) * bonus, float(sp["radius"])))
		"self":
			GameState.heal(float(sp["heal"]) * bonus)
			world.spawn_fx(str(sp["fx"]), position, 0.0, 0.6)
	Audio.play("spell")


func _ice_hit(tgt: Vector2, dmg: float, radius: float) -> void:
	if is_instance_valid(world):
		world.area_damage(tgt, radius, dmg)


func set_block(v: bool) -> void:
	if v and not GameState.has_item("shield"):
		world.hud.toast("need_shield")
		Audio.play("error")
		return
	blocking = v and not dead
	shield_spr.visible = blocking
	queue_redraw()


func do_dash() -> void:
	if dead or dash_cd > 0.0 or world.input_locked():
		return
	dash_cd = 0.9
	dash_t = 0.18
	invuln = 0.3


func take_damage(amount: float, from_pos: Vector2) -> void:
	if dead or invuln > 0.0:
		return
	var dmg := amount
	var from_dir := (from_pos - position).normalized()
	if blocking and from_dir.dot(facing) > 0.0:
		dmg *= 0.2
		world.spawn_fx("hit_spark", position + facing * 10.0 + Vector2(0, -8), 0.0, 0.5)
		Audio.play("block")
	else:
		sprite.modulate = Color(1, 0.4, 0.4)
		_flash = 0.15
		Audio.play("hurt")
		world.move_entity(self, -from_dir * 5.0, 4.0)
	GameState.hp -= dmg
	invuln = 0.7
	if GameState.hp <= 0.0:
		GameState.hp = 0.0
		dead = true
		blocking = false
		sprite.modulate = Color(0.6, 0.6, 0.6)
		world.on_player_died()
