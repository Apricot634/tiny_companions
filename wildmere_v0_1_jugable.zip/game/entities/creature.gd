extends Node2D
## Criatura (animal, monstruo o jefe) dirigida por datos de data/species.gd.
## Comportamientos: passive (huye), territorial (ataca si la molestan o se acercan mucho), hostile (persigue).

const Species := preload("res://data/species.gd")

var world = null
var species_id := ""
var cid := ""
var data := {}
var hp := 10.0
var max_hp := 10.0
var radius := 6.0
var home := Vector2.ZERO
var state := "idle"
var target := Vector2.ZERO
var timer := 1.0
var attack_cd := 0.0
var windup := 0.0
var hurt_t := 0.0
var flee_t := 0.0
var provoked := false
var vel := Vector2.ZERO
var dead := false
var spr: AnimatedSprite2D
var _flash := 0.0
var _death_t := 0.0
var _bar_t := 0.0
var _slam_cd := 6.0
var _slam_pos := Vector2.ZERO
var _slam_t := -1.0
var _summoned := false


func setup(sid: String, id: String, world_ref) -> void:
	species_id = sid
	cid = id
	world = world_ref
	data = Species.get_species(sid)
	max_hp = float(data["hp"])
	hp = max_hp
	radius = float(data["radius"])


func _ready() -> void:
	add_to_group("creatures")
	var frames := SpriteFrames.new()
	if frames.has_animation("default"):
		frames.remove_animation("default")
	for anim_name in data["anims"].keys():
		var a: Dictionary = data["anims"][anim_name]
		var tex: Texture2D = load(str(a["tex"]))
		frames.add_animation(anim_name)
		frames.set_animation_speed(anim_name, float(a["fps"]))
		frames.set_animation_loop(anim_name, bool(a["loop"]))
		for i in int(a["n"]):
			var at := AtlasTexture.new()
			at.atlas = tex
			at.region = Rect2(i * int(a["fw"]), int(a["row"]) * int(a["fh"]), int(a["fw"]), int(a["fh"]))
			frames.add_frame(anim_name, at)
	spr = AnimatedSprite2D.new()
	spr.sprite_frames = frames
	spr.centered = false
	var foot: Vector2 = data["foot"]
	spr.offset = -foot
	var sc := float(data.get("scale", 1.0))
	spr.scale = Vector2(sc, sc)
	add_child(spr)
	spr.play("idle")
	timer = randf_range(0.5, 2.5)
	home = position


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, radius + 2.0, Color(0, 0, 0, 0.25))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if _bar_t > 0.0 and not dead:
		var y := -float(data["height"]) * float(data.get("scale", 1.0)) - 7.0
		var bw := maxf(18.0, radius * 2.0)
		draw_rect(Rect2(-bw / 2.0, y, bw, 3), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-bw / 2.0 + 1.0, y + 1, (bw - 2.0) * clampf(hp / max_hp, 0.0, 1.0), 1), Color(0.9, 0.2, 0.2, 1.0))


func body_center() -> Vector2:
	return position + Vector2(0, -float(data["height"]) * float(data.get("scale", 1.0)) * 0.4)


func _play(anim_name: String) -> void:
	if spr.sprite_frames.has_animation(anim_name) and spr.animation != anim_name:
		spr.play(anim_name)


func _process(delta: float) -> void:
	if dead:
		_death_t -= delta
		if _death_t <= 0.0:
			queue_free()
		return
	attack_cd = maxf(0.0, attack_cd - delta)
	hurt_t -= delta
	flee_t -= delta
	_bar_t = maxf(0.0, _bar_t - delta)
	if _flash > 0.0:
		_flash -= delta
		if _flash <= 0.0:
			spr.modulate = Color.WHITE
	if vel.length() > 2.0:
		world.move_entity(self, vel * delta, radius)
		vel = vel.lerp(Vector2.ZERO, minf(1.0, delta * 9.0))
	if hurt_t > 0.0:
		return
	var p = world.player
	var to_p: Vector2 = p.position - position
	var dist := to_p.length()
	var beh := str(data["behavior"])
	var speed := float(data["speed"])
	var alive_player: bool = not world.player_dead()
	if bool(data.get("boss", false)):
		_boss_logic(delta, dist)
	var hostile_now := (beh == "hostile") or (beh == "territorial" and (provoked or dist < 36.0))
	if beh == "passive" and (provoked or dist < 40.0) and alive_player:
		flee_t = 2.2
		state = "flee"
	elif hostile_now and alive_player and dist < float(data["sight"]) and state != "attack":
		state = "chase"
	match state:
		"attack":
			windup -= delta
			if windup <= 0.0:
				if dist <= float(data["range"]) * 1.7 and alive_player:
					world.damage_player(float(data["dmg"]), position)
				attack_cd = 1.1
				state = "chase"
		"chase":
			if not alive_player or dist > float(data["sight"]) * 1.7:
				state = "idle"
				timer = 1.0
			elif dist <= float(data["range"]) and attack_cd <= 0.0:
				state = "attack"
				windup = 0.35
				_play("attack")
			elif dist > float(data["range"]) * 0.8:
				_move_toward(p.position, speed, delta)
		"flee":
			if flee_t <= 0.0:
				state = "idle"
				timer = 1.5
			else:
				_move_toward(position - to_p, speed * 1.1, delta)
		"wander":
			if position.distance_to(target) < 3.0:
				state = "idle"
				timer = randf_range(1.5, 4.0)
			else:
				_move_toward(target, speed * 0.45, delta)
		_:
			_play("idle")
			timer -= delta
			if timer <= 0.0:
				var r := 56.0
				target = home + Vector2(randf_range(-r, r), randf_range(-r, r) * 0.6)
				state = "wander"
	if _bar_t > 0.0:
		queue_redraw()


func _move_toward(dest: Vector2, speed: float, delta: float) -> void:
	var d := dest - position
	if d.length() < 1.0:
		return
	var dirv := d.normalized()
	world.move_entity(self, dirv * speed * delta, radius)
	if absf(dirv.x) > 0.1:
		spr.flip_h = dirv.x < 0.0
	_play("move")


func take_damage(amount: float, from_pos: Vector2, kb: float = 60.0) -> void:
	if dead:
		return
	hp -= amount
	provoked = true
	_bar_t = 3.0
	_flash = 0.12
	spr.modulate = Color(1, 0.45, 0.45)
	var boss := bool(data.get("boss", false))
	hurt_t = 0.05 if boss else 0.22
	vel = (position - from_pos).normalized() * (kb * (0.25 if boss else 1.0))
	if spr.sprite_frames.has_animation("hit") and not boss:
		spr.play("hit")
	world.spawn_fx("hit_spark", position + Vector2(0, -float(data["height"]) * float(data.get("scale", 1.0)) * 0.5), 0.0, 0.5)
	Audio.play("hit")
	queue_redraw()
	if hp <= 0.0:
		_die()


func _die() -> void:
	dead = true
	remove_from_group("creatures")
	spr.modulate = Color.WHITE
	_death_t = 1.2
	if spr.sprite_frames.has_animation("die"):
		spr.play("die")
		_death_t = float(spr.sprite_frames.get_frame_count("die")) / float(data["anims"]["die"]["fps"]) + 0.5
	else:
		var tw := create_tween()
		tw.tween_property(spr, "modulate:a", 0.0, 0.5)
		_death_t = 0.6
	queue_redraw()
	world.on_creature_killed(self)


func _boss_logic(delta: float, dist: float) -> void:
	if not _summoned and hp < max_hp * 0.5:
		_summoned = true
		for i in 2:
			world.spawn_creature({"species": "mushroom", "tx": floori(position.x / 16.0) + (i * 4 - 2), "ty": floori(position.y / 16.0) + 3, "id": "boss_minion_%d_%d" % [i, Time.get_ticks_msec()]})
		world.hud.toast("boss_summon")
	_slam_cd -= delta
	if _slam_t >= 0.0:
		_slam_t -= delta
		if _slam_t < 0.0:
			world.spawn_fx("ground_slam", _slam_pos, 0.0, 0.8)
			world.spawn_fx("small_explosion", _slam_pos, 0.0, 1.0)
			if world.player.position.distance_to(_slam_pos) < 34.0:
				world.damage_player(float(data["dmg"]) * 1.2, _slam_pos)
	elif _slam_cd <= 0.0 and dist < 200.0:
		_slam_cd = 7.0
		_slam_pos = world.player.position
		_slam_t = 0.9
		world.spawn_fx("stun_stars", _slam_pos + Vector2(0, -4), 0.0, 1.0, 0.9)
