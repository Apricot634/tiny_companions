extends RefCounted
## Apariencias de jugador (hojas SuperRetroWorld 16x20, 3 columnas x 4 filas) y estilos iniciales.

const SKINS := [1, 2, 3, 4, 5, 7, 9, 11, 13, 16, 21, 28]
const SHEET := "res://assets/characters/char_%02d.png"
const CELL := Vector2i(16, 20)
# Filas de la hoja: abajo, izquierda, derecha, arriba (convencion RPG Maker; si alguna direccion se ve
# invertida en el juego, basta con cambiar estos numeros).
const ROW_DOWN := 0
const ROW_LEFT := 1
const ROW_RIGHT := 2
const ROW_UP := 3

const STYLES := {
	"adventurer": {"hp": 100.0, "mp": 30.0, "speed": 80.0, "weapon": "sword",
		"items": {"sword": 1, "bow": 1, "arrow": 12, "apple": 3, "potion_hp": 1}, "spells": ["fireball"]},
	"warrior": {"hp": 130.0, "mp": 20.0, "speed": 76.0, "weapon": "sword2",
		"items": {"sword2": 1, "shield": 1, "apple": 3, "potion_hp": 2}, "spells": ["fireball"]},
	"mage": {"hp": 80.0, "mp": 70.0, "speed": 80.0, "weapon": "staff",
		"items": {"staff": 1, "apple": 3, "potion_mp": 3, "potion_hp": 1}, "spells": ["fireball", "ice", "heal"]},
	"archer": {"hp": 90.0, "mp": 30.0, "speed": 90.0, "weapon": "sword",
		"items": {"sword": 1, "bow": 1, "arrow": 40, "apple": 3, "potion_hp": 1}, "spells": ["fireball"]},
}
const STYLE_IDS := ["adventurer", "warrior", "mage", "archer"]
