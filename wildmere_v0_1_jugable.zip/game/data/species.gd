extends RefCounted
## Criaturas. Cada animacion: {tex, fw, fh, row, n, fps, loop}. Los sprites miran a la derecha.

const C := "res://assets/creatures/"


static func strip(file: String, fw: int, fh: int, n: int, fps: float, loop: bool = true) -> Dictionary:
	return {"tex": C + file, "fw": fw, "fh": fh, "row": 0, "n": n, "fps": fps, "loop": loop}


static func row(file: String, row_i: int, n: int, fps: float, loop: bool = true) -> Dictionary:
	return {"tex": C + file, "fw": 32, "fh": 32, "row": row_i, "n": n, "fps": fps, "loop": loop}


static func get_species(id: String) -> Dictionary:
	match id:
		"mushroom":
			return {"hp": 22.0, "speed": 36.0, "dmg": 6.0, "behavior": "hostile", "sight": 90.0, "range": 18.0,
				"foot": Vector2(40, 63), "height": 33.0, "scale": 1.0, "drops": {"gold": 2}, "radius": 6.0,
				"anims": {"idle": strip("mushroom_idle.png", 80, 64, 7, 8.0), "move": strip("mushroom_run.png", 80, 64, 8, 12.0),
					"attack": strip("mushroom_attack.png", 80, 64, 10, 14.0, false), "hit": strip("mushroom_hit.png", 80, 64, 5, 14.0, false),
					"die": strip("mushroom_die.png", 80, 64, 15, 14.0, false)}}
		"wolf":
			return {"hp": 30.0, "speed": 62.0, "dmg": 8.0, "behavior": "hostile", "sight": 110.0, "range": 16.0,
				"foot": Vector2(16, 31), "height": 12.0, "scale": 1.0, "drops": {"meat": 0.5, "gold": 3}, "radius": 6.0,
				"anims": {"idle": row("wolf.png", 0, 4, 6.0), "move": row("wolf.png", 1, 6, 12.0)}}
		"boar":
			return {"hp": 38.0, "speed": 50.0, "dmg": 10.0, "behavior": "territorial", "sight": 70.0, "range": 16.0,
				"foot": Vector2(16, 31), "height": 11.0, "scale": 1.0, "drops": {"meat": 0.8, "gold": 2}, "radius": 6.0,
				"anims": {"idle": row("boar.png", 0, 4, 6.0), "move": row("boar.png", 1, 4, 10.0)}}
		"fox":
			return {"hp": 12.0, "speed": 72.0, "dmg": 0.0, "behavior": "passive", "sight": 70.0, "range": 0.0,
				"foot": Vector2(16, 31), "height": 12.0, "scale": 1.0, "drops": {"meat": 0.3}, "radius": 5.0,
				"anims": {"idle": row("fox.png", 0, 4, 6.0), "move": row("fox.png", 1, 4, 12.0)}}
		"deer":
			return {"hp": 20.0, "speed": 66.0, "dmg": 0.0, "behavior": "passive", "sight": 80.0, "range": 0.0,
				"foot": Vector2(16, 31), "height": 15.0, "scale": 1.0, "drops": {"meat": 0.9}, "radius": 5.0,
				"anims": {"idle": row("deer1.png", 0, 4, 6.0), "move": row("deer1.png", 1, 4, 10.0)}}
		"bunny":
			return {"hp": 6.0, "speed": 56.0, "dmg": 0.0, "behavior": "passive", "sight": 60.0, "range": 0.0,
				"foot": Vector2(16, 31), "height": 9.0, "scale": 1.0, "drops": {"meat": 0.4}, "radius": 4.0,
				"anims": {"idle": row("bunny.png", 0, 4, 6.0), "move": row("bunny.png", 1, 4, 10.0)}}
		"blood":
			return {"hp": 140.0, "speed": 40.0, "dmg": 14.0, "behavior": "hostile", "sight": 150.0, "range": 26.0,
				"foot": Vector2(52, 58), "height": 16.0, "scale": 2.0, "drops": {"gold": 25, "potion_hp": 1.0}, "radius": 12.0, "mini_boss": true,
				"anims": {"idle": strip("blood_idle.png", 100, 100, 6, 8.0), "move": strip("blood_walk.png", 100, 100, 8, 10.0),
					"attack": strip("blood_attack.png", 100, 100, 8, 12.0, false), "hit": strip("blood_hurt.png", 100, 100, 4, 12.0, false),
					"die": strip("blood_death.png", 100, 100, 4, 8.0, false)}}
		"demon":
			return {"hp": 420.0, "speed": 46.0, "dmg": 20.0, "behavior": "hostile", "sight": 400.0, "range": 30.0,
				"foot": Vector2(53, 59), "height": 21.0, "scale": 3.0, "drops": {"gold": 200, "sword2": 1.0}, "radius": 15.0, "boss": true,
				"anims": {"idle": strip("demon_idle.png", 100, 100, 6, 8.0), "move": strip("demon_walk.png", 100, 100, 8, 10.0),
					"attack": strip("demon_attack.png", 100, 100, 7, 12.0, false), "hit": strip("demon_hurt.png", 100, 100, 4, 12.0, false),
					"die": strip("demon_death.png", 100, 100, 4, 8.0, false)}}
	return {}
