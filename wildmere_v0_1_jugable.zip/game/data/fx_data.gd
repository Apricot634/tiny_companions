extends RefCounted
## Generado por make_assets.py desde los manifiestos de PVFX Foundry (hojas grid de 8 columnas).
const FX := {
	"magic_missile": {"w": 156, "h": 60, "n": 28, "ms": 70, "px": 128, "py": 30, "loop": false},
	"fireball_impact": {"w": 96, "h": 64, "n": 15, "ms": 70, "px": 72, "py": 38, "loop": false},
	"ice_spike": {"w": 96, "h": 80, "n": 26, "ms": 70, "px": 46, "py": 68, "loop": false},
	"holy_heal": {"w": 64, "h": 96, "n": 21, "ms": 80, "px": 32, "py": 86, "loop": false},
	"sword_combo": {"w": 104, "h": 64, "n": 14, "ms": 70, "px": 52, "py": 30, "loop": false},
	"hit_spark": {"w": 64, "h": 64, "n": 8, "ms": 80, "px": 32, "py": 32, "loop": false},
	"small_explosion": {"w": 64, "h": 64, "n": 14, "ms": 60, "px": 32, "py": 57, "loop": false},
	"big_explosion": {"w": 128, "h": 128, "n": 18, "ms": 70, "px": 64, "py": 113, "loop": false},
	"arrow_impact": {"w": 64, "h": 32, "n": 17, "ms": 60, "px": 50, "py": 17, "loop": false},
	"stun_stars": {"w": 48, "h": 32, "n": 16, "ms": 75, "px": 24, "py": 16, "loop": true},
	"shield_bubble": {"w": 72, "h": 88, "n": 16, "ms": 75, "px": 36, "py": 84, "loop": true},
	"ground_slam": {"w": 128, "h": 64, "n": 19, "ms": 70, "px": 64, "py": 44, "loop": false},
	"axe_smear": {"w": 128, "h": 104, "n": 9, "ms": 80, "px": 66, "py": 50, "loop": false},
}
