extends RefCounted
## Identificadores de tiles. El orden coincide con las filas de assets/tiles/wild_tiles.png (4 variantes por fila).

const DEEP := 0
const WATER := 1
const SAND := 2
const GRASS := 3
const FOREST := 4
const DESERT := 5
const STONE := 6
const GRAVEL := 7
const PATH := 8
const DFLOOR := 9
const DWALL := 10
const BFLOOR := 11
const LAVA := 12
const STAIRS := 13

const SIZE := 16
const ATLAS := "res://assets/tiles/wild_tiles.png"


static func is_solid(t: int) -> bool:
	return t == DEEP or t == WATER or t == STONE or t == DWALL or t == LAVA


static func is_land(t: int) -> bool:
	return t == GRASS or t == FOREST or t == DESERT or t == SAND or t == GRAVEL or t == PATH
