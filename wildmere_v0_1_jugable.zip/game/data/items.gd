extends RefCounted
## Objetos del juego. Los nombres visibles estan en Loc con la clave "item_<id>".

const ICON := "res://assets/items/%s.png"
const ITEMS := {
	"sword": {"kind": "weapon", "dmg": 10.0, "icon": "sword"},
	"sword2": {"kind": "weapon", "dmg": 16.0, "icon": "sword2"},
	"staff": {"kind": "weapon", "dmg": 5.0, "icon": "staff", "spell_bonus": 1.5},
	"bow": {"kind": "tool", "icon": "bow"},
	"shield": {"kind": "tool", "icon": "shield"},
	"arrow": {"kind": "ammo", "icon": "bread", "icon_path": "res://assets/props/arrow.png"},
	"potion_hp": {"kind": "consumable", "heal": 45.0, "icon": "potion_hp"},
	"potion_mp": {"kind": "consumable", "mana": 40.0, "icon": "potion_mp"},
	"apple": {"kind": "consumable", "food": 22.0, "heal": 6.0, "icon": "apple"},
	"meat": {"kind": "consumable", "food": 45.0, "heal": 10.0, "icon": "meat"},
	"tome_ice": {"kind": "tome", "spell": "ice", "icon": "key"},
	"tome_heal": {"kind": "tome", "spell": "heal", "icon": "hat"},
}
const ORDER := ["sword", "sword2", "staff", "bow", "shield", "arrow", "potion_hp", "potion_mp", "apple", "meat", "tome_ice", "tome_heal"]


static func icon_path(id: String) -> String:
	var it: Dictionary = ITEMS[id]
	if it.has("icon_path"):
		return str(it["icon_path"])
	return ICON % str(it["icon"])
