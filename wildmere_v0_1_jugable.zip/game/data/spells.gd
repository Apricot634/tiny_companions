extends RefCounted
## Hechizos. "fx" son efectos de assets/fx (PVFX Foundry, CC0).

const SPELLS := {
	"fireball": {"mana": 8.0, "dmg": 18.0, "cooldown": 0.7, "kind": "projectile", "radius": 26.0, "fx": "fireball_impact"},
	"ice": {"mana": 14.0, "dmg": 26.0, "cooldown": 1.2, "kind": "ground", "radius": 24.0, "fx": "ice_spike", "range": 44.0},
	"heal": {"mana": 16.0, "heal": 35.0, "cooldown": 1.5, "kind": "self", "fx": "holy_heal"},
}
const ORDER := ["fireball", "ice", "heal"]
