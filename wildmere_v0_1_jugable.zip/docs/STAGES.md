# Etapas

## Etapa 0 - Base: HECHA (juego anterior archivado, proyecto nuevo, compilacion Android, calibracion de joystick)

## v0.1 jugable (esta entrega, mezcla de etapas 1-3 y parte de 4-6)
Implementado (escrito; la verificacion real la hace la prueba automatica en GitHub y tu telefono):
- Arranque con logo, menu por pantallas (mundos, crear mundo, crear personaje, ajustes, creditos con iconos pixel art).
- Creacion de personaje: 12 apariencias, nombre, estilo inicial (aventurero / guerrero / mago / arquero) sin clase fija.
- Mundo por semilla con biomas, rios, aldea, cuevas, arboles, arbustos con fruta; carga y descarga de chunks.
- Combate: espada, arco, hechizos (bola de fuego, lanza de hielo, curacion), escudo, esquiva; efectos PVFX.
- Criaturas: ciervo, conejo, zorro (pacificos), jabali (territorial), lobo y hongo (hostiles), mini jefe y jefe final.
- Cuevas con cofres, arena fija del jefe final, mochila, hambre, oro, mision del anciano, curandera, dialogos.
- Guardado por mundo (hasta 8), pausa, idiomas es/en/fr.

## Siguiente
Probar en el telefono, corregir lo que salga, y luego: registros de criaturas, mas misiones, alquimia, equipo visible por capas.
