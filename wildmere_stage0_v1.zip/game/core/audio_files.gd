extends RefCounted
# Catalogo de sonidos por categoria (Kenney Interface Sounds, CC0)
const FILES := {
	"misc_bong": [
		"res://assets/audio/ui/misc_bong/bong_001.ogg"
	],
	"misc_drop": [
		"res://assets/audio/ui/misc_drop/drop_001.ogg",
		"res://assets/audio/ui/misc_drop/drop_002.ogg",
		"res://assets/audio/ui/misc_drop/drop_003.ogg",
		"res://assets/audio/ui/misc_drop/drop_004.ogg"
	],
	"misc_glass": [
		"res://assets/audio/ui/misc_glass/glass_001.ogg",
		"res://assets/audio/ui/misc_glass/glass_002.ogg",
		"res://assets/audio/ui/misc_glass/glass_003.ogg",
		"res://assets/audio/ui/misc_glass/glass_004.ogg",
		"res://assets/audio/ui/misc_glass/glass_005.ogg",
		"res://assets/audio/ui/misc_glass/glass_006.ogg"
	],
	"misc_glitch": [
		"res://assets/audio/ui/misc_glitch/glitch_001.ogg",
		"res://assets/audio/ui/misc_glitch/glitch_002.ogg",
		"res://assets/audio/ui/misc_glitch/glitch_003.ogg",
		"res://assets/audio/ui/misc_glitch/glitch_004.ogg"
	],
	"misc_pluck": [
		"res://assets/audio/ui/misc_pluck/pluck_001.ogg",
		"res://assets/audio/ui/misc_pluck/pluck_002.ogg"
	],
	"misc_scratch": [
		"res://assets/audio/ui/misc_scratch/scratch_001.ogg",
		"res://assets/audio/ui/misc_scratch/scratch_002.ogg",
		"res://assets/audio/ui/misc_scratch/scratch_003.ogg",
		"res://assets/audio/ui/misc_scratch/scratch_004.ogg",
		"res://assets/audio/ui/misc_scratch/scratch_005.ogg"
	],
	"ui_back": [
		"res://assets/audio/ui/ui_back/back_001.ogg",
		"res://assets/audio/ui/ui_back/back_002.ogg",
		"res://assets/audio/ui/ui_back/back_003.ogg",
		"res://assets/audio/ui/ui_back/back_004.ogg",
		"res://assets/audio/ui/ui_back/close_001.ogg",
		"res://assets/audio/ui/ui_back/close_002.ogg",
		"res://assets/audio/ui/ui_back/close_003.ogg",
		"res://assets/audio/ui/ui_back/close_004.ogg"
	],
	"ui_click": [
		"res://assets/audio/ui/ui_click/click_001.ogg",
		"res://assets/audio/ui/ui_click/click_002.ogg",
		"res://assets/audio/ui/ui_click/click_003.ogg",
		"res://assets/audio/ui/ui_click/click_004.ogg",
		"res://assets/audio/ui/ui_click/click_005.ogg",
		"res://assets/audio/ui/ui_click/tick_001.ogg",
		"res://assets/audio/ui/ui_click/tick_002.ogg",
		"res://assets/audio/ui/ui_click/tick_004.ogg"
	],
	"ui_close": [
		"res://assets/audio/ui/ui_close/minimize_001.ogg",
		"res://assets/audio/ui/ui_close/minimize_002.ogg",
		"res://assets/audio/ui/ui_close/minimize_003.ogg",
		"res://assets/audio/ui/ui_close/minimize_004.ogg",
		"res://assets/audio/ui/ui_close/minimize_005.ogg",
		"res://assets/audio/ui/ui_close/minimize_006.ogg",
		"res://assets/audio/ui/ui_close/minimize_007.ogg",
		"res://assets/audio/ui/ui_close/minimize_008.ogg",
		"res://assets/audio/ui/ui_close/minimize_009.ogg"
	],
	"ui_confirm": [
		"res://assets/audio/ui/ui_confirm/confirmation_001.ogg",
		"res://assets/audio/ui/ui_confirm/confirmation_002.ogg",
		"res://assets/audio/ui/ui_confirm/confirmation_003.ogg",
		"res://assets/audio/ui/ui_confirm/confirmation_004.ogg"
	],
	"ui_error": [
		"res://assets/audio/ui/ui_error/error_001.ogg",
		"res://assets/audio/ui/ui_error/error_002.ogg",
		"res://assets/audio/ui/ui_error/error_003.ogg",
		"res://assets/audio/ui/ui_error/error_004.ogg",
		"res://assets/audio/ui/ui_error/error_005.ogg",
		"res://assets/audio/ui/ui_error/error_006.ogg",
		"res://assets/audio/ui/ui_error/error_007.ogg",
		"res://assets/audio/ui/ui_error/error_008.ogg"
	],
	"ui_open": [
		"res://assets/audio/ui/ui_open/maximize_001.ogg",
		"res://assets/audio/ui/ui_open/maximize_002.ogg",
		"res://assets/audio/ui/ui_open/maximize_003.ogg",
		"res://assets/audio/ui/ui_open/maximize_004.ogg",
		"res://assets/audio/ui/ui_open/maximize_005.ogg",
		"res://assets/audio/ui/ui_open/maximize_006.ogg",
		"res://assets/audio/ui/ui_open/maximize_007.ogg",
		"res://assets/audio/ui/ui_open/maximize_008.ogg",
		"res://assets/audio/ui/ui_open/maximize_009.ogg",
		"res://assets/audio/ui/ui_open/open_001.ogg",
		"res://assets/audio/ui/ui_open/open_002.ogg",
		"res://assets/audio/ui/ui_open/open_003.ogg",
		"res://assets/audio/ui/ui_open/open_004.ogg"
	],
	"ui_question": [
		"res://assets/audio/ui/ui_question/question_001.ogg",
		"res://assets/audio/ui/ui_question/question_002.ogg",
		"res://assets/audio/ui/ui_question/question_003.ogg",
		"res://assets/audio/ui/ui_question/question_004.ogg"
	],
	"ui_scroll": [
		"res://assets/audio/ui/ui_scroll/scroll_001.ogg",
		"res://assets/audio/ui/ui_scroll/scroll_002.ogg",
		"res://assets/audio/ui/ui_scroll/scroll_003.ogg",
		"res://assets/audio/ui/ui_scroll/scroll_004.ogg",
		"res://assets/audio/ui/ui_scroll/scroll_005.ogg"
	],
	"ui_select": [
		"res://assets/audio/ui/ui_select/select_001.ogg",
		"res://assets/audio/ui/ui_select/select_002.ogg",
		"res://assets/audio/ui/ui_select/select_003.ogg",
		"res://assets/audio/ui/ui_select/select_004.ogg",
		"res://assets/audio/ui/ui_select/select_005.ogg",
		"res://assets/audio/ui/ui_select/select_006.ogg",
		"res://assets/audio/ui/ui_select/select_007.ogg",
		"res://assets/audio/ui/ui_select/select_008.ogg"
	],
	"ui_toggle": [
		"res://assets/audio/ui/ui_toggle/switch_001.ogg",
		"res://assets/audio/ui/ui_toggle/switch_002.ogg",
		"res://assets/audio/ui/ui_toggle/switch_003.ogg",
		"res://assets/audio/ui/ui_toggle/switch_004.ogg",
		"res://assets/audio/ui/ui_toggle/switch_005.ogg",
		"res://assets/audio/ui/ui_toggle/switch_006.ogg",
		"res://assets/audio/ui/ui_toggle/switch_007.ogg",
		"res://assets/audio/ui/ui_toggle/toggle_001.ogg",
		"res://assets/audio/ui/ui_toggle/toggle_002.ogg",
		"res://assets/audio/ui/ui_toggle/toggle_003.ogg",
		"res://assets/audio/ui/ui_toggle/toggle_004.ogg"
	],
}
