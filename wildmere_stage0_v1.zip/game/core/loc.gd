extends Node
## Localizacion: todos los textos visibles pasan por Loc.t(clave). Idiomas: es, en, fr.

signal language_changed

const LANGS := ["es", "en", "fr"]
const LANG_NAMES := {"es": "Español", "en": "English", "fr": "Français"}

const T := {
	"title": {"es": "Wildmere", "en": "Wildmere", "fr": "Wildmere"},
	"stage0": {"es": "Etapa 0 - base técnica", "en": "Stage 0 - technical base", "fr": "Étape 0 - base technique"},
	"test_controls": {"es": "Probar controles", "en": "Test controls", "fr": "Tester les commandes"},
	"settings": {"es": "Ajustes", "en": "Settings", "fr": "Réglages"},
	"credits": {"es": "Créditos", "en": "Credits", "fr": "Crédits"},
	"quit": {"es": "Salir", "en": "Quit", "fr": "Quitter"},
	"back": {"es": "Volver", "en": "Back", "fr": "Retour"},
	"language": {"es": "Idioma", "en": "Language", "fr": "Langue"},
	"sound": {"es": "Sonido", "en": "Sound", "fr": "Son"},
	"calibrate": {"es": "Calibrar joystick", "en": "Calibrate joystick", "fr": "Calibrer le joystick"},
	"calib_up": {"es": "Arrastra el dedo hacia ARRIBA y suéltalo", "en": "Drag your finger UP and release", "fr": "Glissez le doigt vers le HAUT puis relâchez"},
	"calib_right": {"es": "Ahora arrástralo hacia la DERECHA", "en": "Now drag it to the RIGHT", "fr": "Maintenant vers la DROITE"},
	"calib_retry": {"es": "No se detectó bien. Hazlo en línea recta", "en": "Not detected. Drag in a straight line", "fr": "Non détecté. Glissez en ligne droite"},
	"calib_done": {"es": "Listo. Ejes invertidos:", "en": "Done. Inverted axes:", "fr": "Terminé. Axes inversés :"},
	"calib_ok": {"es": "Aceptar", "en": "OK", "fr": "OK"},
	"calib_cancel": {"es": "Cancelar", "en": "Cancel", "fr": "Annuler"},
	"test_hint": {"es": "Mueve el cuadro con el joystick o con WASD / flechas", "en": "Move the square with the joystick or WASD / arrows", "fr": "Déplacez le carré avec le joystick ou WASD / flèches"},
	"test_joy": {"es": "Joystick", "en": "Joystick", "fr": "Joystick"},
	"test_move": {"es": "Movimiento", "en": "Movement", "fr": "Mouvement"},
	"credits_creator": {"es": "Creador", "en": "Creator", "fr": "Créateur"},
	"credits_social": {"es": "Plataformas oficiales", "en": "Official platforms", "fr": "Plateformes officielles"},
	"credits_third": {"es": "Recursos de terceros", "en": "Third-party resources", "fr": "Ressources tierces"},
	"credits_note": {"es": "Los créditos se ampliarán con cada recurso que se incorpore.", "en": "Credits will grow with every resource added.", "fr": "Les crédits s'étendront à chaque ressource ajoutée."},
}

var lang := "es"


func _ready() -> void:
	lang = str(Settings.data.get("lang", "es"))
	if not LANGS.has(lang):
		lang = "es"


func t(key: String) -> String:
	if not T.has(key):
		return key
	var entry: Dictionary = T[key]
	return str(entry.get(lang, entry.get("en", key)))


func set_language(l: String) -> void:
	if not LANGS.has(l):
		return
	lang = l
	Settings.set_value("lang", l)
	language_changed.emit()
