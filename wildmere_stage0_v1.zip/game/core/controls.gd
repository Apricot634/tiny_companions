extends Node
## Vector de movimiento unificado: teclado + joystick virtual.

var joy := Vector2.ZERO


func get_move() -> Vector2:
	return (Input.get_vector("move_left", "move_right", "move_up", "move_down") + joy).limit_length(1.0)
