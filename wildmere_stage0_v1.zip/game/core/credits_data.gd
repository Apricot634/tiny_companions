extends RefCounted
## Datos de creditos. Los enlaces del creador son los proporcionados por el propio creador.

const CREATOR := "Apricot634"

const LINKS := [
	{"name": "Instagram", "url": "https://instagram.com/apricot_634"},
	{"name": "Kick", "url": "https://kick.com/hjapri"},
	{"name": "Twitch", "url": "https://m.twitch.tv/hj_apri/home"},
	{"name": "YouTube", "url": "https://www.youtube.com/@Apricot634"},
	{"name": "TikTok", "url": "https://tiktok.com/@apricot.634"},
]

# Solo recursos que realmente estan incluidos en este proyecto.
const THIRD_PARTY := [
	{"name": "Interface Sounds", "author": "Kenney", "license": "CC0 1.0", "url": "https://kenney.nl"},
	{"name": "Godot Engine", "author": "Godot Engine contributors", "license": "MIT", "url": "https://godotengine.org"},
]
