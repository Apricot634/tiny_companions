extends RefCounted
## Lectura y escritura segura de JSON: temporal + validacion + copia de seguridad (.bak).
## Reutilizado del prototipo anterior; sera la base del guardado por regiones.


static func read_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if typeof(parsed) == TYPE_DICTIONARY:
		return parsed
	return {}


## Lee el archivo principal; si esta danado o falta, usa la copia .bak.
static func read_json_safe(path: String) -> Dictionary:
	var d := read_json(path)
	if d.is_empty():
		d = read_json(path + ".bak")
	return d


static func write_json_atomic(path: String, data: Dictionary) -> bool:
	var tmp := path + ".tmp"
	var bak := path + ".bak"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("SaveIO: no se pudo abrir " + tmp)
		return false
	f.store_string(JSON.stringify(data))
	f.close()
	if typeof(JSON.parse_string(FileAccess.get_file_as_string(tmp))) != TYPE_DICTIONARY:
		push_warning("SaveIO: temporal invalido, se conserva el archivo anterior")
		return false
	if FileAccess.file_exists(path):
		DirAccess.copy_absolute(path, bak)
		DirAccess.remove_absolute(path)
	return DirAccess.rename_absolute(tmp, path) == OK
