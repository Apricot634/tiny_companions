extends Node
## Sonido por eventos del juego. Cada evento apunta a una categoria del catalogo.

const AudioFiles := preload("res://core/audio_files.gd")
const EVENTS := {
	"click": "ui_click", "back": "ui_back", "confirm": "ui_confirm", "error": "ui_error",
	"open": "ui_open", "toggle": "ui_toggle", "select": "ui_select",
}
const POOL_SIZE := 6

var _players: Array[AudioStreamPlayer] = []
var _cache := {}
var _next := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)


func play(event: String) -> void:
	var cat: String = EVENTS.get(event, "")
	if cat == "" or not AudioFiles.FILES.has(cat):
		return
	var files: Array = AudioFiles.FILES[cat]
	var path: String = files[randi() % files.size()]
	if not _cache.has(path):
		_cache[path] = load(path)
	var stream: AudioStream = _cache[path]
	if stream == null:
		return
	var p := _players[_next]
	_next = (_next + 1) % POOL_SIZE
	p.stream = stream
	p.play()
