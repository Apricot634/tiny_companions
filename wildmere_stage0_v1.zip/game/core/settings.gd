extends Node
## Ajustes globales (idioma, volumen, joystick) y acciones de teclado.

signal changed

const PATH := "user://settings.json"
const SaveIO := preload("res://core/save_io.gd")

var data := {"lang": "es", "volume": 0.8, "joy_invert_x": false, "joy_invert_y": false}


func _ready() -> void:
	_setup_input_actions()
	load_settings()


func _setup_input_actions() -> void:
	var map := {
		"move_left": [KEY_A, KEY_LEFT],
		"move_right": [KEY_D, KEY_RIGHT],
		"move_up": [KEY_W, KEY_UP],
		"move_down": [KEY_S, KEY_DOWN],
		"interact": [KEY_E, KEY_ENTER],
		"pause": [KEY_ESCAPE, KEY_P],
	}
	for action in map.keys():
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for code in map[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = code
			InputMap.action_add_event(action, ev)


func load_settings() -> void:
	var d := SaveIO.read_json_safe(PATH)
	data["lang"] = str(d.get("lang", "es"))
	data["volume"] = clampf(float(d.get("volume", 0.8)), 0.0, 1.0)
	data["joy_invert_x"] = bool(d.get("joy_invert_x", false))
	data["joy_invert_y"] = bool(d.get("joy_invert_y", false))
	apply_volume()


func save_settings() -> bool:
	return SaveIO.write_json_atomic(PATH, data)


func set_value(key: String, value: Variant) -> void:
	data[key] = value
	if key == "volume":
		apply_volume()
	save_settings()
	changed.emit()


func get_bool(key: String) -> bool:
	return bool(data.get(key, false))


func apply_volume() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, float(data["volume"]))))
