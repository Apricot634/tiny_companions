extends Node
## Prueba automatica de la Etapa 0. Ejecutar: godot --headless --path . -- --autotest
## Imprime "AUTOTEST OK" o "AUTOTEST FAIL" y termina con codigo 0 / 1.

const SaveIO := preload("res://core/save_io.gd")
const CreditsData := preload("res://core/credits_data.gd")
const Calib := preload("res://ui/joystick_calibration.gd")

var ok := true
var _cal := {"x": false, "y": false}


func _check(cond: bool, label: String) -> void:
	if cond:
		print("  ok   ", label)
	else:
		print("  FAIL ", label)
		ok = false


func run() -> void:
	await get_tree().process_frame
	_test_save_io()
	_test_loc()
	_test_settings()
	await _test_menu()
	await _test_arena()
	print("AUTOTEST ", "OK" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)


func _test_save_io() -> void:
	var p := "user://autotest_save.json"
	for suffix in ["", ".bak", ".tmp"]:
		if FileAccess.file_exists(p + suffix):
			DirAccess.remove_absolute(p + suffix)
	_check(SaveIO.write_json_atomic(p, {"v": 1}), "guardar v1")
	_check(SaveIO.write_json_atomic(p, {"v": 2}), "guardar v2 (crea copia .bak)")
	_check(int(SaveIO.read_json_safe(p).get("v", 0)) == 2, "leer v2")
	var f := FileAccess.open(p, FileAccess.WRITE)
	f.store_string("{esto no es json")
	f.close()
	_check(int(SaveIO.read_json_safe(p).get("v", 0)) == 1, "archivo danado -> recupera copia .bak")


func _test_loc() -> void:
	var all_ok := true
	for key in Loc.T.keys():
		for l in Loc.LANGS:
			if str(Loc.T[key].get(l, "")) == "":
				print("  falta traduccion: ", key, " ", l)
				all_ok = false
	_check(all_ok, "todas las claves tienen es/en/fr")
	for l in Loc.LANGS:
		Loc.set_language(l)
	Loc.set_language("es")
	_check(Loc.t("settings") == "Ajustes", "cambio de idioma")


func _test_settings() -> void:
	Settings.set_value("joy_invert_x", true)
	Settings.data["joy_invert_x"] = false
	Settings.load_settings()
	_check(Settings.get_bool("joy_invert_x"), "ajuste de joystick persiste en disco")
	Settings.set_value("joy_invert_x", false)


func _test_menu() -> void:
	var menu: Control = load("res://scenes/main_menu.tscn").instantiate()
	get_tree().root.add_child(menu)
	await get_tree().process_frame
	_check(menu.screens.size() == 3, "menu: 3 pantallas (principal, ajustes, creditos)")
	_check(menu.link_buttons.size() == 5, "creditos: 5 plataformas del creador")
	var urls_ok := true
	for i in 5:
		if str(menu.link_buttons[i].get_meta("url")) != str(CreditsData.LINKS[i]["url"]):
			urls_ok = false
	_check(urls_ok, "creditos: los enlaces coinciden con los datos")
	menu._go("credits")
	_check(menu.screens["credits"].visible and not menu.screens["main"].visible, "navegar a creditos")
	Loc.set_language("en")
	_check(menu.title.text == "Wildmere", "menu se actualiza al cambiar idioma")
	Loc.set_language("es")
	menu.queue_free()
	await get_tree().process_frame


func _touch(node: Node, pressed: bool, pos: Vector2) -> void:
	var e := InputEventScreenTouch.new()
	e.index = 0
	e.position = pos
	e.pressed = pressed
	node._input(e)


func _drag(node: Node, pos: Vector2) -> void:
	var e := InputEventScreenDrag.new()
	e.index = 0
	e.position = pos
	node._input(e)


func _on_cal(ix: bool, iy: bool) -> void:
	_cal["x"] = ix
	_cal["y"] = iy


func _test_arena() -> void:
	var arena = load("res://scenes/control_test.tscn").instantiate()
	get_tree().root.add_child(arena)
	await get_tree().process_frame
	var joy: Node = arena.ui.get_child(0)
	var vp: Vector2 = joy.get_viewport_rect().size
	var o := Vector2(60.0, vp.y - 60.0)
	_touch(joy, true, o)
	_drag(joy, o + Vector2(30, 0))
	_check(Controls.joy.x > 0.5 and absf(Controls.joy.y) < 0.2, "joystick: arrastrar a la derecha da X positiva")
	var x0: float = arena.ppos.x
	arena.step(0.5)
	_check(arena.ppos.x > x0 + 20.0, "el cuadro se mueve a la derecha")
	_drag(joy, o + Vector2(0, -30))
	_check(Controls.joy.y < -0.5 and absf(Controls.joy.x) < 0.2, "joystick: arrastrar arriba da Y negativa")
	var y0: float = arena.ppos.y
	arena.step(0.5)
	_check(arena.ppos.y < y0 - 20.0, "el cuadro se mueve hacia arriba")
	Settings.data["joy_invert_y"] = true
	_drag(joy, o + Vector2(0, -30))
	_check(Controls.joy.y > 0.5, "joystick: eje Y invertido por ajuste")
	Settings.data["joy_invert_y"] = false
	_touch(joy, false, o)
	_check(Controls.joy == Vector2.ZERO, "joystick: al soltar vuelve a cero")
	Input.action_press("move_left")
	var xl: float = arena.ppos.x
	arena.step(0.5)
	Input.action_release("move_left")
	_check(arena.ppos.x < xl - 20.0, "teclado: izquierda mueve a la izquierda")
	var c = Calib.new()
	arena.ui.add_child(c)
	c.setup({}, _on_cal)
	c.feed(Vector2(0, 80))
	c.feed(Vector2(-80, 0))
	_check(_cal["y"] == true and _cal["x"] == true, "calibracion detecta ejes invertidos")
	c.queue_free()
	arena.queue_free()
	await get_tree().process_frame
