extends Node2D
## Arena de pruebas de controles (Etapa 0): un cuadro que se mueve con joystick o teclado.
## Sirve para verificar la direccion del joystick en el telefono.

const WildTheme := preload("res://ui/wild_theme.gd")
const Joystick := preload("res://ui/virtual_joystick.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const SPEED := 110.0
const LIMIT := Vector2(560, 360)

var ppos := Vector2.ZERO
var facing := Vector2.DOWN
var ui: Control
var readout: Label
var hint: Label
var back_btn: Button
var calib_btn: Button
var cam: Camera2D


func _ready() -> void:
	cam = Camera2D.new()
	cam.zoom = Vector2(2, 2)
	add_child(cam)
	cam.make_current()
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	ui = Control.new()
	ui.theme = WildTheme.make(12)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(Joystick.new())
	var panel := PanelContainer.new()
	ui.add_child(panel)
	var vb := VBoxContainer.new()
	panel.add_child(vb)
	hint = Label.new()
	readout = Label.new()
	vb.add_child(hint)
	vb.add_child(readout)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 12)
	back_btn = Button.new()
	back_btn.focus_mode = Control.FOCUS_NONE
	back_btn.custom_minimum_size = Vector2(90, 34)
	back_btn.pressed.connect(_on_back)
	calib_btn = Button.new()
	calib_btn.focus_mode = Control.FOCUS_NONE
	calib_btn.custom_minimum_size = Vector2(130, 34)
	calib_btn.pressed.connect(_on_calibrate)
	var row := HBoxContainer.new()
	row.add_child(calib_btn)
	row.add_child(back_btn)
	ui.add_child(row)
	row.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 12)
	row.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	Loc.language_changed.connect(_refresh)
	_refresh()


func _refresh() -> void:
	hint.text = Loc.t("test_hint")
	back_btn.text = Loc.t("back")
	calib_btn.text = Loc.t("calibrate")


## Avanza la simulacion (separado de _process para poder probarlo).
func step(delta: float) -> void:
	var m := Controls.get_move()
	if m.length() > 0.05:
		facing = m.normalized()
	ppos = (ppos + m * SPEED * delta).clamp(-LIMIT, LIMIT)
	cam.position = ppos
	readout.text = "%s: (%.2f, %.2f)   %s: (%.0f, %.0f)   %d FPS" % [
		Loc.t("test_joy"), Controls.joy.x, Controls.joy.y, Loc.t("test_move"), ppos.x, ppos.y,
		int(Engine.get_frames_per_second())]
	queue_redraw()


func _process(delta: float) -> void:
	step(delta)


func _draw() -> void:
	draw_rect(Rect2(-LIMIT - Vector2(16, 16), LIMIT * 2.0 + Vector2(32, 32)), Color8(44, 60, 52))
	var x := -LIMIT.x
	while x <= LIMIT.x:
		draw_line(Vector2(x, -LIMIT.y), Vector2(x, LIMIT.y), Color(1, 1, 1, 0.07), 1.0)
		x += 32.0
	var y := -LIMIT.y
	while y <= LIMIT.y:
		draw_line(Vector2(-LIMIT.x, y), Vector2(LIMIT.x, y), Color(1, 1, 1, 0.07), 1.0)
		y += 32.0
	draw_rect(Rect2(-LIMIT, LIMIT * 2.0), Color8(240, 200, 90), false, 2.0)
	# ejes de referencia: X rojo hacia la derecha, Y azul hacia abajo
	draw_line(Vector2.ZERO, Vector2(48, 0), Color8(230, 90, 90), 2.0)
	draw_line(Vector2.ZERO, Vector2(0, 48), Color8(90, 150, 230), 2.0)
	# jugador de prueba
	draw_rect(Rect2(ppos - Vector2(8, 8), Vector2(16, 16)), Color8(240, 200, 90))
	var tip := ppos + facing * 14.0
	draw_line(ppos, tip, Color8(120, 40, 20), 3.0)


func _on_back() -> void:
	Audio.play("back")
	Controls.joy = Vector2.ZERO
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _on_calibrate() -> void:
	Audio.play("click")
	var c := Calib.new()
	ui.add_child(c)
	c.setup({
		"title": Loc.t("calibrate"), "up": Loc.t("calib_up"), "right": Loc.t("calib_right"),
		"retry": Loc.t("calib_retry"), "done": Loc.t("calib_done"), "ok": Loc.t("calib_ok"),
		"cancel": Loc.t("calib_cancel"),
	}, _on_calibrated)


func _on_calibrated(ix: bool, iy: bool) -> void:
	Settings.data["joy_invert_x"] = ix
	Settings.data["joy_invert_y"] = iy
	Settings.save_settings()
	Audio.play("confirm")
