extends RefCounted
## Tema visual de Wildmere: pergamino oscuro con detalles dorados.

const BG := Color8(30, 34, 52)
const PANEL := Color8(38, 44, 66)
const GOLD := Color8(240, 200, 90)
const GOLD_DARK := Color8(150, 112, 40)
const TEXT := Color8(238, 232, 214)


static func make(font_size: int = 14) -> Theme:
	var th := Theme.new()
	th.default_font_size = font_size
	th.set_color("font_color", "Label", TEXT)
	th.set_stylebox("normal", "Button", _box(Color8(58, 68, 100), GOLD_DARK, 6, 3))
	th.set_stylebox("hover", "Button", _box(Color8(76, 88, 128), GOLD, 6, 3))
	th.set_stylebox("pressed", "Button", _box(Color8(44, 52, 80), GOLD, 6, 1))
	th.set_stylebox("disabled", "Button", _box(Color8(50, 54, 66), Color8(90, 90, 90), 6, 3))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		th.set_color(c, "Button", TEXT)
	th.set_color("font_disabled_color", "Button", Color8(130, 130, 130))
	th.set_stylebox("panel", "PanelContainer", _box(PANEL, GOLD_DARK, 8, 2))
	th.set_stylebox("slider", "HSlider", _box(Color8(20, 24, 40), GOLD_DARK, 3, 0))
	th.set_stylebox("grabber_area", "HSlider", _box(GOLD, GOLD, 3, 0))
	th.set_stylebox("grabber_area_highlight", "HSlider", _box(Color8(255, 220, 120), GOLD, 3, 0))
	return th


static func _box(bg: Color, border: Color, radius: int, bottom: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.border_width_bottom = 2 + bottom
	s.set_corner_radius_all(radius)
	s.content_margin_left = 10
	s.content_margin_right = 10
	s.content_margin_top = 5
	s.content_margin_bottom = 5 + bottom
	return s
