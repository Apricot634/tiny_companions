extends Control
## Menu principal de Wildmere (Etapa 0): prueba de controles, ajustes y creditos.
## Cada boton abre su propia pantalla.

const WildTheme := preload("res://ui/wild_theme.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const CreditsData := preload("res://core/credits_data.gd")
const TEST_SCENE := "res://scenes/control_test.tscn"

var screens := {}
var current := "main"
var title: Label
var sub: Label
var txt := {}
var lang_buttons := {}
var link_buttons: Array = []
var volume_slider: HSlider
var third_labels: Array = []


func _ready() -> void:
	get_tree().paused = false
	theme = WildTheme.make(14)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = WildTheme.BG
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	title = Label.new()
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 36)
	title.add_theme_color_override("font_color", WildTheme.GOLD)
	title.add_theme_constant_override("outline_size", 6)
	title.add_theme_color_override("font_outline_color", Color8(60, 40, 10))
	add_child(title)
	sub = Label.new()
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(sub)
	_build_main()
	_build_settings()
	_build_credits()
	resized.connect(_layout)
	Loc.language_changed.connect(_refresh)
	_show("main")
	_refresh()
	_layout()


func _layout() -> void:
	title.position = Vector2(0, 20)
	title.size = Vector2(size.x, 46)
	sub.position = Vector2(0, 64)
	sub.size = Vector2(size.x, 22)


func _button(key: String, cb: Callable, min_h: float = 34.0) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, min_h)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	txt[key] = b
	return b


func _label(key: String, big: bool = false) -> Label:
	var l := Label.new()
	if big:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", 18)
		l.add_theme_color_override("font_color", WildTheme.GOLD)
	txt[key] = l
	return l


func _screen(id: String, width: float, with_panel: bool = true) -> VBoxContainer:
	var root := CenterContainer.new()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.offset_top = 70
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(width, 0)
	vb.add_theme_constant_override("separation", 6)
	if with_panel:
		var panel := PanelContainer.new()
		root.add_child(panel)
		panel.add_child(vb)
	else:
		root.add_child(vb)
	screens[id] = root
	return vb


func _show(id: String) -> void:
	current = id
	for k in screens.keys():
		screens[k].visible = (k == id)
	sub.visible = (id == "main")


func _go(id: String) -> void:
	Audio.play("click")
	_show(id)
	_refresh()


# ------------------------------------------------------------ pantallas
func _build_main() -> void:
	var vb := _screen("main", 220, false)
	vb.add_child(_button("test_controls", _on_test, 38))
	vb.add_child(_button("settings", _go.bind("settings"), 38))
	vb.add_child(_button("credits", _go.bind("credits"), 38))
	if OS.has_feature("pc"):
		vb.add_child(_button("quit", _on_quit, 38))


func _build_settings() -> void:
	var vb := _screen("settings", 340)
	vb.add_child(_label("settings", true))
	vb.add_child(_label("language"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	for l in Loc.LANGS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 34)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.text = Loc.LANG_NAMES[l]
		b.pressed.connect(_on_pick_language.bind(l))
		row.add_child(b)
		lang_buttons[l] = b
	vb.add_child(row)
	vb.add_child(_label("sound"))
	volume_slider = HSlider.new()
	volume_slider.min_value = 0.0
	volume_slider.max_value = 1.0
	volume_slider.step = 0.1
	volume_slider.value = float(Settings.data["volume"])
	volume_slider.custom_minimum_size = Vector2(0, 24)
	volume_slider.value_changed.connect(_on_volume)
	vb.add_child(volume_slider)
	vb.add_child(_button("calibrate", _on_calibrate))
	vb.add_child(_button("back_settings", _go.bind("main")))


func _build_credits() -> void:
	var vb := _screen("credits", 400)
	vb.add_child(_label("credits", true))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 190)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 6)
	scroll.add_child(inner)
	var creator := Label.new()
	creator.name = "CreatorLabel"
	inner.add_child(_label("credits_creator"))
	creator.text = CreditsData.CREATOR
	creator.add_theme_font_size_override("font_size", 18)
	inner.add_child(creator)
	inner.add_child(_label("credits_social"))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	inner.add_child(grid)
	for link in CreditsData.LINKS:
		var b := Button.new()
		b.text = str(link["name"])
		b.custom_minimum_size = Vector2(0, 34)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.set_meta("url", str(link["url"]))
		b.pressed.connect(_on_open_link.bind(str(link["url"])))
		grid.add_child(b)
		link_buttons.append(b)
	inner.add_child(_label("credits_third"))
	for item in CreditsData.THIRD_PARTY:
		var l := Label.new()
		l.text = "%s - %s (%s)" % [str(item["name"]), str(item["author"]), str(item["license"])]
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(360, 0)
		inner.add_child(l)
		third_labels.append(l)
	var note := _label("credits_note")
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(360, 0)
	inner.add_child(note)
	vb.add_child(_button("back_credits", _go.bind("main")))


# ------------------------------------------------------------ textos
func _refresh() -> void:
	title.text = Loc.t("title")
	sub.text = Loc.t("stage0")
	var keys := {
		"test_controls": "test_controls", "settings": "settings", "credits": "credits", "quit": "quit",
		"language": "language", "sound": "sound", "calibrate": "calibrate", "back_settings": "back",
		"back_credits": "back", "credits_creator": "credits_creator", "credits_social": "credits_social",
		"credits_third": "credits_third", "credits_note": "credits_note",
	}
	for k in keys.keys():
		if txt.has(k):
			txt[k].text = Loc.t(keys[k])
	for l in lang_buttons.keys():
		var b: Button = lang_buttons[l]
		b.modulate = Color(1, 0.85, 0.4) if l == Loc.lang else Color.WHITE


# ------------------------------------------------------------ acciones
func _on_test() -> void:
	Audio.play("confirm")
	get_tree().change_scene_to_file(TEST_SCENE)


func _on_pick_language(l: String) -> void:
	Audio.play("toggle")
	Loc.set_language(l)


func _on_volume(v: float) -> void:
	Settings.set_value("volume", v)
	Audio.play("click")


func _on_open_link(url: String) -> void:
	Audio.play("click")
	OS.shell_open(url)


func _on_calibrate() -> void:
	Audio.play("click")
	var c := Calib.new()
	add_child(c)
	c.setup({
		"title": Loc.t("calibrate"), "up": Loc.t("calib_up"), "right": Loc.t("calib_right"),
		"retry": Loc.t("calib_retry"), "done": Loc.t("calib_done"), "ok": Loc.t("calib_ok"),
		"cancel": Loc.t("calib_cancel"),
	}, _on_calibrated)


func _on_calibrated(ix: bool, iy: bool) -> void:
	Settings.data["joy_invert_x"] = ix
	Settings.data["joy_invert_y"] = iy
	Settings.save_settings()
	Audio.play("confirm")


func _on_quit() -> void:
	get_tree().quit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and current != "main":
		_go("main")
