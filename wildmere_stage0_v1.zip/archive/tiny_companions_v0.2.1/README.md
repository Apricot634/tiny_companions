# Tiny Companions (nombre provisional) – v0.1.0

Juego 2D pixel art de mascotas virtuales y simulación de vida, en Godot 4.3 (GDScript).

## Estado
Ver CHANGELOG.md. Esta versión **no ha sido ejecutada en Godot** por quien la escribió
(no había Godot disponible). La prueba automática y la compilación las ejecuta GitHub Actions.

## Controles
- PC: WASD/flechas mover · E recoger · 1 alimentar · 2 acariciar · 3 dormir/despertar · Esc pausa.
- Android: joystick flotante (mitad izquierda de la pantalla), botones a la derecha, botón atrás = pausa.

## Compilar sin computadora (GitHub Actions)
1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta (rama `main`).
2. Pestaña **Actions** → "Build Tiny Companions" (se lanza solo al subir, o con "Run workflow").
3. Cuando termine, abre la ejecución y descarga en **Artifacts**:
   `TinyCompanions-Android-APK` (APK de depuración) y `TinyCompanions-Windows`.
   También se guarda `test-log` con el resultado de la prueba automática.
4. Android: descomprime el artifact, abre el .apk y permite "instalar apps desconocidas".

### Subir los archivos desde un teléfono Android
La web de GitHub no permite subir carpetas desde el móvil. Opción fiable: app **Termux**:
```
pkg install git unzip
mkdir tiny_companions && cd tiny_companions && unzip ../tiny_companions_v0.2.zip
git init -b main && git add . && git commit -m "v0.1"
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main      # pide usuario y un Personal Access Token como contraseña
```

## Estructura
- `autoload/` GameState (necesidades, guardado), Sfx (sonido por eventos), Loc (es/en/fr)
- `scripts/` main_menu, world, player, pet, autotest · `scripts/ui/` hud, joystick, tema
- `assets/` recursos organizados + `assets/_docs/` (CATALOG.md, PROVENANCE.csv, licencias)
- `.github/workflows/build.yml` pruebas + exportación Windows y Android

## Licencias de assets
Ver `assets/_docs/CATALOG.md`. PixelSpaces es solo no comercial. Tiny Wonder Farm y Harvest Sumer sin licencia verificada.
