extends Control
## Intro animada con el nombre del juego (aparece tras el logo de arranque). Tocar = saltar.

const MENU := "res://scenes/main_menu.tscn"
const TILES := [151, 170, 178, 152, 154, 165, 179]

var title: Label
var subtitle: Label
var sprites: Array = []
var _t := 0.0
var _done := false


func _ready() -> void:
	if "--autotest" in OS.get_cmdline_user_args():
		_autotest_start.call_deferred()
		return
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var sky := ColorRect.new()
	sky.color = Color8(140, 200, 240)
	add_child(sky)
	sky.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var ground := ColorRect.new()
	ground.color = Color8(165, 197, 67)
	add_child(ground)
	ground.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	ground.offset_top = -110
	title = _label(Loc.t("title"), 38)
	subtitle = _label("", 12)
	for n in TILES:
		var s := Sprite2D.new()
		s.texture = load("res://assets/creatures/tiny_creatures/tile_%04d.png" % n)
		s.centered = false
		s.offset = Vector2(-8, -16)
		s.scale = Vector2(4, 4)
		s.modulate.a = 0.0
		add_child(s)
		sprites.append(s)
	resized.connect(_layout)
	_layout()


func _label(text: String, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color8(255, 230, 120))
	l.add_theme_constant_override("outline_size", 8)
	l.add_theme_color_override("font_outline_color", Color8(96, 58, 30))
	l.modulate.a = 0.0
	add_child(l)
	return l


func _layout() -> void:
	title.position = Vector2(0, size.y * 0.2)
	title.size = Vector2(size.x, 50)


func _process(delta: float) -> void:
	if title == null:
		return
	_t += delta
	title.modulate.a = clampf(_t / 0.6, 0.0, 1.0)
	title.scale = Vector2.ONE * (0.9 + 0.1 * clampf(_t / 0.6, 0.0, 1.0))
	title.pivot_offset = title.size / 2.0
	var base_y := size.y - 70.0
	for i in sprites.size():
		var s: Sprite2D = sprites[i]
		var appear := 0.4 + i * 0.18
		s.modulate.a = clampf((_t - appear) / 0.25, 0.0, 1.0)
		s.position.x = size.x * (i + 1.0) / (sprites.size() + 1.0)
		var hop := maxf(0.0, sin((_t - appear) * 6.0)) if _t > appear else 0.0
		s.position.y = base_y - hop * 14.0
	if _t > 2.8 and not _done:
		_finish()


func _input(event: InputEvent) -> void:
	if _done:
		return
	if (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed) \
			or (event is InputEventKey and event.pressed):
		_finish()


func _finish() -> void:
	_done = true
	get_tree().change_scene_to_file(MENU)


## Solo para pruebas automaticas (CI): construye el menu y entra a un mundo nuevo.
func _autotest_start() -> void:
	var menu: Node = load(MENU).instantiate()
	add_child(menu)
	await get_tree().process_frame
	await get_tree().process_frame
	menu.queue_free()
	GameState.new_world("Test", "")
	get_tree().change_scene_to_file("res://scenes/world.tscn")
