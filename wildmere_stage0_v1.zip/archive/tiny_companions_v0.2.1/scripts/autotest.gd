extends Node
## Prueba automatica: godot --headless --path . -- --autotest
## Imprime "AUTOTEST OK" o "AUTOTEST FAIL" y cierra con codigo 0/1.

var _cal := {"x": false, "y": false}


func _on_cal(ix: bool, iy: bool) -> void:
	_cal["x"] = ix
	_cal["y"] = iy


func run(world) -> void:
	await get_tree().process_frame
	var ok := true
	GameState.pet["hunger"] = 10.0
	GameState.pet["sleeping"] = false
	world.player.position = world.pet.position
	var food_before := int(GameState.inventory["food"])
	world._on_feed()
	if not (float(GameState.pet["hunger"]) > 10.0 and int(GameState.inventory["food"]) == food_before - 1):
		print("FAIL feed"); ok = false
	var aff := float(GameState.pet["affection"])
	world._pet_cooldown = 0.0
	world._on_pet()
	if not float(GameState.pet["affection"]) > aff - 0.001:
		print("FAIL pet"); ok = false
	GameState.pet["energy"] = 40.0
	world._on_sleep()
	if not bool(GameState.pet["sleeping"]):
		print("FAIL sleep"); ok = false
	world._on_sleep()
	if bool(GameState.pet["sleeping"]):
		print("FAIL wake"); ok = false
	# pausa
	world.hud.set_paused(true)
	await get_tree().process_frame
	if not get_tree().paused:
		print("FAIL pause"); ok = false
	world.hud.set_paused(false)
	# joystick: arrastrar a la derecha debe dar X positiva y arriba Y negativa
	var joy = world.hud.joystick
	var vp: Vector2 = joy.get_viewport_rect().size
	var o := Vector2(60.0, vp.y - 60.0)
	_touch(joy, true, o)
	_drag(joy, o + Vector2(30, 0))
	if not (GameState.joy.x > 0.5 and absf(GameState.joy.y) < 0.2):
		print("FAIL joystick derecha ", GameState.joy); ok = false
	_drag(joy, o + Vector2(0, -30))
	if not (GameState.joy.y < -0.5 and absf(GameState.joy.x) < 0.2):
		print("FAIL joystick arriba ", GameState.joy); ok = false
	GameState.settings["joy_invert_x"] = true
	_drag(joy, o + Vector2(30, 0))
	if not GameState.joy.x < -0.5:
		print("FAIL joystick invertido ", GameState.joy); ok = false
	GameState.settings["joy_invert_x"] = false
	_touch(joy, false, o)
	if GameState.joy != Vector2.ZERO:
		print("FAIL joystick suelta"); ok = false
	# calibracion: un dispositivo que reporta "abajo" al arrastrar arriba debe marcar Y invertida
	var Calib = load("res://scripts/ui/joystick_calibration.gd")
	var c = Calib.new()
	world.hud.ui.add_child(c)
	_cal = {"x": false, "y": false}
	c.setup({}, _on_cal)
	c.feed(Vector2(0, 80))
	c.feed(Vector2(-80, 0))
	if not (_cal["y"] == true and _cal["x"] == true):
		print("FAIL calibracion ", _cal); ok = false
	c.queue_free()
	# guardado / carga
	var name_before := str(GameState.pet["name"])
	var seed_before := GameState.world_seed
	if not GameState.save_game():
		print("FAIL save"); ok = false
	GameState.pet = {}
	GameState.world_seed = 0
	if not GameState.load_game(GameState.current_slot) or str(GameState.pet["name"]) != name_before or GameState.world_seed != seed_before:
		print("FAIL load"); ok = false
	# idiomas
	for l in Loc.LANGS:
		Loc.set_language(l)
		await get_tree().process_frame
	Loc.set_language("es")
	print("AUTOTEST ", "OK" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)


func _touch(node, pressed: bool, pos: Vector2) -> void:
	var e := InputEventScreenTouch.new()
	e.index = 0
	e.position = pos
	e.pressed = pressed
	node._input(e)


func _drag(node, pos: Vector2) -> void:
	var e := InputEventScreenDrag.new()
	e.index = 0
	e.position = pos
	node._input(e)
