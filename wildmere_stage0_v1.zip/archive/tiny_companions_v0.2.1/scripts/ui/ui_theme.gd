extends RefCounted
## Tema visual calido y redondeado (estilo "animalito"), compartido por menu y HUD.

const CREAM := Color8(255, 244, 214)
const BROWN := Color8(96, 58, 30)
const PEACH := Color8(255, 205, 140)
const PEACH_HOVER := Color8(255, 224, 172)
const PEACH_DOWN := Color8(236, 178, 108)
const EDGE := Color8(150, 92, 44)


static func make(font_size: int = 12) -> Theme:
	var th := Theme.new()
	th.default_font_size = font_size
	th.set_color("font_color", "Label", BROWN)
	th.set_stylebox("normal", "Button", _box(PEACH, EDGE, 8, 4))
	th.set_stylebox("hover", "Button", _box(PEACH_HOVER, EDGE, 8, 4))
	th.set_stylebox("pressed", "Button", _box(PEACH_DOWN, EDGE, 8, 2))
	th.set_stylebox("disabled", "Button", _box(Color8(214, 200, 176), Color8(170, 150, 120), 8, 4))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		th.set_color(c, "Button", BROWN)
	th.set_color("font_disabled_color", "Button", Color8(130, 115, 95))
	th.set_stylebox("panel", "PanelContainer", _box(CREAM, EDGE, 12, 3))
	th.set_stylebox("background", "ProgressBar", _box(Color8(222, 205, 170), EDGE, 5, 2))
	th.set_stylebox("fill", "ProgressBar", _box(Color8(120, 190, 80), Color8(120, 190, 80), 4, 0))
	th.set_stylebox("normal", "LineEdit", _box(Color.WHITE, EDGE, 6, 2))
	th.set_stylebox("focus", "LineEdit", _box(Color.WHITE, Color8(230, 140, 40), 6, 2))
	th.set_color("font_color", "LineEdit", BROWN)
	th.set_color("font_placeholder_color", "LineEdit", Color8(170, 140, 110))
	th.set_color("caret_color", "LineEdit", BROWN)
	th.set_stylebox("slider", "HSlider", _box(Color8(222, 205, 170), EDGE, 4, 1))
	th.set_stylebox("grabber_area", "HSlider", _box(Color8(255, 170, 70), Color8(255, 170, 70), 4, 0))
	th.set_stylebox("grabber_area_highlight", "HSlider", _box(Color8(255, 190, 100), Color8(255, 190, 100), 4, 0))
	return th


static func _box(bg: Color, border: Color, radius: int, bottom: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.border_width_bottom = 2 + bottom
	s.set_corner_radius_all(radius)
	s.content_margin_left = 8
	s.content_margin_right = 8
	s.content_margin_top = 4
	s.content_margin_bottom = 4 + bottom
	return s
