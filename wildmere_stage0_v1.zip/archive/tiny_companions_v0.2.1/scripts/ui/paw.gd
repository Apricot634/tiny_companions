extends Control
## Huella de animal dibujada por codigo (decoracion).

var color := Color(0.45, 0.28, 0.15, 0.35)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(20, 20)
	size = Vector2(20, 20)


func _draw() -> void:
	draw_circle(Vector2(10, 13), 5.5, color)
	draw_circle(Vector2(3.5, 7), 2.4, color)
	draw_circle(Vector2(7.5, 3), 2.4, color)
	draw_circle(Vector2(12.5, 3), 2.4, color)
	draw_circle(Vector2(16.5, 7), 2.4, color)
