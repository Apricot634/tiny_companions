extends Control
## Calibracion del joystick. Pide arrastrar el dedo hacia ARRIBA y luego hacia la DERECHA,
## mide el vector que reporta el dispositivo y detecta ejes invertidos.
## Uso: var c := Calib.new(); add_child(c); c.setup(textos, callback(inv_x: bool, inv_y: bool))
## textos: title, up, right, retry, done, ok, cancel

const MIN_DRAG := 30.0

var texts := {}
var on_done: Callable
var step := 0                 # 0 = arriba, 1 = derecha, 2 = terminado
var inv_x := false
var inv_y := false
var _idx := -1
var _start := Vector2.ZERO
var _cur := Vector2.ZERO
var _title: Label
var _msg: Label
var _ok: Button
var _cancel: Button
var _retry := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.82)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_BEGIN
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vb)
	vb.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	vb.offset_top = 24
	vb.offset_bottom = 120
	_title = _label(vb, 18)
	_msg = _label(vb, 14)
	_cancel = Button.new()
	_cancel.focus_mode = Control.FOCUS_NONE
	_cancel.custom_minimum_size = Vector2(110, 34)
	_cancel.pressed.connect(queue_free)
	add_child(_cancel)
	_cancel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 14)
	_cancel.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_cancel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_ok = Button.new()
	_ok.focus_mode = Control.FOCUS_NONE
	_ok.custom_minimum_size = Vector2(130, 38)
	_ok.visible = false
	_ok.pressed.connect(queue_free)
	add_child(_ok)
	_ok.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 60)
	_refresh()


func _label(parent: Control, size_px: int) -> Label:
	var l := Label.new()
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_constant_override("outline_size", 4)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


func setup(t: Dictionary, cb: Callable) -> void:
	texts = t
	on_done = cb
	if is_inside_tree():
		_refresh()


func _refresh() -> void:
	if _title == null:
		return
	_title.text = str(texts.get("title", ""))
	_cancel.text = str(texts.get("cancel", "X"))
	_ok.text = str(texts.get("ok", "OK"))
	if step == 0:
		_msg.text = str(texts.get("retry", "")) if _retry else str(texts.get("up", ""))
	elif step == 1:
		_msg.text = str(texts.get("retry", "")) if _retry else str(texts.get("right", ""))
	else:
		_msg.text = "%s  X: %s   Y: %s" % [str(texts.get("done", "")), str(inv_x), str(inv_y)]
		_ok.visible = true
		_cancel.visible = false
	queue_redraw()


func _canvas(p: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * p


func _input(event: InputEvent) -> void:
	if step >= 2:
		return
	if event is InputEventScreenTouch:
		var p := _canvas(event.position)
		if event.pressed and _idx == -1:
			_idx = event.index
			_start = p
			_cur = p
			queue_redraw()
		elif not event.pressed and event.index == _idx:
			_idx = -1
			feed(_cur - _start)
	elif event is InputEventScreenDrag and event.index == _idx:
		_cur = _canvas(event.position)
		queue_redraw()
	elif not DisplayServer.is_touchscreen_available():
		# Solo para probar con raton en PC
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed and _idx == -1:
				_idx = 99
				_start = _canvas(event.position)
				_cur = _start
			elif not event.pressed and _idx == 99:
				_idx = -1
				feed(_cur - _start)
		elif event is InputEventMouseMotion and _idx == 99:
			_cur = _canvas(event.position)
			queue_redraw()


## Procesa un arrastre completo (vector crudo que reporta el dispositivo).
func feed(d: Vector2) -> void:
	if step >= 2 or d.length() < MIN_DRAG:
		return
	if step == 0:
		if absf(d.y) < absf(d.x):
			_retry = true
			_refresh()
			return
		inv_y = d.y > 0.0          # arrastrar hacia arriba deberia dar Y negativa
		step = 1
	else:
		if absf(d.x) < absf(d.y):
			_retry = true
			_refresh()
			return
		inv_x = d.x < 0.0          # arrastrar a la derecha deberia dar X positiva
		step = 2
		if on_done.is_valid():
			on_done.call(inv_x, inv_y)
	_retry = false
	_refresh()


func _draw() -> void:
	var s := size
	var c := Vector2(s.x * 0.5, s.y * 0.58)
	var dir := Vector2.UP if step == 0 else Vector2.RIGHT
	if step < 2:
		var tip := c + dir * 70.0
		draw_line(c - dir * 70.0, tip, Color(1, 0.85, 0.3, 0.9), 6.0)
		draw_line(tip, tip - dir * 22.0 + dir.orthogonal() * 14.0, Color(1, 0.85, 0.3, 0.9), 6.0)
		draw_line(tip, tip - dir * 22.0 - dir.orthogonal() * 14.0, Color(1, 0.85, 0.3, 0.9), 6.0)
	if _idx != -1:
		draw_circle(_start, 22.0, Color(1, 1, 1, 0.2))
		draw_circle(_cur, 12.0, Color(1, 1, 1, 0.6))
