# Cambios
## 0.1.0 (primera versión jugable, sin probar en Godot)
- Menú de inicio (Jugar, Nuevo mundo, Idioma es/en/fr, Créditos, Salir en PC).
- Mundo 2D con terreno, árboles, arbustos con fruta y cama generados por semilla.
- Jugador (hoja Tiny Wonder Farm) con teclado y joystick virtual.
- Mascota (Tiny Creatures) con apariencia/nombre/personalidad por semilla y 4 necesidades.
- Acciones: alimentar, acariciar, dormir/despertar, recoger fruta.
- HUD, pausa real (congela el mundo y el tiempo), guardado atómico con copia de seguridad.
- Sonidos Kenney por evento. Workflow de GitHub con prueba automática, APK y .exe.
## Pendiente conocido
- No ejecutado en Godot: pueden aparecer errores de script o recortes de sprites desalineados.
- Hoja del jugador: se asume que mira a la derecha y que la fila 1 es caminar.
- Un solo mundo guardado; sin higiene, salud, envejecimiento, NPC ni ciclo de vida.
- Pantalla táctil: no se puede mover y pulsar un botón a la vez (limitación del ratón emulado).
- Idioma de nombres de mascota fijo; sin música; Pixel Plains y UI Book sin extraer.

## 0.2.0
- ARREGLO pantalla gris: error de tipos en world.gd (Godot no cargaba el script del mundo).
- ARREGLO fondo negro de las criaturas: se regeneraron con transparencia real (originales en assets/creatures/tiny_creatures_original, ignorados por Godot).
- Pantalla completa sin franjas negras (stretch "expand"); menú y HUD se adaptan al ancho.
- Intro animada con el nombre del juego y logo de arranque propio (splash.png).
- Menú por pantallas: Jugar → Mundos (lista, borrar, crear) → Crear mundo (nombre + semilla); Ajustes (idioma, volumen); Créditos.
- Hasta 8 mundos independientes (cada uno con su guardado y copia de seguridad).
- Tema visual más "animalito": paneles crema, botones redondeados, huellas decorativas.
- El flujo de GitHub ahora ejecuta una prueba automática (test-log) sin bloquear la compilación.

## 0.2.1 (copia archivada con correccion del joystick)
- NUEVO: Ajustes y menu de pausa -> "Calibrar joystick". Pide arrastrar ARRIBA y DERECHA, mide el vector que reporta el dispositivo y activa la inversion de ejes si hace falta (se guarda en settings).
- La prueba automatica ahora simula el joystick (derecha, arriba, ejes invertidos, soltar) y la calibracion.
- La causa exacta de la inversion no se pudo confirmar sin el dispositivo; el codigo de lectura es correcto en la simulacion.
