extends Control
## Menu principal estilo "cada boton abre su propia pantalla":
## Principal -> Jugar (mundos) -> Crear mundo | Ajustes (idioma, volumen) | Creditos.

const UiTheme := preload("res://scripts/ui/ui_theme.gd")
const Paw := preload("res://scripts/ui/paw.gd")
const TREES := "res://assets/tiles/harvest_sumer/Vegetation/Trees_3.png"
const SHEET := "res://assets/characters/tiny_wonder_farm/main_character/walk_and_idle.png"
const WORLD_SCENE := "res://scenes/world.tscn"

var screens := {}
var current := "main"
var title: Label
var info: Label
var deco: Control
var tree_l: Sprite2D
var tree_r: Sprite2D
var girl: Sprite2D
var pet_sprite: Sprite2D
var paws: Array = []
var fade: ColorRect
# widgets que cambian de texto
var txt := {}                       # clave -> Label o Button
var worlds_list: VBoxContainer
var name_edit: LineEdit
var seed_edit: LineEdit
var lang_buttons := {}
var volume_slider: HSlider
var _pending_delete := -1
var _t := 0.0


func _ready() -> void:
	GameState.active = false
	get_tree().paused = false
	theme = UiTheme.make(14)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_background()
	_build_title()
	_build_main()
	_build_worlds()
	_build_create()
	_build_settings()
	_build_credits()
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fade)
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	Loc.language_changed.connect(_refresh)
	_show("main")
	_refresh()
	_layout()


# ------------------------------------------------------------ utilidades
func _atlas(path: String, rect: Rect2) -> AtlasTexture:
	var a := AtlasTexture.new()
	a.atlas = load(path)
	a.region = rect
	return a


func _deco(tex: Texture2D, scl: float) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height())
	s.scale = Vector2(scl, scl)
	deco.add_child(s)
	return s


func _button(text_key: String, cb: Callable, min_h: float = 34.0) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, min_h)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	txt[text_key] = b
	return b


func _label(text_key: String) -> Label:
	var l := Label.new()
	txt[text_key] = l
	return l


## Crea una pantalla: centrada, con un panel y una caja vertical dentro.
func _screen(id: String, width: float, with_panel: bool = true) -> VBoxContainer:
	var root := CenterContainer.new()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.offset_top = 56
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(width, 0)
	vb.add_theme_constant_override("separation", 6)
	if with_panel:
		var panel := PanelContainer.new()
		root.add_child(panel)
		panel.add_child(vb)
	else:
		root.add_child(vb)
	screens[id] = root
	return vb


func _show(id: String) -> void:
	current = id
	for k in screens.keys():
		screens[k].visible = (k == id)
	title.visible = (id == "main")
	_pending_delete = -1
	if id == "worlds":
		_rebuild_worlds()
	info.text = ""


func _go(id: String) -> void:
	Sfx.play("click")
	_show(id)
	_refresh()


# ------------------------------------------------------------ fondo y titulo
func _build_background() -> void:
	var sky := ColorRect.new()
	sky.color = Color8(140, 200, 240)
	add_child(sky)
	sky.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var ground := ColorRect.new()
	ground.color = Color8(165, 197, 67)
	add_child(ground)
	ground.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	ground.offset_top = -100
	deco = Control.new()
	deco.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(deco)
	deco.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tree_l = _deco(_atlas(TREES, Rect2(0, 0, 48, 54)), 2.0)
	tree_r = _deco(_atlas(TREES, Rect2(48, 0, 48, 54)), 2.0)
	girl = _deco(_atlas(SHEET, Rect2(0, 0, 24, 24)), 3.0)
	var tile: int = GameState.PET_TILES[randi() % GameState.PET_TILES.size()]
	pet_sprite = _deco(load("res://assets/creatures/tiny_creatures/tile_%04d.png" % tile), 4.0)
	for i in 6:
		var p := Paw.new()
		deco.add_child(p)
		p.rotation = randf_range(-0.6, 0.6)
		paws.append(p)


func _layout() -> void:
	var s := size
	tree_l.position = Vector2(s.x * 0.10, s.y - 78)
	tree_r.position = Vector2(s.x * 0.91, s.y - 82)
	girl.position = Vector2(s.x * 0.24, s.y - 22)
	for i in paws.size():
		paws[i].position = Vector2(s.x * (0.12 + 0.15 * i), s.y - 42 + (i % 2) * 14)
	title.position = Vector2(0, 22)
	title.size = Vector2(s.x, 44)
	info.position = Vector2(0, s.y - 24)
	info.size = Vector2(s.x, 20)


func _build_title() -> void:
	title = Label.new()
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", Color8(255, 230, 120))
	title.add_theme_constant_override("outline_size", 8)
	title.add_theme_color_override("font_outline_color", Color8(96, 58, 30))
	add_child(title)
	info = Label.new()
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 11)
	info.add_theme_color_override("font_color", Color.WHITE)
	info.add_theme_constant_override("outline_size", 4)
	info.add_theme_color_override("font_outline_color", Color8(96, 58, 30))
	add_child(info)


# ------------------------------------------------------------ pantallas
func _build_main() -> void:
	var vb := _screen("main", 190, false)
	vb.add_child(_button("play", _on_play, 36))
	vb.add_child(_button("settings", _go.bind("settings"), 36))
	vb.add_child(_button("credits", _go.bind("credits"), 36))
	if OS.has_feature("pc"):
		vb.add_child(_button("quit", _on_quit, 36))


func _build_worlds() -> void:
	var vb := _screen("worlds", 380)
	var t := _label("worlds")
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 18)
	vb.add_child(t)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 150)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	worlds_list = VBoxContainer.new()
	worlds_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	worlds_list.add_theme_constant_override("separation", 5)
	scroll.add_child(worlds_list)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var nb := _button("create_world", _on_open_create)
	nb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bb := _button("back_worlds", _go.bind("main"))
	bb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(nb)
	row.add_child(bb)
	vb.add_child(row)


func _build_create() -> void:
	var vb := _screen("create", 340)
	var t := _label("title_create")
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 18)
	vb.add_child(t)
	vb.add_child(_label("world_name"))
	name_edit = LineEdit.new()
	name_edit.max_length = 24
	name_edit.custom_minimum_size = Vector2(0, 30)
	vb.add_child(name_edit)
	vb.add_child(_label("seed"))
	seed_edit = LineEdit.new()
	seed_edit.max_length = 24
	seed_edit.custom_minimum_size = Vector2(0, 30)
	vb.add_child(seed_edit)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var cb := _button("create", _on_create)
	cb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bb := _button("back_create", _go.bind("worlds"))
	bb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(cb)
	row.add_child(bb)
	vb.add_child(row)


func _build_settings() -> void:
	var vb := _screen("settings", 340)
	var t := _label("title_settings")
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 18)
	vb.add_child(t)
	vb.add_child(_label("language"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	for l in Loc.LANGS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 34)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.text = Loc.LANG_NAMES[l]
		b.pressed.connect(_on_pick_language.bind(l))
		row.add_child(b)
		lang_buttons[l] = b
	vb.add_child(row)
	vb.add_child(_label("sound"))
	volume_slider = HSlider.new()
	volume_slider.min_value = 0.0
	volume_slider.max_value = 1.0
	volume_slider.step = 0.1
	volume_slider.value = float(GameState.settings["volume"])
	volume_slider.custom_minimum_size = Vector2(0, 24)
	volume_slider.value_changed.connect(_on_volume)
	vb.add_child(volume_slider)
	vb.add_child(_button("back_settings", _go.bind("main")))


func _build_credits() -> void:
	var vb := _screen("credits", 400)
	var t := _label("title_credits")
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 18)
	vb.add_child(t)
	var l := _label("credits_text")
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(380, 0)
	l.add_theme_font_size_override("font_size", 12)
	vb.add_child(l)
	vb.add_child(_button("back_credits", _go.bind("main")))


# ------------------------------------------------------------ textos
func _refresh() -> void:
	title.text = Loc.t("title")
	var keys := {
		"play": "play", "settings": "settings", "credits": "credits", "quit": "quit",
		"worlds": "worlds", "create_world": "create_world", "back_worlds": "back",
		"world_name": "world_name", "seed": "seed", "create": "create", "back_create": "back",
		"language": "language", "sound": "sound", "back_settings": "back",
		"credits_text": "credits_text", "back_credits": "back",
		"title_create": "create_world", "title_settings": "settings", "title_credits": "credits",
	}
	for k in keys.keys():
		if txt.has(k):
			txt[k].text = Loc.t(keys[k])
	name_edit.placeholder_text = Loc.t("default_world") % GameState.list_worlds().size()
	seed_edit.placeholder_text = "123456"
	for l in lang_buttons.keys():
		var b: Button = lang_buttons[l]
		b.modulate = Color(1, 0.85, 0.4) if l == Loc.lang else Color.WHITE
	if current == "worlds":
		_rebuild_worlds()


func _rebuild_worlds() -> void:
	for c in worlds_list.get_children():
		c.queue_free()
	var worlds := GameState.list_worlds()
	if worlds.is_empty():
		var l := Label.new()
		l.text = Loc.t("no_worlds")
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		worlds_list.add_child(l)
	for w in worlds:
		var slot: int = w["slot"]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		var pb := Button.new()
		pb.focus_mode = Control.FOCUS_NONE
		pb.custom_minimum_size = Vector2(0, 38)
		pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pb.alignment = HORIZONTAL_ALIGNMENT_LEFT
		pb.text = "%s  -  %s  (%s)" % [str(w["name"]), str(w["pet_name"]), Loc.t("minutes") % int(float(w["play_seconds"]) / 60.0)]
		pb.pressed.connect(_on_play_world.bind(slot))
		var db := Button.new()
		db.focus_mode = Control.FOCUS_NONE
		db.custom_minimum_size = Vector2(70 if _pending_delete == slot else 38, 38)
		db.text = Loc.t("delete_confirm") if _pending_delete == slot else "X"
		db.pressed.connect(_on_delete.bind(slot))
		row.add_child(pb)
		row.add_child(db)
		worlds_list.add_child(row)


# ------------------------------------------------------------ acciones
func _process(delta: float) -> void:
	_t += delta
	title.position.y = 22.0 + sin(_t * 2.0) * 3.0
	pet_sprite.position = Vector2(size.x * 0.76, size.y - 22.0 - absf(sin(_t * 4.0)) * 8.0)


func _go_world() -> void:
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.25)
	tw.tween_callback(func(): get_tree().change_scene_to_file(WORLD_SCENE))


func _on_play() -> void:
	Sfx.play("confirm")
	_show("worlds")
	_refresh()


func _on_open_create() -> void:
	Sfx.play("click")
	if GameState.list_worlds().size() >= GameState.MAX_WORLDS:
		Sfx.play("error")
		info.text = Loc.t("max_worlds")
		return
	name_edit.text = ""
	seed_edit.text = ""
	_show("create")
	_refresh()


func _on_create() -> void:
	Sfx.play("confirm")
	var wname := name_edit.text.strip_edges()
	if wname == "":
		wname = Loc.t("default_world") % (GameState.list_worlds().size() + 1)
	if GameState.new_world(wname, seed_edit.text):
		_go_world()
	else:
		Sfx.play("error")
		info.text = Loc.t("max_worlds")


func _on_play_world(slot: int) -> void:
	Sfx.play("confirm")
	if GameState.load_game(slot):
		_go_world()
	else:
		Sfx.play("error")
		info.text = Loc.t("load_error")


func _on_delete(slot: int) -> void:
	if _pending_delete == slot:
		Sfx.play("back")
		GameState.delete_world(slot)
		_pending_delete = -1
	else:
		Sfx.play("toggle")
		_pending_delete = slot
	_rebuild_worlds()


func _on_pick_language(l: String) -> void:
	Sfx.play("toggle")
	Loc.set_language(l)


func _on_volume(v: float) -> void:
	GameState.settings["volume"] = v
	GameState.apply_volume()
	GameState.save_settings()
	Sfx.play("click")


func _on_quit() -> void:
	get_tree().quit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and current != "main":   # atras de Android
		var back := {"worlds": "main", "create": "worlds", "settings": "main", "credits": "main"}
		_go(back.get(current, "main"))
