extends Control
## Joystick virtual flotante: aparece donde se toca dentro de ZONE (mitad izquierda inferior).
## Usa eventos tactiles reales (ScreenTouch/ScreenDrag) con seguimiento de indice.

const RADIUS := 36.0

var _idx := -1
var _origin := Vector2.ZERO
var _knob := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _zone() -> Rect2:
	var s := get_viewport_rect().size
	return Rect2(0.0, s.y * 0.33, s.x * 0.45, s.y * 0.67)


func _rest() -> Vector2:
	return Vector2(80.0, get_viewport_rect().size.y - 80.0)


func _to_canvas(p: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * p


func _input(event: InputEvent) -> void:
	if get_tree().paused:
		if _idx != -1:
			reset()
		return
	if event is InputEventScreenTouch:
		var p := _to_canvas(event.position)
		if event.pressed and _idx == -1 and _zone().has_point(p):
			_idx = event.index
			_origin = p
			_knob = Vector2.ZERO
			queue_redraw()
		elif not event.pressed and event.index == _idx:
			reset()
	elif event is InputEventScreenDrag and event.index == _idx:
		_knob = (_to_canvas(event.position) - _origin).limit_length(RADIUS)
		GameState.joy = _knob / RADIUS
		queue_redraw()


func reset() -> void:
	_idx = -1
	_knob = Vector2.ZERO
	GameState.joy = Vector2.ZERO
	queue_redraw()


func _draw() -> void:
	if _idx != -1:
		draw_circle(_origin, RADIUS, Color(1, 1, 1, 0.15))
		draw_arc(_origin, RADIUS, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 2.0)
		draw_circle(_origin + _knob, 14.0, Color(1, 1, 1, 0.55))
	elif DisplayServer.is_touchscreen_available():
		draw_arc(_rest(), RADIUS, 0.0, TAU, 32, Color(1, 1, 1, 0.25), 2.0)
		draw_circle(_rest(), 14.0, Color(1, 1, 1, 0.2))
