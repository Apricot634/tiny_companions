# Arquitectura (Etapa 0)

Detalle completo en la propuesta tecnica (documento aparte). Resumen de lo que existe hoy:

```
wildmere/
├─ archive/
│  ├─ tiny_companions_v0.2/     prototipo original, SIN modificar (respaldo)
│  └─ tiny_companions_v0.2.1/   copia con calibracion de joystick (jugable)
├─ game/                        proyecto Godot nuevo
│  ├─ core/    settings, loc, audio, controls, save_io, credits_data
│  ├─ ui/      tema, joystick virtual, calibracion, boot, menu principal
│  ├─ test_arena/  arena de prueba de controles
│  ├─ tests/   prueba automatica (--autotest)
│  └─ assets/  solo sonidos Kenney (CC0) por ahora
├─ shared/     scripts compartidos entre el prototipo y el juego nuevo
├─ docs/
└─ .github/workflows/build.yml
```

Convenciones
- Todo texto visible usa `Loc.t("clave")` (es/en/fr). La prueba automatica falla si falta una traduccion.
- Datos de creditos en un script de constantes (no en JSON) para que se exporten siempre.
- Guardado: `SaveIO.write_json_atomic` (temporal + validacion + copia .bak). Base del guardado por regiones.
- Convencion del joystick: derecha = X positiva, arriba = Y negativa. Se corrige por dispositivo con la calibracion.
