# Etapas

## Etapa 0 - Base (esta entrega)
| Punto | Estado |
|---|---|
| Juego anterior respaldado sin modificar | Hecho (`archive/tiny_companions_v0.2`) |
| Estructura nueva y proyecto Godot "Wildmere" | Escrito |
| Sistemas reutilizados (guardado, idiomas, sonido, tema, joystick) | Escrito y adaptado |
| Creditos del creador con 5 enlaces | Escrito |
| Compilacion Android + PC | Flujo escrito; **resultado pendiente de ejecutarse en GitHub** |
| Prueba automatica | Escrita; **no ejecutada por mi** (no hay Godot en mi entorno) |
| Joystick invertido del prototipo | Calibracion agregada en `archive/tiny_companions_v0.2.1`; causa exacta sin confirmar |

Criterio para cerrar la Etapa 0: el APK de Wildmere se instala, abre el arranque y el menu, y la
"prueba de controles" mueve el cuadro en la direccion correcta (con o sin calibracion).

## Siguiente: Etapa 1 - Sensacion de juego
Personaje con movimiento y controles tactiles completos sobre un mapa de prueba, camara, HUD base.
Antes: prueba visual de 2 o 3 packs de terreno juntos para elegir direccion artistica.
