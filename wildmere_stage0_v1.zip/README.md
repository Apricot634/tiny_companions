# Wildmere (nombre provisional)

RPG 2D pixel art de mundo abierto en Godot 4.3. Proyecto de uso personal por ahora.

## Que hay aqui
- `game/` - el juego nuevo (Etapa 0).
- `archive/tiny_companions_v0.2/` - prototipo anterior, sin tocar.
- `archive/tiny_companions_v0.2.1/` - el mismo prototipo con calibracion del joystick.
- `docs/` - arquitectura, etapas y licencias.

## Compilar sin computadora
1. Sube **solo el archivo** `wildmere_stage0_v1.zip` a la raiz del repositorio (Add file > Upload files).
   Si hay otros `wildmere*.zip`, se usa el de numero mayor.
2. Crea o reemplaza `.github/workflows/build.yml` con el que viene dentro del ZIP.
3. Actions > "Build Wildmere" se ejecuta al guardar. Descarga los APK desde **Artifacts**:
   `Wildmere-Android-APK` y `Prototipo-0.2.1-Android-APK` (se instalan a la vez: tienen distinto nombre de paquete).
4. En la pagina de la ejecucion, el **Summary** muestra el resultado de la prueba automatica.
