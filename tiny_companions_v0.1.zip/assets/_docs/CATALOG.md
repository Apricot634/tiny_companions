# Catálogo de assets (Etapa 1 – parcial)

| Paquete | Estado | Contenido verificado | Licencia | Uso previsto |
|---|---|---|---|---|
| Tiny Creatures | Extraído | 180 sprites 16x16 estáticos (1 frame, miran a la derecha) | CC0 | Mascotas, ganado, fauna. Animación por código (rebote, squash, flip) |
| Kenney Interface Sounds | Extraído | 100 OGG, 20 familias | CC0 | UI. Mapeados en audio/audio_events.json |
| Tiny Wonder Farm Free | Extraído | Personaje 192x72 (walk+idle), retratos 64x64, plantas, objetos de granja, muebles, tilemaps | Sin verificar | Jugador, cultivos, granja |
| PixelSpaces Free | Extraído | 129 PNG: muebles, objetos, fondos, 2 NPC | NO comercial | Interior de la casa, NPC |
| Harvest Sumer Free | PARCIAL (4/8) | Vallas, árboles, objetos, hojas cayendo | Sin verificar | Exterior |
| Pixel Plains Free | NO extraído (RAR con compresión) | - | Desconocida | Exterior |
| UI Book Styles | NO extraído (7z) | - | Desconocida | Interfaz y cursores |
| KayKit Furniture Bits | Excluido | Modelos 3D | CC0 | No usar (3D) |

## Notas
- Sin animaciones de mascota: ningún pack las trae. No hay música ni sonidos de juego (comer, dormir, animales).
- Escalas mezcladas: criaturas 16x16, resto por verificar. Usar escala entera y filtro "nearest".
- Procedencia por archivo: PROVENANCE.csv
