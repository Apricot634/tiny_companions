# Cambios
## 0.1.0 (primera versión jugable, sin probar en Godot)
- Menú de inicio (Jugar, Nuevo mundo, Idioma es/en/fr, Créditos, Salir en PC).
- Mundo 2D con terreno, árboles, arbustos con fruta y cama generados por semilla.
- Jugador (hoja Tiny Wonder Farm) con teclado y joystick virtual.
- Mascota (Tiny Creatures) con apariencia/nombre/personalidad por semilla y 4 necesidades.
- Acciones: alimentar, acariciar, dormir/despertar, recoger fruta.
- HUD, pausa real (congela el mundo y el tiempo), guardado atómico con copia de seguridad.
- Sonidos Kenney por evento. Workflow de GitHub con prueba automática, APK y .exe.
## Pendiente conocido
- No ejecutado en Godot: pueden aparecer errores de script o recortes de sprites desalineados.
- Hoja del jugador: se asume que mira a la derecha y que la fila 1 es caminar.
- Un solo mundo guardado; sin higiene, salud, envejecimiento, NPC ni ciclo de vida.
- Pantalla táctil: no se puede mover y pulsar un botón a la vez (limitación del ratón emulado).
- Idioma de nombres de mascota fijo; sin música; Pixel Plains y UI Book sin extraer.
