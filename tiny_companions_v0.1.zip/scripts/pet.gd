extends Node2D
## Mascota: sprite de res://assets/creatures/tiny_creatures (16x16, estatico).
## Las animaciones (saltito, respiracion, aplastamiento) se hacen por codigo.

const SPEED := 28.0

var sprite: Sprite2D
var emote: Label
var player: Node2D
var home := Vector2.ZERO
var bed_pos := Vector2.ZERO
var bounds := Rect2(24, 40, 912, 590)
var state := "idle"
var target := Vector2.ZERO
var timer := 1.0
var _t := 0.0
var _emote_t := 0.0
var _squash_t := 0.0
var _alert_t := 4.0
var _was_sleeping := false


func _ready() -> void:
	var tile: int = int(GameState.pet["tile"])
	sprite = Sprite2D.new()
	sprite.texture = load("res://assets/creatures/tiny_creatures/tile_%04d.png" % tile)
	sprite.centered = false
	sprite.offset = Vector2(-8, -15)
	add_child(sprite)
	emote = Label.new()
	emote.position = Vector2(-14, -34)
	emote.add_theme_font_size_override("font_size", 8)
	emote.add_theme_constant_override("outline_size", 3)
	emote.add_theme_color_override("font_outline_color", Color.BLACK)
	emote.visible = false
	add_child(emote)


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0, 0, 0, 0.25))


func _process(delta: float) -> void:
	_t += delta
	_squash_t -= delta
	if _emote_t > 0.0:
		_emote_t -= delta
		emote.position.y = -34.0 + sin(_t * 6.0) * 1.5
		if _emote_t <= 0.0:
			emote.visible = false
	if bool(GameState.pet["sleeping"]):
		_was_sleeping = true
		_sleep(delta)
		return
	if _was_sleeping:
		_was_sleeping = false
		sprite.modulate = Color.WHITE
		sprite.scale = Vector2.ONE
		state = "idle"
		timer = 1.0
	_alert_t -= delta
	if _alert_t <= 0.0:
		_alert_t = 5.0
		var low := minf(minf(float(GameState.pet["hunger"]), float(GameState.pet["energy"])), \
				minf(float(GameState.pet["happy"]), float(GameState.pet["affection"])))
		if low < 25.0:
			show_emote("!", 1.0)
	match state:
		"eat":
			timer -= delta
			sprite.position.y = -absf(sin(_t * 14.0)) * 2.0
			if timer <= 0.0:
				state = "idle"
				timer = 1.0
				sprite.position.y = 0.0
		"walk":
			if _walk(delta, SPEED):
				state = "idle"
				timer = randf_range(1.5, 4.0)
				sprite.position.y = 0.0
		_:
			timer -= delta
			sprite.position.y = 0.0
			if _squash_t <= 0.0:
				sprite.scale = Vector2(1.0, 1.0 + 0.04 * sin(_t * 3.0))
			if timer <= 0.0:
				_choose_target()


func _choose_target() -> void:
	var aff := float(GameState.pet["affection"])
	if aff > 55.0 and player != null and position.distance_to(player.position) > 90.0:
		target = player.position + Vector2(randf_range(-30, 30), randf_range(10, 30))
	else:
		var r := 60.0 if str(GameState.pet["personality"]) == "sleepy" else 120.0
		target = home + Vector2(randf_range(-r, r), randf_range(-r * 0.6, r * 0.6))
	target = target.clamp(bounds.position, bounds.end)
	sprite.scale = Vector2.ONE
	state = "walk"


## Devuelve true al llegar al destino.
func _walk(delta: float, speed: float) -> bool:
	var d := target - position
	if d.length() < 2.0:
		return true
	position += d.normalized() * minf(speed * delta, d.length())
	if absf(d.x) > 0.5:
		sprite.flip_h = d.x < 0.0   # los sprites miran a la derecha
	sprite.position.y = -absf(sin(_t * 10.0)) * 3.0
	return false


func _sleep(delta: float) -> void:
	target = bed_pos
	if position.distance_to(bed_pos) > 3.0:
		_walk(delta, SPEED * 1.6)
		return
	sprite.position.y = 0.0
	sprite.modulate = Color(0.75, 0.75, 0.9)
	sprite.scale = Vector2(1.05 + 0.03 * sin(_t * 2.0), 0.9)
	show_emote("Zzz", 0.3)


func show_emote(text: String, seconds: float) -> void:
	emote.text = text
	emote.visible = true
	_emote_t = seconds


func do_eat() -> void:
	state = "eat"
	timer = 1.3
	sprite.scale = Vector2.ONE
	show_emote("Nom!", 1.2)


func do_pet() -> void:
	_squash_t = 0.32
	var tw := create_tween()
	tw.tween_property(sprite, "scale", Vector2(1.2, 0.8), 0.08)
	tw.tween_property(sprite, "scale", Vector2(0.9, 1.15), 0.1)
	tw.tween_property(sprite, "scale", Vector2.ONE, 0.1)
	show_emote("<3", 1.0)
