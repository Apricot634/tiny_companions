extends Control
## Pantalla de inicio: titulo, Jugar, Nuevo mundo, Idioma, Creditos, Salir (solo en PC).

const UiTheme := preload("res://scripts/ui/ui_theme.gd")
const TM := "res://assets/tiles/tiny_wonder_farm/spring_farm_tilemap.png"
const TREES := "res://assets/tiles/harvest_sumer/Vegetation/Trees_3.png"
const SHEET := "res://assets/characters/tiny_wonder_farm/main_character/walk_and_idle.png"
const WORLD_SCENE := "res://scenes/world.tscn"

var title: Label
var info: Label
var btns := {}
var credits_overlay: Control
var credits_label: Label
var credits_back: Button
var pet_sprite: Sprite2D
var _confirm_new := false
var _t := 0.0


func _ready() -> void:
	GameState.active = false
	get_tree().paused = false
	theme = UiTheme.make(14)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_background()
	_build_title()
	_build_buttons()
	_build_credits()
	Loc.language_changed.connect(_refresh)
	_refresh()


func _atlas(path: String, rect: Rect2) -> AtlasTexture:
	var a := AtlasTexture.new()
	a.atlas = load(path)
	a.region = rect
	return a


func _deco(tex: Texture2D, pos: Vector2, scl: float, foot: bool = true) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	if foot:
		s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height())
	s.position = pos
	s.scale = Vector2(scl, scl)
	add_child(s)
	return s


func _build_background() -> void:
	var sky := ColorRect.new()
	sky.color = Color8(140, 200, 240)
	sky.size = Vector2(640, 360)
	add_child(sky)
	var ground := ColorRect.new()
	ground.color = Color8(165, 197, 67)
	ground.position = Vector2(0, 250)
	ground.size = Vector2(640, 110)
	add_child(ground)
	_deco(_atlas(TREES, Rect2(0, 0, 48, 54)), Vector2(70, 275), 2.0)
	_deco(_atlas(TREES, Rect2(48, 0, 48, 54)), Vector2(585, 270), 2.0)
	_deco(_atlas(SHEET, Rect2(0, 0, 24, 24)), Vector2(150, 320), 3.0)
	var tile: int = GameState.PET_TILES[randi() % GameState.PET_TILES.size()]
	pet_sprite = _deco(load("res://assets/creatures/tiny_creatures/tile_%04d.png" % tile), Vector2(490, 320), 4.0)


func _build_title() -> void:
	title = Label.new()
	title.position = Vector2(0, 24)
	title.size = Vector2(640, 44)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", Color8(255, 230, 120))
	title.add_theme_constant_override("outline_size", 8)
	title.add_theme_color_override("font_outline_color", Color8(80, 40, 20))
	add_child(title)
	info = Label.new()
	info.position = Vector2(0, 336)
	info.size = Vector2(640, 20)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 10)
	info.add_theme_constant_override("outline_size", 3)
	info.add_theme_color_override("font_outline_color", Color.BLACK)
	add_child(info)


func _build_buttons() -> void:
	var vb := VBoxContainer.new()
	vb.position = Vector2(230, 92)
	vb.custom_minimum_size = Vector2(180, 0)
	vb.add_theme_constant_override("separation", 6)
	add_child(vb)
	var defs := [["play", _on_play], ["new_world", _on_new], ["language", _on_language], ["credits", _on_credits]]
	if OS.has_feature("pc"):
		defs.append(["quit", _on_quit])
	for d in defs:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 32)
		b.focus_mode = Control.FOCUS_NONE
		var cb: Callable = d[1]
		b.pressed.connect(cb)
		vb.add_child(b)
		btns[d[0]] = b


func _build_credits() -> void:
	credits_overlay = ColorRect.new()
	(credits_overlay as ColorRect).color = Color(0, 0, 0, 0.6)
	credits_overlay.size = Vector2(640, 360)
	credits_overlay.visible = false
	add_child(credits_overlay)
	var center := CenterContainer.new()
	credits_overlay.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	panel.add_child(vb)
	credits_label = Label.new()
	credits_label.custom_minimum_size = Vector2(420, 0)
	credits_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	credits_label.add_theme_font_size_override("font_size", 12)
	vb.add_child(credits_label)
	credits_back = Button.new()
	credits_back.custom_minimum_size = Vector2(0, 30)
	credits_back.focus_mode = Control.FOCUS_NONE
	credits_back.pressed.connect(_on_credits_back)
	vb.add_child(credits_back)


func _refresh() -> void:
	title.text = Loc.t("title")
	btns["play"].text = Loc.t("play")
	btns["new_world"].text = Loc.t("new_world_confirm") if _confirm_new else Loc.t("new_world")
	btns["new_world"].visible = GameState.has_save()
	btns["language"].text = "%s: %s" % [Loc.t("language"), Loc.LANG_NAMES[Loc.lang]]
	btns["credits"].text = Loc.t("credits")
	if btns.has("quit"):
		btns["quit"].text = Loc.t("quit")
	credits_label.text = Loc.t("credits_text")
	credits_back.text = Loc.t("back")


func _process(delta: float) -> void:
	_t += delta
	title.position.y = 24.0 + sin(_t * 2.0) * 3.0
	pet_sprite.position.y = 320.0 - absf(sin(_t * 4.0)) * 8.0


func _go_world() -> void:
	get_tree().change_scene_to_file(WORLD_SCENE)


func _on_play() -> void:
	Sfx.play("confirm")
	if GameState.has_save():
		if GameState.load_game():
			_go_world()
		else:
			Sfx.play("error")
			info.text = Loc.t("load_error")
	else:
		GameState.new_world()
		_go_world()


func _on_new() -> void:
	if not _confirm_new:
		_confirm_new = true
		Sfx.play("toggle")
		_refresh()
		return
	Sfx.play("confirm")
	GameState.new_world()
	_go_world()


func _on_language() -> void:
	Sfx.play("toggle")
	Loc.next_language()


func _on_credits() -> void:
	Sfx.play("open")
	credits_overlay.visible = true


func _on_credits_back() -> void:
	Sfx.play("back")
	credits_overlay.visible = false


func _on_quit() -> void:
	get_tree().quit()
