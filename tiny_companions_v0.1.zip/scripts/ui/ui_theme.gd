extends RefCounted
## Tema visual pixel-art sencillo compartido por menu y HUD.


static func make(font_size: int = 12) -> Theme:
	var th := Theme.new()
	th.default_font_size = font_size
	th.set_stylebox("normal", "Button", _box(Color8(120, 78, 44), Color8(60, 36, 20)))
	th.set_stylebox("hover", "Button", _box(Color8(145, 98, 58), Color8(60, 36, 20)))
	th.set_stylebox("pressed", "Button", _box(Color8(90, 58, 32), Color8(40, 24, 12)))
	th.set_stylebox("disabled", "Button", _box(Color8(80, 70, 60), Color8(40, 30, 20)))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_color("font_color", "Button", Color.WHITE)
	th.set_color("font_hover_color", "Button", Color.WHITE)
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	th.set_stylebox("panel", "PanelContainer", _box(Color(0.12, 0.09, 0.06, 0.85), Color8(60, 36, 20)))
	th.set_stylebox("background", "ProgressBar", _box(Color(0.1, 0.1, 0.1, 0.8), Color8(30, 30, 30)))
	th.set_stylebox("fill", "ProgressBar", _box(Color8(110, 190, 70), Color8(110, 190, 70)))
	return th


static func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(3)
	s.content_margin_left = 6
	s.content_margin_right = 6
	s.content_margin_top = 3
	s.content_margin_bottom = 3
	return s
