extends CanvasLayer
## Interfaz durante el juego: necesidades, botones de accion, pausa, toast y joystick.

signal feed_pressed
signal pet_pressed
signal sleep_pressed
signal interact_pressed

const UiTheme := preload("res://scripts/ui/ui_theme.gd")
const Joystick := preload("res://scripts/ui/virtual_joystick.gd")
const ITEMS := "res://assets/objects/tiny_wonder_farm/items_free.png"
const NEED_KEYS := ["hunger", "energy", "happy", "affection"]
const NEED_LOC := {"hunger": "need_hunger", "energy": "need_energy", "happy": "need_happy", "affection": "need_affection"}

var ui: Control
var bars := {}
var need_labels := {}
var name_label: Label
var food_label: Label
var btn := {}
var pause_overlay: Control
var pause_title: Label
var pause_btns := {}
var volume_label: Label
var toast_label: Label
var joystick   # Control (virtual_joystick.gd)
var _toast_t := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	ui = Control.new()
	ui.theme = UiTheme.make(11)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	joystick = Joystick.new()
	ui.add_child(joystick)
	_build_status()
	_build_buttons()
	_build_toast()
	_build_pause()
	Loc.language_changed.connect(_refresh_texts)
	GameState.needs_changed.connect(_refresh_needs)
	_refresh_texts()


# ------------------------------------------------------------ construccion
func _build_status() -> void:
	var panel := PanelContainer.new()
	ui.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	panel.add_child(vb)
	name_label = Label.new()
	vb.add_child(name_label)
	for k in NEED_KEYS:
		var row := HBoxContainer.new()
		var lbl := Label.new()
		lbl.custom_minimum_size = Vector2(62, 0)
		var bar := ProgressBar.new()
		bar.custom_minimum_size = Vector2(70, 10)
		bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		bar.show_percentage = false
		bar.max_value = 100.0
		row.add_child(lbl)
		row.add_child(bar)
		vb.add_child(row)
		bars[k] = bar
		need_labels[k] = lbl
	var frow := HBoxContainer.new()
	var icon := TextureRect.new()
	var at := AtlasTexture.new()
	at.atlas = load(ITEMS)
	at.region = Rect2(48, 0, 16, 16)
	icon.texture = at
	icon.custom_minimum_size = Vector2(16, 16)
	food_label = Label.new()
	frow.add_child(icon)
	frow.add_child(food_label)
	vb.add_child(frow)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 6)


func _make_button(id: String, min_size: Vector2) -> Button:
	var b := Button.new()
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	btn[id] = b
	return b


func _build_buttons() -> void:
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	ui.add_child(grid)
	var defs := [["feed", feed_pressed], ["pet", pet_pressed], ["sleep", sleep_pressed], ["interact", interact_pressed]]
	for d in defs:
		var b := _make_button(d[0], Vector2(68, 40))
		var sig: Signal = d[1]
		b.pressed.connect(_on_action_button.bind(sig))
		grid.add_child(b)
	grid.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT, Control.PRESET_MODE_MINSIZE, 6)
	grid.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	grid.grow_vertical = Control.GROW_DIRECTION_BEGIN
	var pb := _make_button("pause", Vector2(40, 32))
	pb.text = "II"
	pb.pressed.connect(func(): set_paused(true))
	ui.add_child(pb)
	pb.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 6)
	pb.grow_horizontal = Control.GROW_DIRECTION_BEGIN


func _build_toast() -> void:
	toast_label = Label.new()
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.add_theme_font_size_override("font_size", 13)
	toast_label.add_theme_constant_override("outline_size", 4)
	toast_label.add_theme_color_override("font_outline_color", Color.BLACK)
	toast_label.modulate.a = 0.0
	ui.add_child(toast_label)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	toast_label.offset_top = 44
	toast_label.offset_bottom = 66


func _build_pause() -> void:
	pause_overlay = ColorRect.new()
	(pause_overlay as ColorRect).color = Color(0, 0, 0, 0.55)
	pause_overlay.visible = false
	ui.add_child(pause_overlay)
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	pause_overlay.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 5)
	vb.custom_minimum_size = Vector2(170, 0)
	panel.add_child(vb)
	pause_title = Label.new()
	pause_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(pause_title)
	var defs := {
		"resume": _on_resume,
		"save": _on_save,
		"language": _on_language,
		"main_menu": _on_main_menu,
	}
	for id in defs.keys():
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 32)
		b.focus_mode = Control.FOCUS_NONE
		var cb: Callable = defs[id]
		b.pressed.connect(cb)
		vb.add_child(b)
		pause_btns[id] = b
	volume_label = Label.new()
	vb.add_child(volume_label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.1
	slider.value = float(GameState.settings["volume"])
	slider.custom_minimum_size = Vector2(0, 20)
	slider.value_changed.connect(_on_volume)
	vb.add_child(slider)


# ------------------------------------------------------------ logica
func set_paused(v: bool) -> void:
	if get_tree().paused == v:
		return
	get_tree().paused = v
	pause_overlay.visible = v
	joystick.reset()
	Sfx.play("open" if v else "back")
	if v:
		GameState.save_game()


func _on_action_button(sig: Signal) -> void:
	Sfx.play("click")
	sig.emit()


func _on_resume() -> void:
	set_paused(false)


func _on_language() -> void:
	Sfx.play("toggle")
	Loc.next_language()


func _on_volume(v: float) -> void:
	GameState.settings["volume"] = v
	GameState.apply_volume()
	GameState.save_settings()


func _on_save() -> void:
	if GameState.save_game():
		Sfx.play("confirm")
		toast("saved")
	else:
		Sfx.play("error")
		toast("save_failed")


func _on_main_menu() -> void:
	GameState.save_game()
	GameState.active = false
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func toast(key: String) -> void:
	toast_label.text = Loc.t(key)
	_toast_t = 2.2


func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		toast_label.modulate.a = clampf(_toast_t / 0.5, 0.0, 1.0)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		set_paused(not get_tree().paused)
		get_viewport().set_input_as_handled()
		return
	if get_tree().paused:
		return
	if event.is_action_pressed("act_feed"):
		feed_pressed.emit()
	elif event.is_action_pressed("act_pet"):
		pet_pressed.emit()
	elif event.is_action_pressed("act_sleep"):
		sleep_pressed.emit()
	elif event.is_action_pressed("interact"):
		interact_pressed.emit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:   # boton atras de Android
		set_paused(not get_tree().paused)


# ------------------------------------------------------------ textos / datos
func _refresh_texts() -> void:
	for k in NEED_KEYS:
		need_labels[k].text = Loc.t(NEED_LOC[k])
	btn["feed"].text = Loc.t("feed")
	btn["pet"].text = Loc.t("pet")
	btn["interact"].text = Loc.t("interact")
	pause_title.text = Loc.t("pause")
	pause_btns["resume"].text = Loc.t("resume")
	pause_btns["save"].text = Loc.t("save")
	pause_btns["language"].text = "%s: %s" % [Loc.t("language"), Loc.LANG_NAMES[Loc.lang]]
	pause_btns["main_menu"].text = Loc.t("main_menu")
	volume_label.text = Loc.t("volume")
	_refresh_needs()


func _refresh_needs() -> void:
	var p: Dictionary = GameState.pet
	if p.is_empty():
		return
	name_label.text = "%s - %s" % [str(p["name"]), Loc.t("personality_" + str(p["personality"]))]
	for k in NEED_KEYS:
		var v := float(p[k])
		var bar: ProgressBar = bars[k]
		bar.value = v
		bar.modulate = Color(1, 0.45, 0.45) if v < 25.0 else Color.WHITE
	food_label.text = "x %d" % int(GameState.inventory["food"])
	btn["sleep"].text = Loc.t("wake") if bool(p["sleeping"]) else Loc.t("sleep")
