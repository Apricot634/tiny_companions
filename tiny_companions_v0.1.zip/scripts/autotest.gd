extends Node
## Prueba automatica: godot --headless --path . -- --autotest
## Imprime "AUTOTEST OK" o "AUTOTEST FAIL" y cierra con codigo 0/1.

func run(world) -> void:
	await get_tree().process_frame
	var ok := true
	GameState.pet["hunger"] = 10.0
	GameState.pet["sleeping"] = false
	world.player.position = world.pet.position
	var food_before := int(GameState.inventory["food"])
	world._on_feed()
	if not (float(GameState.pet["hunger"]) > 10.0 and int(GameState.inventory["food"]) == food_before - 1):
		print("FAIL feed"); ok = false
	var aff := float(GameState.pet["affection"])
	world._pet_cooldown = 0.0
	world._on_pet()
	if not float(GameState.pet["affection"]) > aff - 0.001:
		print("FAIL pet"); ok = false
	GameState.pet["energy"] = 40.0
	world._on_sleep()
	if not bool(GameState.pet["sleeping"]):
		print("FAIL sleep"); ok = false
	world._on_sleep()
	if bool(GameState.pet["sleeping"]):
		print("FAIL wake"); ok = false
	# pausa
	world.hud.set_paused(true)
	await get_tree().process_frame
	if not get_tree().paused:
		print("FAIL pause"); ok = false
	world.hud.set_paused(false)
	# guardado / carga
	var name_before := str(GameState.pet["name"])
	var seed_before := GameState.world_seed
	if not GameState.save_game():
		print("FAIL save"); ok = false
	GameState.pet = {}
	GameState.world_seed = 0
	if not GameState.load_game() or str(GameState.pet["name"]) != name_before or GameState.world_seed != seed_before:
		print("FAIL load"); ok = false
	# idiomas
	for l in Loc.LANGS:
		Loc.set_language(l)
		await get_tree().process_frame
	Loc.set_language("es")
	print("AUTOTEST ", "OK" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)
