extends Node2D
## Primer mundo jugable: terreno generado por semilla, arbustos con fruta, cama y mascota.

const WORLD := Rect2(0, 0, 960, 640)
const TM := "res://assets/tiles/tiny_wonder_farm/spring_farm_tilemap.png"
const TREES := "res://assets/tiles/harvest_sumer/Vegetation/Trees_3.png"
const BED := "res://assets/furniture/pixelspaces/Bedroom/Bed_red.png"
const ITEMS := "res://assets/objects/tiny_wonder_farm/items_free.png"
const GRASS := Color8(165, 197, 67)
const NEAR_PET := 44.0
const NEAR_BUSH := 36.0
const REGROW_SECONDS := 75.0

const PlayerScript := preload("res://scripts/player.gd")
const PetScript := preload("res://scripts/pet.gd")
const HudScript := preload("res://scripts/ui/hud.gd")
const AutoTest := preload("res://scripts/autotest.gd")

var player   # CharacterBody2D (scripts/player.gd)
var pet      # Node2D (scripts/pet.gd)
var hud      # CanvasLayer (scripts/ui/hud.gd)
var objects: Node2D
var home := Vector2(480, 330)
var bed_pos := Vector2(556, 300)
var bush_list: Array = []        # [{ "key": String, "pos": Vector2, "fruit": Sprite2D }]
var _pet_cooldown := 0.0


func _ready() -> void:
	get_tree().paused = false
	if not GameState.active:
		GameState.new_world()
	_build_ground()
	_build_objects()
	_spawn_actors()
	hud = HudScript.new()
	add_child(hud)
	hud.feed_pressed.connect(_on_feed)
	hud.pet_pressed.connect(_on_pet)
	hud.sleep_pressed.connect(_on_sleep)
	hud.interact_pressed.connect(_on_interact)
	hud.toast("hint_start")
	if "--autotest" in OS.get_cmdline_user_args():
		var at := AutoTest.new()
		add_child(at)
		at.run(self)


# ------------------------------------------------------------ construccion
func _atlas(path: String, rect: Rect2) -> AtlasTexture:
	var a := AtlasTexture.new()
	a.atlas = load(path)
	a.region = rect
	return a


func _spr(tex: Texture2D, pos: Vector2, parent: Node, foot: bool = false) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = tex
	s.centered = false
	if foot:
		s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height() + 3.0)
	s.position = pos
	parent.add_child(s)
	return s


func _build_ground() -> void:
	var bg := ColorRect.new()
	bg.color = GRASS
	bg.position = WORLD.position - Vector2(200, 200)
	bg.size = WORLD.size + Vector2(400, 400)
	add_child(bg)
	var flat := Node2D.new()
	add_child(flat)
	var dirt := _spr(_atlas(TM, Rect2(80, 176, 48, 48)), home - Vector2(48, 48), flat)
	dirt.scale = Vector2(2, 2)
	var rng := RandomNumberGenerator.new()
	rng.seed = GameState.world_seed
	var flowers := _atlas(TM, Rect2(0, 0, 32, 48))
	for i in 9:
		var p := Vector2(rng.randf_range(10, WORLD.size.x - 40), rng.randf_range(10, WORLD.size.y - 60))
		if p.distance_to(home) > 80.0:
			_spr(flowers, p, flat)
	_spr(load(BED), bed_pos - Vector2(12, 12), flat)


func _too_close(p: Vector2, taken: Array, d: float) -> bool:
	for q in taken:
		if p.distance_to(q) < d:
			return true
	return false


func _build_objects() -> void:
	objects = Node2D.new()
	objects.y_sort_enabled = true
	add_child(objects)
	var rng := RandomNumberGenerator.new()
	rng.seed = GameState.world_seed + 1
	var taken: Array = [home, bed_pos]
	var big_trees := [_atlas(TREES, Rect2(0, 0, 48, 54)), _atlas(TREES, Rect2(48, 0, 48, 54))]
	var placed := 0
	var tries := 0
	while placed < 26 and tries < 800:
		tries += 1
		var p := Vector2(rng.randf_range(24, WORLD.size.x - 24), rng.randf_range(50, WORLD.size.y - 12))
		if p.distance_to(home) < 135.0 or _too_close(p, taken, 36.0):
			continue
		taken.append(p)
		placed += 1
		_add_solid(_atlas_pick(big_trees, rng), p)
	var bush_tex := [_atlas(TREES, Rect2(98, 14, 30, 50)), _atlas(TREES, Rect2(128, 14, 30, 50))]
	var fruit_tex := _atlas(ITEMS, Rect2(48, 0, 16, 16))
	var idx := 0
	tries = 0
	while idx < 5 and tries < 800:
		tries += 1
		var p := Vector2(rng.randf_range(40, WORLD.size.x - 40), rng.randf_range(60, WORLD.size.y - 12))
		var d := p.distance_to(home)
		if d < 90.0 or d > 280.0 or _too_close(p, taken, 40.0):
			continue
		taken.append(p)
		var body := _add_solid(_atlas_pick(bush_tex, rng), p)
		var fruit := _spr(fruit_tex, Vector2(-8, -34), body)
		bush_list.append({"key": str(idx), "pos": p, "fruit": fruit})
		idx += 1


func _atlas_pick(list: Array, rng: RandomNumberGenerator) -> AtlasTexture:
	return list[rng.randi() % list.size()]


func _add_solid(tex: Texture2D, p: Vector2) -> StaticBody2D:
	var body := StaticBody2D.new()
	body.position = p
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(12, 7)
	cs.shape = r
	cs.position = Vector2(0, -3)
	body.add_child(cs)
	_spr(tex, Vector2.ZERO, body, true)
	objects.add_child(body)
	return body


func _spawn_actors() -> void:
	player = PlayerScript.new()
	player.position = GameState.player_pos.clamp(Vector2(16, 28), Vector2(944, 632))
	objects.add_child(player)
	var cam := Camera2D.new()
	cam.zoom = Vector2(2, 2)
	cam.position = Vector2(0, -12)
	cam.limit_left = int(WORLD.position.x)
	cam.limit_top = int(WORLD.position.y)
	cam.limit_right = int(WORLD.end.x)
	cam.limit_bottom = int(WORLD.end.y)
	cam.position_smoothing_enabled = true
	player.add_child(cam)
	cam.make_current()
	pet = PetScript.new()
	pet.home = home
	pet.bed_pos = bed_pos
	pet.player = player
	pet.position = home + Vector2(30, 10)
	objects.add_child(pet)


# ------------------------------------------------------------ bucle
func _process(delta: float) -> void:
	_pet_cooldown -= delta
	for b in bush_list:
		var ready_fruit: bool = float(GameState.bushes.get(b["key"], 0.0)) <= 0.0
		(b["fruit"] as Sprite2D).visible = ready_fruit


# ------------------------------------------------------------ acciones
func _near_pet() -> bool:
	return player.position.distance_to(pet.position) < NEAR_PET


func _fail(key: String) -> void:
	Sfx.play("error")
	hud.toast(key)


func _on_feed() -> void:
	if not _near_pet():
		_fail("too_far")
		return
	if bool(GameState.pet["sleeping"]):
		_fail("pet_sleeping")
		return
	if int(GameState.inventory["food"]) <= 0:
		_fail("no_food")
		return
	if float(GameState.pet["hunger"]) >= 95.0:
		_fail("pet_full")
		return
	GameState.add_food(-1)
	GameState.change_need("hunger", 30.0)
	GameState.change_need("happy", 3.0)
	pet.do_eat()
	Sfx.play("feed")
	hud.toast("fed")


func _on_pet() -> void:
	if not _near_pet():
		_fail("too_far")
		return
	if bool(GameState.pet["sleeping"]):
		_fail("pet_sleeping")
		return
	if _pet_cooldown > 0.0:
		return
	_pet_cooldown = 0.8
	var pers := str(GameState.pet["personality"])
	GameState.change_need("affection", 6.0 if pers == "shy" else 10.0)
	GameState.change_need("happy", 12.0 if pers == "playful" else 8.0)
	pet.do_pet()
	Sfx.play("pet")
	hud.toast("petted")


func _on_sleep() -> void:
	if bool(GameState.pet["sleeping"]):
		GameState.pet["sleeping"] = false
		GameState.needs_changed.emit()
		Sfx.play("wake")
		hud.toast("woke")
		return
	if not _near_pet():
		_fail("too_far")
		return
	if float(GameState.pet["energy"]) > 85.0:
		_fail("not_tired")
		return
	GameState.pet["sleeping"] = true
	GameState.needs_changed.emit()
	Sfx.play("sleep")
	hud.toast("sleep_start")


func _on_interact() -> void:
	var best: Dictionary = {}
	var best_d := NEAR_BUSH
	for b in bush_list:
		var d := player.position.distance_to(b["pos"])
		if d < best_d:
			best_d = d
			best = b
	if best.is_empty():
		_fail("nothing_here")
		return
	if float(GameState.bushes.get(best["key"], 0.0)) > 0.0:
		_fail("bush_empty")
		return
	GameState.bushes[best["key"]] = REGROW_SECONDS
	GameState.add_food(1)
	Sfx.play("collect")
	hud.toast("collected")
