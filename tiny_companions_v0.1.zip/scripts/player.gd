extends CharacterBody2D
## Jugador: movimiento top-down con teclado (WASD/flechas) o joystick virtual.
## Hoja de sprites: walk_and_idle.png, celdas de 24x24 (fila 0 = idle x4, fila 1 = caminar x8).

const SHEET := "res://assets/characters/tiny_wonder_farm/main_character/walk_and_idle.png"
const CELL := 24
const SPEED := 75.0

var anim: AnimatedSprite2D
var bounds := Rect2(16, 28, 928, 604)


func _ready() -> void:
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	var cs := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 5.0
	cs.shape = circle
	cs.position = Vector2(0, -3)
	add_child(cs)
	var tex: Texture2D = load(SHEET)
	var frames := SpriteFrames.new()
	_add_anim(frames, "idle", tex, 0, 4, 4.0)
	_add_anim(frames, "walk", tex, 1, 8, 10.0)
	anim = AnimatedSprite2D.new()
	anim.sprite_frames = frames
	anim.centered = false
	anim.offset = Vector2(-12, -22)
	add_child(anim)
	anim.play("idle")


func _add_anim(frames: SpriteFrames, anim_name: String, tex: Texture2D, row: int, count: int, fps: float) -> void:
	if frames.has_animation(anim_name):
		frames.remove_animation(anim_name)
	frames.add_animation(anim_name)
	frames.set_animation_speed(anim_name, fps)
	frames.set_animation_loop(anim_name, true)
	for i in count:
		var at := AtlasTexture.new()
		at.atlas = tex
		at.region = Rect2(i * CELL, row * CELL, CELL, CELL)
		frames.add_frame(anim_name, at)


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0, 0, 0, 0.25))


func _physics_process(_delta: float) -> void:
	var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down") + GameState.joy
	dir = dir.limit_length(1.0)
	velocity = dir * SPEED
	move_and_slide()
	position = position.clamp(bounds.position, bounds.end)
	GameState.player_pos = position
	if dir.length() > 0.1:
		if anim.animation != "walk":
			anim.play("walk")
		if absf(dir.x) > 0.1:
			anim.flip_h = dir.x < 0.0
	elif anim.animation != "idle":
		anim.play("idle")
