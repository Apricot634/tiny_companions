extends Node
## Localizacion: todos los textos visibles pasan por Loc.t(clave). Idiomas: es, en, fr.

signal language_changed

const LANGS := ["es", "en", "fr"]
const LANG_NAMES := {"es": "Español", "en": "English", "fr": "Français"}

const T := {
	"title": {"es": "Compañeros Diminutos", "en": "Tiny Companions", "fr": "Petits Compagnons"},
	"play": {"es": "Jugar", "en": "Play", "fr": "Jouer"},
	"new_world": {"es": "Nuevo mundo", "en": "New world", "fr": "Nouveau monde"},
	"new_world_confirm": {"es": "Toca otra vez: borra el mundo actual", "en": "Tap again: erases current world", "fr": "Encore une fois : efface le monde"},
	"language": {"es": "Idioma", "en": "Language", "fr": "Langue"},
	"credits": {"es": "Créditos", "en": "Credits", "fr": "Crédits"},
	"quit": {"es": "Salir", "en": "Quit", "fr": "Quitter"},
	"back": {"es": "Volver", "en": "Back", "fr": "Retour"},
	"credits_text": {
		"es": "Arte: Tiny Creatures (Clint Bellanger, CC0), Tiny Wonder Farm, PixelSpaces, Harvest Sumer.\nSonidos: Kenney Interface Sounds (CC0).\nMotor: Godot 4.\nVersión provisional.",
		"en": "Art: Tiny Creatures (Clint Bellanger, CC0), Tiny Wonder Farm, PixelSpaces, Harvest Sumer.\nSounds: Kenney Interface Sounds (CC0).\nEngine: Godot 4.\nProvisional version.",
		"fr": "Art : Tiny Creatures (Clint Bellanger, CC0), Tiny Wonder Farm, PixelSpaces, Harvest Sumer.\nSons : Kenney Interface Sounds (CC0).\nMoteur : Godot 4.\nVersion provisoire.",
	},
	"load_error": {"es": "No se pudo leer el guardado", "en": "Could not read the save", "fr": "Sauvegarde illisible"},
	"pause": {"es": "Pausa", "en": "Paused", "fr": "Pause"},
	"resume": {"es": "Continuar", "en": "Resume", "fr": "Reprendre"},
	"save": {"es": "Guardar", "en": "Save", "fr": "Sauvegarder"},
	"saved": {"es": "Partida guardada", "en": "Game saved", "fr": "Partie sauvegardée"},
	"save_failed": {"es": "Error al guardar", "en": "Save failed", "fr": "Échec de la sauvegarde"},
	"main_menu": {"es": "Menú principal", "en": "Main menu", "fr": "Menu principal"},
	"volume": {"es": "Volumen", "en": "Volume", "fr": "Volume"},
	"need_hunger": {"es": "Saciedad", "en": "Fullness", "fr": "Satiété"},
	"need_energy": {"es": "Energía", "en": "Energy", "fr": "Énergie"},
	"need_happy": {"es": "Felicidad", "en": "Happiness", "fr": "Bonheur"},
	"need_affection": {"es": "Cariño", "en": "Affection", "fr": "Affection"},
	"feed": {"es": "Alimentar", "en": "Feed", "fr": "Nourrir"},
	"pet": {"es": "Acariciar", "en": "Pet", "fr": "Caresser"},
	"sleep": {"es": "Dormir", "en": "Sleep", "fr": "Dormir"},
	"wake": {"es": "Despertar", "en": "Wake up", "fr": "Réveiller"},
	"interact": {"es": "Recoger", "en": "Gather", "fr": "Cueillir"},
	"too_far": {"es": "Acércate a tu mascota", "en": "Get closer to your pet", "fr": "Approchez-vous de votre animal"},
	"no_food": {"es": "Sin comida. Recoge fruta de los arbustos", "en": "No food. Gather fruit from the bushes", "fr": "Plus de nourriture. Cueillez des fruits"},
	"pet_full": {"es": "No tiene hambre", "en": "Not hungry", "fr": "N'a pas faim"},
	"pet_sleeping": {"es": "Está durmiendo", "en": "It is sleeping", "fr": "Il dort"},
	"not_tired": {"es": "No tiene sueño", "en": "Not sleepy", "fr": "N'a pas sommeil"},
	"fed": {"es": "¡Ñam!", "en": "Yum!", "fr": "Miam !"},
	"petted": {"es": "¡Le encanta!", "en": "It loves it!", "fr": "Il adore !"},
	"sleep_start": {"es": "A dormir...", "en": "Time to sleep...", "fr": "Au dodo..."},
	"woke": {"es": "Se despertó", "en": "Woke up", "fr": "Réveillé"},
	"collected": {"es": "+1 comida", "en": "+1 food", "fr": "+1 nourriture"},
	"nothing_here": {"es": "Aquí no hay nada", "en": "Nothing here", "fr": "Rien ici"},
	"bush_empty": {"es": "Aún no hay frutos", "en": "No fruit yet", "fr": "Pas encore de fruits"},
	"hint_start": {"es": "Muévete y acércate a tu mascota", "en": "Move and get close to your pet", "fr": "Déplacez-vous près de votre animal"},
	"personality_curious": {"es": "curiosa", "en": "curious", "fr": "curieuse"},
	"personality_shy": {"es": "tímida", "en": "shy", "fr": "timide"},
	"personality_sleepy": {"es": "dormilona", "en": "sleepy", "fr": "dormeuse"},
	"personality_playful": {"es": "juguetona", "en": "playful", "fr": "joueuse"},
}

var lang := "es"


func _ready() -> void:
	lang = str(GameState.settings.get("lang", "es"))
	if not LANGS.has(lang):
		lang = "es"


func t(key: String) -> String:
	if not T.has(key):
		return key
	var entry: Dictionary = T[key]
	return str(entry.get(lang, entry.get("en", key)))


func set_language(l: String) -> void:
	if not LANGS.has(l):
		return
	lang = l
	GameState.settings["lang"] = l
	GameState.save_settings()
	language_changed.emit()


func next_language() -> void:
	set_language(LANGS[(LANGS.find(lang) + 1) % LANGS.size()])
