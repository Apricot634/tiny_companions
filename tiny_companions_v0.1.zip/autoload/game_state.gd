extends Node
## Estado global: mascota, necesidades, inventario, ajustes y guardado.
## Guardado atomico: se escribe a un temporal, se valida, se rota la copia .bak y se renombra.

signal needs_changed

const SAVE_PATH := "user://world_1.json"
const BACKUP_PATH := "user://world_1.bak.json"
const TMP_PATH := "user://world_1.tmp"
const SETTINGS_PATH := "user://settings.json"
const SAVE_VERSION := 1

# Indices de tiles de res://assets/creatures/tiny_creatures (verificados visualmente)
const PET_TILES := [151, 152, 153, 154, 170, 178, 179, 161, 165, 157]
const PET_NAMES := ["Mochi", "Nube", "Pipo", "Tofu", "Bruma", "Canela", "Lumi", "Nuez", "Bigotes", "Chispa"]
const PERSONALITIES := ["curious", "shy", "sleepy", "playful"]

const DECAY_HUNGER := 0.16   # puntos por segundo
const DECAY_ENERGY := 0.09
const DECAY_HAPPY := 0.10
const DECAY_AFFECTION := 0.07
const SLEEP_RECOVERY := 3.5
const OFFLINE_CAP_SECONDS := 4 * 3600
const OFFLINE_FACTOR := 0.2     # fuera de la app los cambios son mas suaves
const NEED_FLOOR_OFFLINE := 20.0

var settings := {"lang": "es", "volume": 0.8}
var world_seed: int = 0
var pet: Dictionary = {}
var inventory := {"food": 3}
var player_pos := Vector2(480, 330)
var bushes := {}              # "idx" -> segundos restantes para rebrotar
var play_seconds: float = 0.0
var active := false           # true cuando hay un mundo en curso
var joy := Vector2.ZERO       # vector del joystick virtual

var _emit_t := 0.0
var _autosave_t := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	_setup_input_actions()
	load_settings()


# ---------------------------------------------------------------- input
func _setup_input_actions() -> void:
	var map := {
		"move_left": [KEY_A, KEY_LEFT],
		"move_right": [KEY_D, KEY_RIGHT],
		"move_up": [KEY_W, KEY_UP],
		"move_down": [KEY_S, KEY_DOWN],
		"interact": [KEY_E, KEY_ENTER],
		"act_feed": [KEY_1],
		"act_pet": [KEY_2],
		"act_sleep": [KEY_3],
		"pause": [KEY_ESCAPE, KEY_P],
	}
	for action in map.keys():
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for code in map[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = code
			InputMap.action_add_event(action, ev)


# ---------------------------------------------------------------- mundo
func new_world() -> void:
	randomize()
	world_seed = randi()
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed
	pet = {
		"name": PET_NAMES[rng.randi() % PET_NAMES.size()],
		"tile": PET_TILES[rng.randi() % PET_TILES.size()],
		"personality": PERSONALITIES[rng.randi() % PERSONALITIES.size()],
		"hunger": 80.0, "energy": 90.0, "happy": 75.0, "affection": 60.0,
		"sleeping": false, "age_seconds": 0.0,
	}
	inventory = {"food": 3}
	player_pos = Vector2(480, 330)
	bushes = {}
	play_seconds = 0.0
	active = true
	save_game()


func change_need(key: String, amount: float) -> void:
	pet[key] = clampf(float(pet[key]) + amount, 0.0, 100.0)
	needs_changed.emit()


func add_food(n: int) -> void:
	inventory["food"] = maxi(0, int(inventory["food"]) + n)
	needs_changed.emit()


func _process(delta: float) -> void:
	if not active or pet.is_empty():
		return
	play_seconds += delta
	pet["age_seconds"] = float(pet["age_seconds"]) + delta
	var sleeping: bool = pet["sleeping"]
	var pers: String = pet["personality"]
	var f_energy := 1.5 if pers == "sleepy" else 1.0
	var f_happy := 1.5 if pers == "playful" else 1.0
	var f_aff := 1.6 if pers == "shy" else 1.0
	if float(pet["hunger"]) < 25.0:
		f_happy *= 2.0
	var f_sleep := 0.5 if sleeping else 1.0
	pet["hunger"] = clampf(float(pet["hunger"]) - DECAY_HUNGER * f_sleep * delta, 0.0, 100.0)
	pet["happy"] = clampf(float(pet["happy"]) - DECAY_HAPPY * f_happy * f_sleep * delta, 0.0, 100.0)
	pet["affection"] = clampf(float(pet["affection"]) - DECAY_AFFECTION * f_aff * f_sleep * delta, 0.0, 100.0)
	if sleeping:
		pet["energy"] = clampf(float(pet["energy"]) + SLEEP_RECOVERY * delta, 0.0, 100.0)
		if float(pet["energy"]) >= 100.0:
			pet["sleeping"] = false
	else:
		pet["energy"] = clampf(float(pet["energy"]) - DECAY_ENERGY * f_energy * delta, 0.0, 100.0)
		if float(pet["energy"]) <= 5.0:
			pet["sleeping"] = true   # se duerme de agotamiento
	for k in bushes.keys():
		bushes[k] = maxf(0.0, float(bushes[k]) - delta)
	_emit_t += delta
	if _emit_t >= 0.25:
		_emit_t = 0.0
		needs_changed.emit()
	_autosave_t += delta
	if _autosave_t >= 30.0:
		_autosave_t = 0.0
		save_game()


# ---------------------------------------------------------------- guardado
func to_dict() -> Dictionary:
	return {
		"version": SAVE_VERSION,
		"saved_unix": Time.get_unix_time_from_system(),
		"seed": world_seed,
		"pet": pet,
		"inventory": inventory,
		"player_pos": [player_pos.x, player_pos.y],
		"bushes": bushes,
		"play_seconds": play_seconds,
	}


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH) or FileAccess.file_exists(BACKUP_PATH)


func save_game() -> bool:
	if not active or pet.is_empty():
		return false
	var txt := JSON.stringify(to_dict())
	var f := FileAccess.open(TMP_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("No se pudo abrir el temporal de guardado")
		return false
	f.store_string(txt)
	f.close()
	if typeof(JSON.parse_string(FileAccess.get_file_as_string(TMP_PATH))) != TYPE_DICTIONARY:
		push_warning("Guardado temporal invalido; se conserva el anterior")
		return false
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.copy_absolute(SAVE_PATH, BACKUP_PATH)
		DirAccess.remove_absolute(SAVE_PATH)
	return DirAccess.rename_absolute(TMP_PATH, SAVE_PATH) == OK


func load_game() -> bool:
	for path in [SAVE_PATH, BACKUP_PATH]:
		if not FileAccess.file_exists(path):
			continue
		var data = JSON.parse_string(FileAccess.get_file_as_string(path))
		if typeof(data) == TYPE_DICTIONARY and data.has("pet") and data.has("seed"):
			_apply(data)
			return true
	return false


func _apply(d: Dictionary) -> void:
	world_seed = int(d["seed"])
	pet = d["pet"]
	for k in ["hunger", "energy", "happy", "affection", "age_seconds"]:
		pet[k] = float(pet.get(k, 50.0))
	pet["sleeping"] = bool(pet.get("sleeping", false))
	pet["tile"] = int(pet.get("tile", 151))
	pet["personality"] = str(pet.get("personality", "curious"))
	pet["name"] = str(pet.get("name", "Mochi"))
	var inv: Dictionary = d.get("inventory", {"food": 3})
	inventory = {"food": int(inv.get("food", 3))}
	var pp: Array = d.get("player_pos", [480.0, 330.0])
	player_pos = Vector2(float(pp[0]), float(pp[1]))
	bushes = d.get("bushes", {})
	play_seconds = float(d.get("play_seconds", 0.0))
	# Cambio suave por el tiempo transcurrido fuera de la app
	var elapsed := clampf(Time.get_unix_time_from_system() - float(d.get("saved_unix", 0.0)), 0.0, OFFLINE_CAP_SECONDS)
	var e := elapsed * OFFLINE_FACTOR
	if pet["sleeping"]:
		pet["energy"] = clampf(float(pet["energy"]) + SLEEP_RECOVERY * e, 0.0, 100.0)
		if float(pet["energy"]) >= 100.0:
			pet["sleeping"] = false
	else:
		pet["energy"] = maxf(NEED_FLOOR_OFFLINE, float(pet["energy"]) - DECAY_ENERGY * e)
	pet["hunger"] = maxf(NEED_FLOOR_OFFLINE, float(pet["hunger"]) - DECAY_HUNGER * e)
	pet["happy"] = maxf(NEED_FLOOR_OFFLINE, float(pet["happy"]) - DECAY_HAPPY * e)
	pet["affection"] = maxf(NEED_FLOOR_OFFLINE, float(pet["affection"]) - DECAY_AFFECTION * e)
	active = true


# ---------------------------------------------------------------- ajustes
func load_settings() -> void:
	if FileAccess.file_exists(SETTINGS_PATH):
		var data = JSON.parse_string(FileAccess.get_file_as_string(SETTINGS_PATH))
		if typeof(data) == TYPE_DICTIONARY:
			settings["lang"] = str(data.get("lang", "es"))
			settings["volume"] = clampf(float(data.get("volume", 0.8)), 0.0, 1.0)
	apply_volume()


func save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))
		f.close()


func apply_volume() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, float(settings["volume"]))))


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if active:
			save_game()
