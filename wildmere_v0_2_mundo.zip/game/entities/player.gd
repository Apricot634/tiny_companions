extends Node2D
## Jugador: movimiento (lento en agua), espada/hacha/lanza, arco y hechizos que se cargan manteniendo el boton,
## escudo, esquiva. El arma solo se ve al usarla (no flota).

const Appearances := preload("res://data/appearances.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")
const T := preload("res://data/tiles.gd")
const BOW_FULL := 0.8
const SPELL_FULL := 1.0

var world = null
var habitat := "player"
var facing := Vector2.DOWN
var sprite: Sprite2D
var weapon_spr: Sprite2D
var shield_spr: Sprite2D
var moving := false
var dead := false
var blocking := false
var attack_cd := 0.0
var bow_cd := 0.0
var spell_cd := 0.0
var dash_t := 0.0
var dash_cd := 0.0
var invuln := 0.0
var speed := 80.0
var poison_t := 0.0
var bow_charge := -1.0
var spell_charge := -1.0
var _anim_t := 0.0
var _swing_t := 0.0
var _flash := 0.0
var _slash_t := 0.0
var _slash_dir := Vector2.DOWN
var _poison_tick := 0.0
var _show_weapon_t := 0.0
var _weapon_id := ""


func _ready() -> void:
	add_to_group("player")
	sprite = Sprite2D.new()
	sprite.texture = load(Appearances.SHEET % GameState.appearance)
	sprite.hframes = 3
	sprite.vframes = 4
	sprite.centered = false
	sprite.offset = Vector2(-8, -19)
	sprite.frame = 1
	add_child(sprite)
	weapon_spr = Sprite2D.new()
	weapon_spr.visible = false
	add_child(weapon_spr)
	shield_spr = Sprite2D.new()
	shield_spr.texture = load(Items.icon_path("shield"))
	shield_spr.visible = false
	add_child(shield_spr)
	speed = float(Appearances.STYLES[GameState.style]["speed"])
	refresh_weapon()


func refresh_weapon() -> void:
	_weapon_id = GameState.weapon_id()
	if _weapon_id != "" and Items.ITEMS.has(_weapon_id):
		weapon_spr.texture = load(Items.icon_path(_weapon_id))


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0, 0, 0, 0.25))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if blocking:
		draw_arc(Vector2(0, -9), 13.0, facing.angle() - 1.0, facing.angle() + 1.0, 10, Color(0.5, 0.85, 1.0, 0.9), 2.0)
	if _slash_t > 0.0:
		var a := _slash_dir.angle()
		var k := _slash_t / 0.18
		draw_arc(Vector2(0, -9), 18.0, a - 1.1, a + 1.1, 14, Color(1, 1, 1, k * 0.9), 3.0)
		draw_arc(Vector2(0, -9), 22.0, a - 0.9, a + 0.9, 14, Color(0.8, 0.9, 1, k * 0.5), 2.0)
	if bow_charge >= 0.0:
		var f := clampf(bow_charge / BOW_FULL, 0.0, 1.0)
		draw_arc(Vector2(0, -26), 6.0, -PI / 2.0, -PI / 2.0 + TAU * f, 16, Color(1, 0.9, 0.4, 0.95), 2.0)
		draw_line(Vector2(0, -9) + facing * 6.0, Vector2(0, -9) + facing * (10.0 + 10.0 * f), Color(0.75, 0.55, 0.3), 1.5)
	if spell_charge >= 0.0:
		var f2 := clampf(spell_charge / SPELL_FULL, 0.0, 1.0)
		draw_arc(Vector2(0, -26), 6.0, -PI / 2.0, -PI / 2.0 + TAU * f2, 16, Color(0.6, 0.8, 1.0, 0.95), 2.0)
		draw_circle(Vector2(0, -9) + facing * 9.0, 2.0 + 3.0 * f2, Color(0.7, 0.85, 1.0, 0.7))


func _process(delta: float) -> void:
	if dead:
		return
	attack_cd = maxf(0.0, attack_cd - delta)
	bow_cd = maxf(0.0, bow_cd - delta)
	spell_cd = maxf(0.0, spell_cd - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	invuln = maxf(0.0, invuln - delta)
	_swing_t = maxf(0.0, _swing_t - delta)
	_show_weapon_t = maxf(0.0, _show_weapon_t - delta)
	if _slash_t > 0.0:
		_slash_t = maxf(0.0, _slash_t - delta)
	if _flash > 0.0:
		_flash -= delta
		if _flash <= 0.0:
			sprite.modulate = Color.WHITE
	if poison_t > 0.0:
		poison_t -= delta
		_poison_tick -= delta
		sprite.modulate = Color(0.7, 1.0, 0.7)
		if _poison_tick <= 0.0:
			_poison_tick = 1.0
			GameState.hp = maxf(1.0, GameState.hp - 2.0)
	if bow_charge >= 0.0:
		bow_charge = minf(bow_charge + delta, BOW_FULL + 0.3)
	if spell_charge >= 0.0:
		spell_charge = minf(spell_charge + delta, SPELL_FULL + 0.3)
	var move := Vector2.ZERO
	if not world.input_locked():
		move = Controls.get_move()
	var tile := world.chunk_view.tile_at_px(position)
	var spd := (speed + GameState.speed_bonus()) * T.speed_mult(tile)
	if blocking or bow_charge >= 0.0 or spell_charge >= 0.0:
		spd *= 0.55
	if dash_t > 0.0:
		dash_t -= delta
		move = facing
		spd = 220.0
	moving = move.length() > 0.1
	if moving:
		if dash_t <= 0.0:
			facing = move.normalized()
		world.move_entity(self, move.limit_length(1.0) * spd * delta, 4.0)
		_anim_t += delta
	else:
		_anim_t = 0.0
	GameState.pos = position
	_update_visuals()
	queue_redraw()


func aim_at(v: Vector2) -> void:
	if v.length() > 0.1:
		facing = v.normalized()


func _row_for_facing() -> int:
	if absf(facing.x) > absf(facing.y):
		return Appearances.ROW_RIGHT if facing.x > 0.0 else Appearances.ROW_LEFT
	return Appearances.ROW_DOWN if facing.y > 0.0 else Appearances.ROW_UP


func _update_visuals() -> void:
	var cols := [1, 0, 1, 2]
	var col := 1
	if moving:
		col = cols[int(_anim_t * 8.0) % 4]
	sprite.frame = _row_for_facing() * 3 + col
	var show_w := _swing_t > 0.0 or bow_charge >= 0.0 or spell_charge >= 0.0 or _show_weapon_t > 0.0
	weapon_spr.visible = show_w
	if show_w:
		var id := _weapon_id
		if bow_charge >= 0.0:
			id = "bow"
		if id != "" and Items.ITEMS.has(id):
			weapon_spr.texture = load(Items.icon_path(id))
		var rot := facing.angle() + PI / 4.0
		if _swing_t > 0.0:
			rot += lerpf(0.9, -0.9, 1.0 - _swing_t / 0.22)
		weapon_spr.rotation = rot
		weapon_spr.position = facing * 7.0 + Vector2(0, -8)
		weapon_spr.scale = Vector2(0.75, 0.75)
		var behind := facing.y < -0.5
		move_child(weapon_spr, 0 if behind else get_child_count() - 1)
	shield_spr.visible = blocking
	shield_spr.position = facing * 7.0 + Vector2(0, -8)


# ------------------------------------------------------------ acciones
func do_attack() -> void:
	if dead or blocking or attack_cd > 0.0 or world.input_locked():
		return
	var wid := GameState.weapon_id()
	var it: Dictionary = Items.ITEMS[wid] if wid != "" and Items.ITEMS.has(wid) else {}
	attack_cd = 0.3 if bool(it.get("fast", false)) else 0.42
	_swing_t = 0.22
	_slash_t = 0.18
	_slash_dir = facing
	var dmg: float = float(it.get("dmg", 3.0))
	var reach: float = float(it.get("reach", 30.0))
	var hits: Array = world.creatures_in_cone(position, facing, reach)
	for c in hits:
		c.take_damage(dmg, position, 70.0)
	world.hit_harvest(position + Vector2(0, -4), facing, float(it.get("chop", 1.0)))
	Audio.play("attack")


func begin_bow() -> void:
	if dead or blocking or bow_cd > 0.0 or world.input_locked():
		return
	if str(GameState.equipped["ranged"]) != "bow":
		world.hud.toast("need_bow_equipped")
		Audio.play("error")
		return
	if not GameState.has_item("arrow"):
		world.hud.toast("need_arrows")
		Audio.play("error")
		return
	bow_charge = 0.0


func release_bow() -> void:
	if bow_charge < 0.0:
		return
	var power := clampf(bow_charge / BOW_FULL, 0.25, 1.0)
	bow_charge = -1.0
	if dead or not GameState.remove_item("arrow", 1):
		return
	bow_cd = 0.35
	_show_weapon_t = 0.25
	var sp := 150.0 + 150.0 * power
	world.spawn_projectile("arrow", position + Vector2(0, -8) + facing * 8.0, facing, 5.0 + 9.0 * power, 26.0, sp)
	Audio.play("attack")


func begin_spell() -> void:
	if dead or blocking or spell_cd > 0.0 or world.input_locked():
		return
	var sid := GameState.selected_spell
	if sid == "":
		world.hud.toast("need_spell")
		Audio.play("error")
		return
	var sp: Dictionary = Spells.SPELLS[sid]
	if GameState.mp < float(sp["mana"]):
		world.hud.toast("no_mana")
		Audio.play("error")
		return
	spell_charge = 0.0


func release_spell() -> void:
	if spell_charge < 0.0:
		return
	var power := 1.0 + clampf(spell_charge / SPELL_FULL, 0.0, 1.0) * 0.6
	spell_charge = -1.0
	var sid := GameState.selected_spell
	if dead or sid == "" or not Spells.SPELLS.has(sid):
		return
	var sp: Dictionary = Spells.SPELLS[sid]
	if GameState.mp < float(sp["mana"]):
		return
	GameState.mp -= float(sp["mana"])
	GameState.add_magic_xp(float(sp["mana"]) * 0.6)
	spell_cd = float(sp["cooldown"])
	_swing_t = 0.22
	_show_weapon_t = 0.4
	var dmg := float(sp.get("dmg", 0.0)) * GameState.spell_bonus() * power
	match str(sp["kind"]):
		"projectile":
			world.spawn_projectile("fireball", position + Vector2(0, -8) + facing * 8.0, facing, dmg, float(sp["radius"]) * power)
		"ground":
			var tgt := position + facing * float(sp["range"])
			world.spawn_fx(str(sp["fx"]), tgt, 0.0, 0.7)
			get_tree().create_timer(0.45).timeout.connect(_delayed_area.bind(tgt, dmg, float(sp["radius"])))
		"self":
			GameState.heal(float(sp["heal"]) * GameState.spell_bonus() * power)
			world.spawn_fx(str(sp["fx"]), position, 0.0, 0.6)
		"chain":
			var targets: Array = world.nearest_creatures(position, float(sp["radius"]), 3)
			for c in targets:
				world.spawn_fx(str(sp["fx"]), c.position, 0.0, 0.6)
				c.take_damage(dmg, position, 40.0)
		"meteor":
			var tgt2 := position + facing * float(sp["range"])
			world.spawn_fx(str(sp["fx"]), tgt2, 0.0, 0.9)
			get_tree().create_timer(0.7).timeout.connect(_delayed_area.bind(tgt2, dmg, float(sp["radius"])))
		"nova":
			world.spawn_fx(str(sp["fx"]), position, 0.0, 0.9)
			world.area_damage(position, float(sp["radius"]), dmg, true)
			GameState.heal(float(sp["heal"]) * power)
	Audio.play("spell")


func _delayed_area(tgt: Vector2, dmg: float, radius: float) -> void:
	if is_instance_valid(world):
		world.area_damage(tgt, radius, dmg, true)


func set_block(v: bool) -> void:
	if v and str(GameState.equipped["offhand"]) != "shield":
		world.hud.toast("need_shield_equipped")
		Audio.play("error")
		return
	blocking = v and not dead
	shield_spr.visible = blocking
	queue_redraw()


func do_dash() -> void:
	if dead or dash_cd > 0.0 or world.input_locked():
		return
	dash_cd = 0.9
	dash_t = 0.18
	invuln = 0.3


func take_damage(amount: float, from_pos: Vector2) -> void:
	if dead or invuln > 0.0:
		return
	var dmg := maxf(1.0, amount - GameState.defense())
	var from_dir := (from_pos - position).normalized()
	if blocking and from_dir.dot(facing) > 0.0:
		dmg *= 0.2
		world.spawn_fx("hit_spark", position + facing * 10.0 + Vector2(0, -8), 0.0, 0.5)
		Audio.play("block")
	else:
		sprite.modulate = Color(1, 0.4, 0.4)
		_flash = 0.15
		Audio.play("hurt")
		world.move_entity(self, -from_dir * 5.0, 4.0)
	GameState.hp -= dmg
	invuln = 0.7
	if GameState.hp <= 0.0:
		GameState.hp = 0.0
		dead = true
		blocking = false
		bow_charge = -1.0
		spell_charge = -1.0
		sprite.modulate = Color(0.6, 0.6, 0.6)
		world.on_player_died()
