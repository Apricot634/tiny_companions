extends Node2D
## Proyectiles: flecha y bola de fuego del jugador; flechas, fuego y sombra de los enemigos.

var world = null
var dir := Vector2.RIGHT
var speed := 230.0
var dmg := 8.0
var kind := "arrow"
var radius := 26.0
var life := 1.2
var _t := 0.0
var _arrow_tex: Texture2D = null


func is_enemy() -> bool:
	return kind.begins_with("enemy")


func _ready() -> void:
	if kind == "arrow" or kind == "enemy_arrow":
		_arrow_tex = load("res://assets/props/arrow.png")
		rotation = dir.angle()
	if is_enemy() and kind != "enemy_arrow":
		speed = 105.0
		life = 3.0
	z_index = 3


func _process(delta: float) -> void:
	_t += delta
	life -= delta
	position += dir * speed * delta
	if kind != "arrow" and kind != "enemy_arrow":
		queue_redraw()
	if world == null:
		queue_free()
		return
	if world.chunk_view.is_blocked_px(position):
		_impact(null)
		return
	if is_enemy():
		if not world.player_dead() and position.distance_to(world.player.position + Vector2(0, -8)) < 8.0:
			world.damage_player(dmg, position - dir * 6.0)
			world.spawn_fx("hit_spark", position, 0.0, 0.5)
			queue_free()
			return
	else:
		var c = world.creature_at(position, 5.0)
		if c != null:
			_impact(c)
			return
	if life <= 0.0:
		if kind == "fireball":
			_impact(null)
		else:
			queue_free()


func _impact(target) -> void:
	if is_enemy():
		world.spawn_fx("hit_spark", position, 0.0, 0.5)
	elif kind == "arrow":
		if target != null:
			target.take_damage(dmg, position - dir * 4.0, 50.0)
		world.spawn_fx("arrow_impact", position, 0.0, 0.6)
	else:
		world.area_damage(position, radius, dmg, true)
		world.spawn_fx("fireball_impact", position + Vector2(0, 6), 0.0, 0.55)
	queue_free()


func _draw() -> void:
	if kind == "arrow" or kind == "enemy_arrow":
		if _arrow_tex != null:
			draw_texture(_arrow_tex, Vector2(-7, -3))
		return
	var f := 1.0 + 0.15 * sin(_t * 30.0)
	var c1 := Color(1.0, 0.45, 0.1, 0.55)
	var c2 := Color(1.0, 0.7, 0.2, 0.9)
	if kind == "enemy_shadow":
		c1 = Color(0.5, 0.2, 0.8, 0.55)
		c2 = Color(0.75, 0.45, 1.0, 0.9)
	draw_circle(Vector2.ZERO, 6.0 * f, c1)
	draw_circle(Vector2.ZERO, 4.0 * f, c2)
	draw_circle(Vector2.ZERO, 2.0, Color(1.0, 0.95, 0.8, 1.0))
	draw_circle(-dir * 6.0, 3.0, Color(c1.r, c1.g, c1.b, 0.4))
