extends Node2D
## Habitante con nombre propio, rol, dialogos que cambian y rutina: los de exterior caminan por la aldea
## (de noche se quedan cerca de casa); comerciantes, posaderos, herreros y maestros se quedan en su puesto.

const Appearances := preload("res://data/appearances.gd")
const STATIONARY := ["merchant", "innkeeper", "smith", "mage", "witch", "elder", "guard", "healer", "bard"]

var role := "villager"
var npc_name := ""
var nid := ""
var skin := 6
var village := ""
var vname := ""
var indoor := false
var talk_count := 0
var sprite: Sprite2D
var home := Vector2.ZERO
var target := Vector2.ZERO
var timer := 1.0
var moving := false
var facing_row := 0
var _t := 0.0
var _anim := 0.0
var world = null


func setup(o: Dictionary) -> void:
	role = str(o.get("role", "villager"))
	npc_name = str(o.get("name", ""))
	nid = str(o.get("id", ""))
	skin = int(o.get("skin", 6))
	village = str(o.get("village", ""))
	vname = str(o.get("vname", ""))
	indoor = bool(o.get("indoor", false))


func _ready() -> void:
	sprite = Sprite2D.new()
	sprite.texture = load(Appearances.SHEET % skin)
	sprite.hframes = 3
	sprite.vframes = 4
	sprite.centered = false
	sprite.offset = Vector2(-8, -19)
	sprite.frame = Appearances.ROW_DOWN * 3 + 1
	add_child(sprite)
	home = position
	target = position
	timer = randf_range(0.5, 3.0)
	add_to_group("npcs")


func is_stationary() -> bool:
	return STATIONARY.has(role)


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 7.0, Color(0, 0, 0, 0.25))


func _process(delta: float) -> void:
	_t += delta
	var p = get_tree().get_first_node_in_group("player")
	var row := facing_row
	if p != null:
		var d: Vector2 = p.position - position
		if d.length() < 60.0 and not moving:
			if absf(d.x) > absf(d.y):
				row = Appearances.ROW_RIGHT if d.x > 0.0 else Appearances.ROW_LEFT
			else:
				row = Appearances.ROW_DOWN if d.y > 0.0 else Appearances.ROW_UP
	moving = false
	if not is_stationary() and world != null:
		timer -= delta
		if timer <= 0.0 and position.distance_to(target) < 3.0:
			var radius := 40.0
			if world.is_night() and not indoor:
				radius = 12.0
			target = home + Vector2(randf_range(-radius, radius), randf_range(-radius * 0.6, radius * 0.6))
			timer = randf_range(2.0, 6.0)
		if position.distance_to(target) >= 3.0:
			var dir := (target - position).normalized()
			var before := position
			world.move_entity(self, dir * 22.0 * delta, 4.0)
			if position.distance_to(before) < 0.1:
				target = position
			moving = true
			if absf(dir.x) > absf(dir.y):
				row = Appearances.ROW_RIGHT if dir.x > 0.0 else Appearances.ROW_LEFT
			else:
				row = Appearances.ROW_DOWN if dir.y > 0.0 else Appearances.ROW_UP
			facing_row = row
	var col := 1
	if moving:
		_anim += delta
		col = [1, 0, 1, 2][int(_anim * 6.0) % 4]
	sprite.frame = row * 3 + col
	sprite.position.y = 0.0 if moving else -absf(sin(_t * 2.0)) * 0.5
