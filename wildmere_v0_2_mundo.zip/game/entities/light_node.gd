extends PointLight2D
## Luz puntual con textura radial generada por codigo (antorchas, hogueras, cristales, jugador).

static var _tex: Texture2D = null


static func radial_texture() -> Texture2D:
	if _tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 256
		t.height = 256
		_tex = t
	return _tex


func setup(radius_px: float, light_energy: float, light_color: Color = Color(1.0, 0.82, 0.55)) -> void:
	texture = radial_texture()
	texture_scale = radius_px / 128.0
	energy = light_energy
	color = light_color
	shadow_enabled = false


func set_radius(radius_px: float) -> void:
	texture_scale = radius_px / 128.0
