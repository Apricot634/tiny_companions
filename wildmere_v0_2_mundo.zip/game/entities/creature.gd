extends Node2D
## Criatura dirigida por datos (data/species.gd). Tres tipos de grafico: anims, tiny (16x16 animado por codigo), human.
## IA: pasivos huyen, territoriales defienden su zona, hostiles persiguen. Ataques: melee, carga, a distancia,
## explosivo y ladron. Evita atascarse en paredes (direccion de rodeo y escape aleatorio). Jefes con habilidades.

const Species := preload("res://data/species.gd")
const Appearances := preload("res://data/appearances.gd")

var world = null
var species_id := ""
var cid := ""
var data := {}
var hp := 10.0
var max_hp := 10.0
var dmg := 0.0
var radius := 6.0
var habitat := "land"
var home := Vector2.ZERO
var state := "idle"
var target := Vector2.ZERO
var timer := 1.0
var attack_cd := 1.0
var windup := 0.0
var hurt_t := 0.0
var flee_t := 0.0
var provoked := false
var vel := Vector2.ZERO
var dead := false
var mode := "anim"
var vis = null                    # AnimatedSprite2D o Sprite2D
var moving := false
var face_x := 1.0
var stolen_gold := 0
var engaged := false
var _t := 0.0
var _flash := 0.0
var _death_t := 0.0
var _bar_t := 0.0
var _stuck_acc := 0.0
var _stuck_t := 0.0
var _stuck_dir := Vector2.ZERO
var _charge_dir := Vector2.ZERO
var _charge_t := 0.0
var _charge_hit := false
var _shoot_dir := Vector2.ZERO
var _erratic_t := 0.0
var _erratic_dir := Vector2.ZERO
var _slam_cd := 6.0
var _slam_pos := Vector2.ZERO
var _slam_t := -1.0
var _volley_cd := 5.0
var _summon_stage := 0
var _frame_row := 0
var _anim_t := 0.0


func setup(sid: String, id: String, world_ref, mult: float = 1.0) -> void:
	species_id = sid
	cid = id
	world = world_ref
	data = Species.get_species(sid)
	max_hp = float(data["hp"]) * mult
	hp = max_hp
	dmg = float(data["dmg"]) * (1.0 + (mult - 1.0) * 0.6)
	radius = float(data["radius"])
	habitat = str(data.get("habitat", "land"))


func _ready() -> void:
	add_to_group("creatures")
	_build_visual()
	timer = randf_range(0.5, 2.5)
	home = position
	attack_cd = randf_range(0.5, 1.5)
	if str(data["behavior"]) == "guard":
		add_to_group("guards")


func _build_visual() -> void:
	var sc := float(data.get("scale", 1.0))
	if data.has("tiny"):
		mode = "tiny"
		var s := Sprite2D.new()
		s.texture = load(Species.TINY % int(data["tiny"]))
		s.centered = false
		s.offset = Vector2(-8, -16)
		s.scale = Vector2(sc, sc)
		add_child(s)
		vis = s
	elif data.has("human"):
		mode = "human"
		var s2 := Sprite2D.new()
		s2.texture = load(Appearances.SHEET % int(data["human"]))
		s2.hframes = 3
		s2.vframes = 4
		s2.centered = false
		s2.offset = Vector2(-8, -19)
		s2.frame = 1
		add_child(s2)
		vis = s2
	else:
		mode = "anim"
		var frames := SpriteFrames.new()
		if frames.has_animation("default"):
			frames.remove_animation("default")
		for anim_name in data["anims"].keys():
			var a: Dictionary = data["anims"][anim_name]
			var tex: Texture2D = load(str(a["tex"]))
			frames.add_animation(anim_name)
			frames.set_animation_speed(anim_name, float(a["fps"]))
			frames.set_animation_loop(anim_name, bool(a["loop"]))
			for i in int(a["n"]):
				var at := AtlasTexture.new()
				at.atlas = tex
				at.region = Rect2(i * int(a["fw"]), int(a["row"]) * int(a["fh"]), int(a["fw"]), int(a["fh"]))
				frames.add_frame(anim_name, at)
		var sp := AnimatedSprite2D.new()
		sp.sprite_frames = frames
		sp.centered = false
		var foot: Vector2 = data["foot"]
		sp.offset = -foot
		sp.scale = Vector2(sc, sc)
		add_child(sp)
		sp.play("idle")
		vis = sp


func body_center() -> Vector2:
	return position + Vector2(0, -float(data["height"]) * float(data.get("scale", 1.0)) * 0.4 - (6.0 if habitat == "air" else 0.0))


func _draw() -> void:
	draw_set_transform(Vector2(0, -1), 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, radius + 2.0, Color(0, 0, 0, 0.25))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if _slam_t >= 0.0:
		var k := 1.0 - clampf(_slam_t / 0.9, 0.0, 1.0)
		draw_circle(_slam_pos - position, 34.0, Color(1, 0.2, 0.1, 0.12 + 0.25 * k))
		draw_arc(_slam_pos - position, 34.0, 0.0, TAU, 28, Color(1, 0.3, 0.1, 0.8), 2.0)
	if _bar_t > 0.0 and not dead:
		var y := -float(data["height"]) * float(data.get("scale", 1.0)) - 7.0
		var bw := maxf(18.0, radius * 2.0)
		draw_rect(Rect2(-bw / 2.0, y, bw, 3), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(-bw / 2.0 + 1.0, y + 1, (bw - 2.0) * clampf(hp / max_hp, 0.0, 1.0), 1), Color(0.9, 0.2, 0.2, 1.0))


# ------------------------------------------------------------ visual
func _vis_modulate(c: Color) -> void:
	if vis != null:
		vis.modulate = c


func _play(anim_name: String) -> void:
	if mode == "anim" and vis.sprite_frames.has_animation(anim_name) and vis.animation != anim_name:
		vis.play(anim_name)


func _update_visual(delta: float) -> void:
	_anim_t += delta
	var sc := float(data.get("scale", 1.0))
	if mode == "anim":
		vis.flip_h = face_x < 0.0
		_play("move" if moving else "idle")
		return
	var lift := 0.0
	if habitat == "air":
		lift = 6.0 + sin(_t * 4.0) * 2.0
	if mode == "tiny":
		vis.flip_h = face_x < 0.0
		if moving:
			vis.position.y = -absf(sin(_t * 11.0)) * 2.0 * sc - lift
			vis.scale = Vector2(sc, sc)
		else:
			vis.position.y = -lift
			vis.scale = Vector2(sc, sc * (1.0 + 0.05 * sin(_t * 3.0)))
		if state == "attack" or state == "charge_windup" or state == "shoot" or state == "explode":
			vis.position.x = sin(_t * 50.0) * 0.8
		else:
			vis.position.x = 0.0
	else:
		var row := _frame_row
		if absf(face_x) > 0.1 and moving:
			row = Appearances.ROW_RIGHT if face_x > 0.0 else Appearances.ROW_LEFT
		_frame_row = row
		var col := 1
		if moving:
			col = [1, 0, 1, 2][int(_anim_t * 8.0) % 4]
		vis.frame = row * 3 + col


# ------------------------------------------------------------ bucle
func _process(delta: float) -> void:
	if dead:
		_death_t -= delta
		if _death_t <= 0.0:
			queue_free()
		return
	_t += delta
	moving = false
	attack_cd = maxf(0.0, attack_cd - delta)
	hurt_t -= delta
	flee_t -= delta
	_bar_t = maxf(0.0, _bar_t - delta)
	if _flash > 0.0:
		_flash -= delta
		if _flash <= 0.0:
			_vis_modulate(Color.WHITE)
	if vel.length() > 2.0:
		world.move_entity(self, vel * delta, radius)
		vel = vel.lerp(Vector2.ZERO, minf(1.0, delta * 9.0))
	if hurt_t > 0.0:
		_update_visual(delta)
		return
	var p = world.player
	var to_p: Vector2 = p.position - position
	var dist := to_p.length()
	var beh := str(data["behavior"])
	var atk := str(data["attack"])
	var speed := float(data["speed"])
	var sight := float(data["sight"])
	var rng := float(data["range"])
	var alive_player: bool = not world.player_dead()
	if not (data.get("abilities", []) as Array).is_empty():
		_boss_logic(delta, dist, sight, alive_player)
	var hostile_now := (beh == "hostile") or (beh == "territorial" and (provoked or dist < 36.0)) \
		or (beh == "guard" and GameState.is_wanted())
	var busy := state == "attack" or state == "charge_windup" or state == "charge" or state == "shoot" or state == "explode"
	if beh == "passive" and (provoked or dist < 40.0) and alive_player:
		if state != "flee":
			flee_t = 2.2
		state = "flee"
	elif hostile_now and alive_player and dist < sight and not busy and not (state == "flee" and flee_t > 0.0):
		state = "chase"
		if not engaged:
			engaged = true
			if bool(data.get("boss", false)):
				world.boss_intro(self)
	match state:
		"attack":
			windup -= delta
			if windup <= 0.0:
				if dist <= rng * 1.7 and alive_player:
					world.damage_player(dmg, position)
					if bool(data.get("poison", false)):
						p.poison_t = 4.0
				attack_cd = 1.1
				state = "chase"
		"charge_windup":
			windup -= delta
			_vis_modulate(Color(1, 0.7, 0.7))
			if windup <= 0.0:
				_vis_modulate(Color.WHITE)
				state = "charge"
				_charge_t = 0.42
				_charge_hit = false
				_charge_dir = to_p.normalized()
		"charge":
			_charge_t -= delta
			_step(_charge_dir, speed * 3.4, delta)
			if not _charge_hit and alive_player and position.distance_to(p.position) < radius + 8.0:
				_charge_hit = true
				world.damage_player(dmg * 1.2, position)
			if _charge_t <= 0.0:
				state = "chase"
				attack_cd = 2.2
		"shoot":
			windup -= delta
			if windup <= 0.0:
				_fire_bolt(p.position + Vector2(0, -8))
				attack_cd = 1.6
				state = "chase"
		"explode":
			windup -= delta
			_vis_modulate(Color(1, 0.5 + 0.5 * sin(_t * 30.0), 0.4))
			if windup <= 0.0:
				world.area_damage_player(position, 30.0, dmg)
				world.spawn_fx("small_explosion", position, 0.0, 0.7)
				hp = 0.0
				_die(true)
		"chase":
			if not alive_player or dist > sight * 1.7:
				state = "idle"
				timer = 1.0
			else:
				_chase(delta, p, to_p, dist, atk, rng, speed)
		"flee":
			if flee_t <= 0.0:
				state = "idle"
				timer = 1.5
				if stolen_gold > 0:
					world.hud.toast("thief_escaped")
					queue_free()
					return
			else:
				var away := -to_p if to_p.length() > 1.0 else Vector2.RIGHT
				_step(away, speed * (1.5 if stolen_gold > 0 else 1.15), delta)
		"wander":
			if position.distance_to(target) < 3.0:
				state = "idle"
				timer = randf_range(1.5, 4.0)
			else:
				_step(target - position, speed * 0.45, delta)
		_:
			timer -= delta
			if bool(data.get("erratic", false)) and alive_player and dist < sight * 1.4 and beh == "hostile":
				state = "chase"
			elif timer <= 0.0:
				var r := 56.0 if beh != "guard" else 24.0
				target = home + Vector2(randf_range(-r, r), randf_range(-r, r) * 0.6)
				state = "wander"
	if bool(data.get("boss", false)) and engaged:
		world.hud.update_boss(hp / max_hp)
	_update_visual(delta)
	if _bar_t > 0.0 or _slam_t >= 0.0:
		queue_redraw()


func _chase(delta: float, p, to_p: Vector2, dist: float, atk: String, rng: float, speed: float) -> void:
	if bool(data.get("erratic", false)):
		_erratic_t -= delta
		if _erratic_t <= 0.0:
			_erratic_t = randf_range(0.3, 0.7)
			_erratic_dir = Vector2.from_angle(randf() * TAU) * 0.8
		_step(to_p.normalized() + _erratic_dir, speed, delta)
		if dist <= rng and attack_cd <= 0.0:
			state = "attack"
			windup = 0.25
		return
	if atk == "ranged":
		if attack_cd <= 0.0 and dist <= rng * 1.25 and dist > 20.0:
			state = "shoot"
			windup = 0.45
			return
		if dist > rng * 0.9:
			_step(to_p, speed, delta)
		elif dist < rng * 0.5:
			_step(-to_p, speed * 0.9, delta)
		else:
			_step(to_p.orthogonal(), speed * 0.5, delta)
		return
	if atk == "charge" and attack_cd <= 0.0 and dist < 120.0 and dist > rng * 1.6:
		state = "charge_windup"
		windup = 0.5
		return
	if atk == "explode":
		if dist < 16.0:
			state = "explode"
			windup = 0.6
			return
	if atk == "thief":
		if dist < rng and stolen_gold == 0:
			var amount: int = mini(GameState.gold, maxi(5, int(GameState.gold * 0.2)))
			if amount > 0:
				GameState.gold -= amount
				stolen_gold = amount
				world.hud.toast("stolen")
				Audio.play("hurt")
				state = "flee"
				flee_t = 7.0
				GameState.changed.emit()
				return
			attack_cd = 3.0
		_step(to_p, speed, delta)
		return
	if dist <= rng and attack_cd <= 0.0:
		state = "attack"
		windup = 0.35
		_play("attack")
	elif dist > rng * 0.8:
		_step(to_p, speed, delta)


## Avanza en una direccion rodeando obstaculos; si se atasca, intenta una direccion aleatoria.
func _step(dir_in: Vector2, speed: float, delta: float) -> void:
	if dir_in.length() < 0.01:
		return
	var dir := dir_in.normalized()
	if _stuck_t > 0.0:
		_stuck_t -= delta
		dir = _stuck_dir
	elif not world.free_ahead(self, dir, 10.0):
		for a in [0.5, -0.5, 1.0, -1.0, 1.6, -1.6, 2.4]:
			var cand := dir.rotated(a)
			if world.free_ahead(self, cand, 10.0):
				dir = cand
				break
	var before := position
	world.move_entity(self, dir * speed * delta, radius)
	var moved := position.distance_to(before)
	if moved < speed * delta * 0.3:
		_stuck_acc += delta
		if _stuck_acc > 0.45:
			_stuck_acc = 0.0
			_stuck_t = 0.7
			_stuck_dir = Vector2.from_angle(randf() * TAU)
	else:
		_stuck_acc = maxf(0.0, _stuck_acc - delta)
	moving = true
	if absf(dir.x) > 0.1:
		face_x = dir.x


func _fire_bolt(aim: Vector2) -> void:
	var kind := "enemy_arrow"
	var b := str(data.get("bolt", ""))
	if b == "fire":
		kind = "enemy_fire"
	elif b == "shadow":
		kind = "enemy_shadow"
	world.spawn_projectile(kind, position + Vector2(0, -8), (aim - (position + Vector2(0, -8))).normalized(), dmg, 10.0)


# ------------------------------------------------------------ dano y muerte
func take_damage(amount: float, from_pos: Vector2, kb: float = 60.0) -> void:
	if dead:
		return
	hp -= amount
	provoked = true
	_bar_t = 3.0
	_flash = 0.12
	_vis_modulate(Color(1, 0.45, 0.45))
	var boss := bool(data.get("boss", false))
	hurt_t = 0.05 if boss else 0.2
	vel = (position - from_pos).normalized() * (kb * (0.2 if boss else 1.0))
	if mode == "anim" and vis.sprite_frames.has_animation("hit") and not boss:
		vis.play("hit")
	world.spawn_fx("hit_spark", body_center(), 0.0, 0.5)
	Audio.play("hit")
	if str(data["behavior"]) == "guard" or str(data["behavior"]) == "passive":
		provoked = true
	queue_redraw()
	if hp <= 0.0:
		_die(false)


func _die(silent: bool) -> void:
	dead = true
	remove_from_group("creatures")
	_vis_modulate(Color.WHITE)
	_death_t = 0.7
	if mode == "anim" and vis.sprite_frames.has_animation("die"):
		vis.play("die")
		_death_t = float(vis.sprite_frames.get_frame_count("die")) / float(data["anims"]["die"]["fps"]) + 0.5
	else:
		var tw := create_tween()
		tw.tween_property(vis, "modulate:a", 0.0, 0.5)
	if bool(data.get("boss", false)):
		world.hud.hide_boss()
	if data.has("split") and not silent:
		for i in 2:
			world.spawn_creature({"species": str(data["split"]), "tx": floori(position.x / 16.0) + i * 2 - 1, "ty": floori(position.y / 16.0),
				"id": "split_%d_%d" % [Time.get_ticks_msec(), i]})
	if stolen_gold > 0:
		GameState.gold += stolen_gold
		world.hud.toast_text("+%d %s" % [stolen_gold, Loc.t("hud_gold")])
		stolen_gold = 0
	queue_redraw()
	if not silent:
		world.on_creature_killed(self)


# ------------------------------------------------------------ jefes
func _boss_logic(delta: float, dist: float, sight: float, alive_player: bool) -> void:
	var abil: Array = data["abilities"]
	if not alive_player or dist > sight:
		return
	if abil.has("slam"):
		_slam_cd -= delta
		if _slam_t >= 0.0:
			_slam_t -= delta
			if _slam_t < 0.0:
				world.spawn_fx("ground_slam", _slam_pos, 0.0, 0.8)
				world.spawn_fx("small_explosion", _slam_pos, 0.0, 1.0)
				world.camera_shake(0.25)
				if world.player.position.distance_to(_slam_pos) < 34.0:
					world.damage_player(dmg * 1.2, _slam_pos)
		elif _slam_cd <= 0.0 and dist < 200.0:
			_slam_cd = 7.0
			_slam_pos = world.player.position
			_slam_t = 0.9
	if abil.has("volley") and engaged:
		_volley_cd -= delta
		if _volley_cd <= 0.0 and dist < 240.0:
			_volley_cd = 5.5
			var base := (world.player.position + Vector2(0, -8) - (position + Vector2(0, -8))).angle()
			for k in range(-2, 3):
				var d := Vector2.from_angle(base + k * 0.22)
				world.spawn_projectile("enemy_fire", position + Vector2(0, -10), d, dmg * 0.7, 10.0)
			world.hud.toast("boss_volley")
	for a in abil:
		if str(a).begins_with("summon:"):
			var ratio := hp / max_hp
			if (_summon_stage == 0 and ratio < 0.66) or (_summon_stage == 1 and ratio < 0.33):
				_summon_stage += 1
				var sp := str(a).substr(7)
				for i in 3:
					var ang := i * TAU / 3.0
					world.spawn_creature({"species": sp, "tx": floori(position.x / 16.0) + roundi(cos(ang) * 3.0), "ty": floori(position.y / 16.0) + roundi(sin(ang) * 3.0),
						"id": "minion_%d_%d" % [Time.get_ticks_msec(), i]})
				world.hud.toast("boss_summon")
