extends Sprite2D
## Efecto animado a partir de una hoja PVFX (rejilla de 8 columnas, ver data/fx_data.gd).

const FxData := preload("res://data/fx_data.gd")

var fx_id := ""
var rot := 0.0
var fx_scale := 1.0
var loop_time := -1.0           # solo para efectos en bucle: segundos de vida
var _spec := {}
var _t := 0.0


func setup(id: String, pos: Vector2, rotation_rad: float = 0.0, scl: float = 1.0, loop_seconds: float = -1.0) -> void:
	fx_id = id
	position = pos
	rot = rotation_rad
	fx_scale = scl
	loop_time = loop_seconds


func _ready() -> void:
	_spec = FxData.FX.get(fx_id, {})
	if _spec.is_empty():
		queue_free()
		return
	texture = load("res://assets/fx/%s.png" % fx_id)
	centered = false
	offset = Vector2(-float(_spec["px"]), -float(_spec["py"]))
	region_enabled = true
	rotation = rot
	scale = Vector2(fx_scale, fx_scale)
	_set_frame(0)


func _set_frame(f: int) -> void:
	var w: int = int(_spec["w"])
	var h: int = int(_spec["h"])
	region_rect = Rect2((f % 8) * w, floori(float(f) / 8.0) * h, w, h)


func _process(delta: float) -> void:
	if _spec.is_empty():
		return
	_t += delta
	var f: int = int(_t * 1000.0 / float(_spec["ms"]))
	var n: int = int(_spec["n"])
	if f >= n:
		if bool(_spec["loop"]) and loop_time > 0.0 and _t < loop_time:
			f = f % n
		else:
			queue_free()
			return
	_set_frame(f)
