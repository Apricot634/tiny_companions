extends Control
## Panel de tienda (comprar / vender / robar) y de maestro de magia (aprender hechizos).

const WildTheme := preload("res://ui/wild_theme.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")
const INK := Color8(70, 44, 22)

var hud = null
var kind := "shop"
var ctx := {}
var mode := "buy"
var steal := false
var teacher := false
var list: VBoxContainer
var gold_label: Label
var title_label: Label
var btn_buy: Button
var btn_sell: Button
var btn_steal: Button
var btn_close: Button


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.65)
	add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	var st := StyleBoxFlat.new()
	st.bg_color = Color8(236, 220, 180)
	st.border_color = Color8(110, 70, 34)
	st.set_border_width_all(4)
	st.set_corner_radius_all(8)
	st.content_margin_left = 10
	st.content_margin_right = 10
	st.content_margin_top = 8
	st.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel", st)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(440, 270)
	vb.add_theme_constant_override("separation", 5)
	panel.add_child(vb)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 4)
	vb.add_child(head)
	title_label = Label.new()
	title_label.add_theme_color_override("font_color", Color8(150, 70, 20))
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title_label)
	gold_label = Label.new()
	gold_label.add_theme_color_override("font_color", INK)
	head.add_child(gold_label)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 4)
	vb.add_child(tabs)
	btn_buy = _tab_button(tabs, _on_mode.bind("buy"))
	btn_sell = _tab_button(tabs, _on_mode.bind("sell"))
	btn_steal = _tab_button(tabs, _on_steal_toggle)
	btn_close = _tab_button(tabs, _on_close)
	btn_close.text = "X"
	btn_close.custom_minimum_size = Vector2(34, 28)
	btn_close.size_flags_horizontal = Control.SIZE_SHRINK_END
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 200)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	list = VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 3)
	scroll.add_child(list)


func _tab_button(parent: Control, cb: Callable) -> Button:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, 28)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func open_shop(k: String, c: Dictionary) -> void:
	kind = k
	ctx = c
	teacher = false
	mode = "buy"
	steal = false
	visible = true
	_refresh()


func open_teacher() -> void:
	teacher = true
	mode = "buy"
	steal = false
	ctx = {}
	visible = true
	_refresh()


func _mult() -> float:
	return float(ctx.get("price_mult", 1.0))


func _buy_price(id: String) -> int:
	return maxi(1, int(float(Items.ITEMS[id]["price"]) * _mult()))


func _on_mode(m: String) -> void:
	mode = m
	steal = false
	Audio.play("click")
	_refresh()


func _on_steal_toggle() -> void:
	steal = not steal
	mode = "buy"
	Audio.play("toggle")
	hud.toast("steal_mode_on" if steal else "steal_mode_off")
	_refresh()


func _on_close() -> void:
	hud.close_shop()


func _row(icon_path: String, text: String, price_text: String, btn_text: String, cb: Callable, enabled: bool = true) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var icon := TextureRect.new()
	icon.texture = load(icon_path)
	icon.custom_minimum_size = Vector2(26, 26)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	row.add_child(icon)
	var l := Label.new()
	l.text = text
	l.add_theme_color_override("font_color", INK)
	l.add_theme_font_size_override("font_size", 11)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)
	var p := Label.new()
	p.text = price_text
	p.add_theme_color_override("font_color", Color8(150, 70, 20))
	row.add_child(p)
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.text = btn_text
	b.custom_minimum_size = Vector2(74, 28)
	b.disabled = not enabled
	b.pressed.connect(cb)
	row.add_child(b)
	list.add_child(row)


func _refresh() -> void:
	for c in list.get_children():
		c.queue_free()
	gold_label.text = "%s: %d" % [Loc.t("hud_gold"), GameState.gold]
	btn_buy.text = Loc.t("shop_buy")
	btn_sell.text = Loc.t("shop_sell")
	btn_steal.text = Loc.t("shop_steal")
	btn_steal.visible = not teacher and ctx.has("steal_cb")
	btn_sell.visible = not teacher
	btn_steal.modulate = Color(1, 0.5, 0.4) if steal else Color.WHITE
	if teacher:
		title_label.text = Loc.t("opt_learn")
		_build_teacher()
	elif mode == "buy":
		title_label.text = Loc.t("place_" + kind) if kind != "shop" else Loc.t("place_shop")
		_build_buy()
	else:
		title_label.text = Loc.t("shop_sell")
		_build_sell()


func _build_buy() -> void:
	for id in Items.SHOPS[kind]:
		var price := _buy_price(str(id))
		var label := Loc.t("item_" + str(id))
		if steal:
			_row(Items.icon_path(str(id)), label, "", Loc.t("shop_steal"), _on_steal_item.bind(str(id)))
		else:
			_row(Items.icon_path(str(id)), label, "%d" % price, Loc.t("shop_buy"), _on_buy.bind(str(id)), GameState.gold >= price)


func _build_sell() -> void:
	for id in GameState.bag:
		if str(id) == "" or int(GameState.inventory.get(str(id), 0)) <= 0:
			continue
		var sid := str(id)
		_row(Items.icon_path(sid), "%s x%d" % [Loc.t("item_" + sid), GameState.item_count(sid)], "%d" % GameState.sell_price(sid), Loc.t("shop_sell"), _on_sell.bind(sid))


func _build_teacher() -> void:
	for sid in Spells.ORDER:
		var sp: Dictionary = Spells.SPELLS[sid]
		var known: bool = GameState.known_spells.has(sid)
		var label := "%s  [%s]" % [Loc.t("spell_" + sid), Loc.t("rank_%d" % int(sp["rank"]))]
		var ok := not known and GameState.magic_rank >= int(sp["rank"]) and GameState.gold >= int(sp["learn"])
		var btn := "OK" if known else str(Loc.t("opt_learn").split(" ")[0])
		var row_text := label
		if not known and GameState.magic_rank < int(sp["rank"]):
			row_text += "  " + Loc.t("spell_locked") % int(sp["rank"])
		_row(Spells.icon_path(sid), row_text, "%d" % int(sp["learn"]), btn, _on_learn.bind(str(sid)), ok)


func _on_buy(id: String) -> void:
	var price := _buy_price(id)
	if not GameState.spend(price):
		hud.toast("not_enough_gold")
		Audio.play("error")
		return
	GameState.add_item(id, 5 if id == "arrow" else 1)
	hud.toast_text(Loc.t("shop_bought") % Loc.t("item_" + id))
	Audio.play("pickup")
	_refresh()


func _on_sell(id: String) -> void:
	var price := GameState.sell_price(id)
	if GameState.remove_item(id, 1):
		GameState.gold += price
		hud.toast_text(Loc.t("shop_sold") % [Loc.t("item_" + id), price])
		Audio.play("pickup")
		GameState.changed.emit()
	_refresh()


func _on_steal_item(id: String) -> void:
	var cb: Callable = ctx["steal_cb"]
	var ok: bool = cb.call(id)
	if ok:
		Audio.play("collect")
		_refresh()


func _on_learn(sid: String) -> void:
	if GameState.learn_spell(sid):
		hud.toast_text(Loc.t("learned_spell") % Loc.t("spell_" + sid))
		Audio.play("confirm")
	else:
		hud.toast("not_enough_gold")
		Audio.play("error")
	_refresh()
