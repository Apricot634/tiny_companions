extends Control
## Menu principal. Cada boton abre su propia pantalla:
## Jugar -> Mundos -> Crear mundo -> Crear personaje | Ajustes | Creditos.

const WildTheme := preload("res://ui/wild_theme.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const CreditsData := preload("res://core/credits_data.gd")
const Appearances := preload("res://data/appearances.gd")
const GAME_SCENE := "res://scenes/game_world.tscn"

var screens := {}
var current := "main"
var logo: TextureRect
var sub: Label
var txt := {}
var info: Label
var fade: ColorRect
var lang_buttons := {}
var link_buttons: Array = []
var third_labels: Array = []
var worlds_list: VBoxContainer
var world_name_edit: LineEdit
var seed_edit: LineEdit
var char_name_edit: LineEdit
var skin_buttons := {}
var style_buttons := {}
var style_desc: Label
var preview: TextureRect
var preview_atlas: AtlasTexture
var sel_skin := 1
var sel_style := "adventurer"
var volume_slider: HSlider
var bg_items: Array = []
var _pending_delete := -1
var _t := 0.0


func _ready() -> void:
	GameState.active = false
	get_tree().paused = false
	theme = WildTheme.make(14)
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_background()
	logo = TextureRect.new()
	logo.texture = load("res://assets/ui/logo.png")
	logo.stretch_mode = TextureRect.STRETCH_KEEP_CENTERED
	add_child(logo)
	sub = Label.new()
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(sub)
	info = Label.new()
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_color_override("font_color", Color8(255, 200, 120))
	add_child(info)
	_build_main()
	_build_worlds()
	_build_create()
	_build_character()
	_build_settings()
	_build_credits()
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fade)
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	resized.connect(_layout)
	Loc.language_changed.connect(_refresh)
	_show("main")
	_refresh()
	_layout()


# ------------------------------------------------------------ fondo
func _build_background() -> void:
	var sky := ColorRect.new()
	sky.color = Color8(24, 28, 46)
	add_child(sky)
	sky.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var glow := ColorRect.new()
	glow.color = Color8(52, 44, 84)
	add_child(glow)
	glow.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	glow.offset_top = -190
	var ground := ColorRect.new()
	ground.color = Color8(46, 72, 52)
	add_child(ground)
	ground.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	ground.offset_top = -64
	for i in 40:
		var s := ColorRect.new()
		s.color = Color(1, 1, 0.85, randf_range(0.3, 0.9))
		s.size = Vector2(2, 2)
		s.mouse_filter = Control.MOUSE_FILTER_IGNORE
		s.set_meta("rx", randf())
		s.set_meta("ry", randf() * 0.5)
		add_child(s)
		bg_items.append(s)
	for spec in [["res://assets/props/tree1.png", 0.07, 2.0], ["res://assets/props/tree2.png", 0.17, 2.0], ["res://assets/props/tree1.png", 0.9, 2.0], ["res://assets/houses/house1.png", 0.83, 1.6], ["res://assets/props/tree2.png", 0.95, 2.0]]:
		var tr := TextureRect.new()
		tr.texture = load(str(spec[0]))
		tr.stretch_mode = TextureRect.STRETCH_KEEP
		tr.scale = Vector2(float(spec[2]), float(spec[2]))
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tr.modulate = Color(0.55, 0.6, 0.75)
		tr.set_meta("rx", float(spec[1]))
		add_child(tr)
		bg_items.append(tr)


func _layout() -> void:
	var s := size
	for it in bg_items:
		if it is TextureRect:
			var tr: TextureRect = it
			var w: float = tr.texture.get_width() * tr.scale.x
			var h: float = tr.texture.get_height() * tr.scale.y
			tr.position = Vector2(s.x * float(tr.get_meta("rx")) - w / 2.0, s.y - 38.0 - h)
		else:
			it.position = Vector2(s.x * float(it.get_meta("rx")), s.y * float(it.get_meta("ry")))
	logo.position = Vector2((s.x - 480.0) / 2.0, 6.0)
	logo.size = Vector2(480, 144)
	logo.scale = Vector2(0.62, 0.62)
	logo.position = Vector2((s.x - 480.0 * 0.62) / 2.0, 4.0)
	sub.position = Vector2(0, 92)
	sub.size = Vector2(s.x, 20)
	info.position = Vector2(0, s.y - 22)
	info.size = Vector2(s.x, 20)


# ------------------------------------------------------------ utilidades
func _button(key: String, cb: Callable, min_h: float = 34.0) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, min_h)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	txt[key] = b
	return b


func _label(key: String, big: bool = false) -> Label:
	var l := Label.new()
	if big:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", 18)
		l.add_theme_color_override("font_color", WildTheme.GOLD)
	txt[key] = l
	return l


func _screen(id: String, width: float, top: float = 118.0, with_panel: bool = true, max_h: float = 230.0) -> VBoxContainer:
	var root := CenterContainer.new()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.offset_top = top
	root.offset_bottom = -10
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(width, 0)
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 6)
	if with_panel:
		var panel := PanelContainer.new()
		root.add_child(panel)
		var scroll := ScrollContainer.new()
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		scroll.custom_minimum_size = Vector2(width + 14.0, max_h)
		panel.add_child(scroll)
		scroll.add_child(vb)
	else:
		root.add_child(vb)
	screens[id] = root
	return vb


func _show(id: String) -> void:
	current = id
	for k in screens.keys():
		screens[k].visible = (k == id)
	var main := (id == "main")
	logo.visible = main or id == "worlds" or id == "settings" or id == "credits"
	sub.visible = main
	_pending_delete = -1
	info.text = ""


func _go(id: String) -> void:
	Audio.play("click")
	_show(id)
	if id == "worlds":
		_rebuild_worlds()
	_refresh()


# ------------------------------------------------------------ pantallas
func _build_main() -> void:
	var vb := _screen("main", 230, 128.0, false)
	vb.add_child(_button("play", _on_play, 40))
	vb.add_child(_button("settings", _go.bind("settings"), 40))
	vb.add_child(_button("credits", _go.bind("credits"), 40))
	if OS.has_feature("pc"):
		vb.add_child(_button("quit", _on_quit, 40))


func _build_worlds() -> void:
	var vb := _screen("worlds", 400, 118.0, true, 230.0)
	vb.add_child(_label("worlds", true))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 120)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	worlds_list = VBoxContainer.new()
	worlds_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	worlds_list.add_theme_constant_override("separation", 5)
	scroll.add_child(worlds_list)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var nb := _button("create_world", _on_open_create)
	nb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bb := _button("back_worlds", _go.bind("main"))
	bb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(nb)
	row.add_child(bb)
	vb.add_child(row)


func _build_create() -> void:
	var vb := _screen("create", 340, 60.0, true, 250.0)
	vb.add_child(_label("title_create", true))
	vb.add_child(_label("world_name"))
	world_name_edit = LineEdit.new()
	world_name_edit.max_length = 24
	world_name_edit.custom_minimum_size = Vector2(0, 32)
	vb.add_child(world_name_edit)
	vb.add_child(_label("seed"))
	seed_edit = LineEdit.new()
	seed_edit.max_length = 24
	seed_edit.custom_minimum_size = Vector2(0, 32)
	seed_edit.placeholder_text = "123456"
	vb.add_child(seed_edit)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var nb := _button("next", _on_create_next)
	nb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bb := _button("back_create", _go.bind("worlds"))
	bb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(nb)
	row.add_child(bb)
	vb.add_child(row)


func _skin_icon(skin: int, col: int) -> AtlasTexture:
	var a := AtlasTexture.new()
	a.atlas = load(Appearances.SHEET % skin)
	a.region = Rect2(col * 16, 0, 16, 20)
	return a


func _build_character() -> void:
	var vb := _screen("character", 540, 6.0, true, 330.0)
	vb.add_child(_label("char_title", true))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	vb.add_child(hb)
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(120, 0)
	hb.add_child(left)
	preview_atlas = _skin_icon(sel_skin, 1)
	preview = TextureRect.new()
	preview.texture = preview_atlas
	preview.custom_minimum_size = Vector2(96, 120)
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	left.add_child(preview)
	left.add_child(_label("char_name"))
	char_name_edit = LineEdit.new()
	char_name_edit.max_length = 16
	char_name_edit.text = "Heroe"
	char_name_edit.custom_minimum_size = Vector2(0, 30)
	left.add_child(char_name_edit)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 5)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(right)
	right.add_child(_label("char_appearance"))
	var grid := GridContainer.new()
	grid.columns = 6
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	right.add_child(grid)
	for skin in Appearances.SKINS:
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(44, 50)
		b.icon = _skin_icon(skin, 1)
		b.expand_icon = true
		b.pressed.connect(_on_pick_skin.bind(skin))
		grid.add_child(b)
		skin_buttons[skin] = b
	right.add_child(_label("char_style"))
	var srow := HBoxContainer.new()
	srow.add_theme_constant_override("separation", 4)
	right.add_child(srow)
	for sid in Appearances.STYLE_IDS:
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, 32)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_pick_style.bind(sid))
		srow.add_child(b)
		style_buttons[sid] = b
	style_desc = Label.new()
	style_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	style_desc.custom_minimum_size = Vector2(0, 34)
	right.add_child(style_desc)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	var eb := _button("enter_world", _on_enter_world, 36)
	eb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bb := _button("back_char", _go.bind("create"), 36)
	bb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(eb)
	row.add_child(bb)
	vb.add_child(row)


func _build_settings() -> void:
	var vb := _screen("settings", 340, 118.0, true, 232.0)
	vb.add_child(_label("title_settings", true))
	vb.add_child(_label("language"))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	for l in Loc.LANGS:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 34)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.text = Loc.LANG_NAMES[l]
		b.pressed.connect(_on_pick_language.bind(l))
		row.add_child(b)
		lang_buttons[l] = b
	vb.add_child(row)
	vb.add_child(_label("sound"))
	volume_slider = HSlider.new()
	volume_slider.min_value = 0.0
	volume_slider.max_value = 1.0
	volume_slider.step = 0.1
	volume_slider.value = float(Settings.data["volume"])
	volume_slider.custom_minimum_size = Vector2(0, 24)
	volume_slider.value_changed.connect(_on_volume)
	vb.add_child(volume_slider)
	vb.add_child(_button("calibrate", _on_calibrate))
	vb.add_child(_button("back_settings", _go.bind("main")))


func _build_credits() -> void:
	var vb := _screen("credits", 440, 110.0, true, 240.0)
	vb.add_child(_label("title_credits", true))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 150)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 6)
	scroll.add_child(inner)
	inner.add_child(_label("credits_creator"))
	var creator := Label.new()
	creator.text = CreditsData.CREATOR
	creator.add_theme_font_size_override("font_size", 18)
	creator.add_theme_color_override("font_color", WildTheme.GOLD)
	inner.add_child(creator)
	inner.add_child(_label("credits_social"))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	inner.add_child(grid)
	for link in CreditsData.LINKS:
		var b := Button.new()
		b.text = " " + str(link["name"])
		b.icon = load(str(link["icon"]))
		b.expand_icon = false
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(0, 38)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.set_meta("url", str(link["url"]))
		b.pressed.connect(_on_open_link.bind(str(link["url"])))
		grid.add_child(b)
		link_buttons.append(b)
	inner.add_child(_label("credits_third"))
	for item in CreditsData.THIRD_PARTY:
		var l := Label.new()
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size = Vector2(400, 0)
		l.add_theme_font_size_override("font_size", 11)
		inner.add_child(l)
		third_labels.append({"label": l, "item": item})
	var note := _label("cred_local")
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(400, 0)
	note.add_theme_font_size_override("font_size", 11)
	inner.add_child(note)
	inner.add_child(_label("credits_note"))
	vb.add_child(_button("back_credits", _go.bind("main")))


# ------------------------------------------------------------ textos
func _tbc(v: String) -> String:
	return Loc.t("tbc") if v == "?" else v


func _refresh() -> void:
	sub.text = Loc.t("subtitle")
	var keys := {
		"play": "play", "settings": "settings", "credits": "credits", "quit": "quit", "worlds": "worlds",
		"create_world": "create_world", "back_worlds": "back", "title_create": "create_world",
		"title_settings": "settings", "title_credits": "credits",
		"world_name": "world_name", "seed": "seed", "next": "next", "back_create": "back",
		"char_title": "char_title", "char_name": "char_name", "char_appearance": "char_appearance",
		"char_style": "char_style", "enter_world": "enter_world", "back_char": "back",
		"language": "language", "sound": "sound", "calibrate": "calibrate", "test_controls": "test_controls",
		"back_settings": "back", "credits_creator": "credits_creator", "credits_social": "credits_social",
		"credits_third": "credits_third", "credits_note": "credits_note", "cred_local": "cred_local",
		"back_credits": "back",
	}
	for k in keys.keys():
		if txt.has(k):
			txt[k].text = Loc.t(keys[k])
	for e in third_labels:
		var item: Dictionary = e["item"]
		(e["label"] as Label).text = "%s - %s (%s)" % [str(item["name"]), _tbc(str(item["author"])), _tbc(str(item["license"]))]
	for l in lang_buttons.keys():
		(lang_buttons[l] as Button).modulate = Color(1, 0.85, 0.4) if l == Loc.lang else Color.WHITE
	for sid in style_buttons.keys():
		var b: Button = style_buttons[sid]
		b.text = Loc.t("style_" + str(sid))
		b.modulate = Color(1, 0.85, 0.4) if sid == sel_style else Color.WHITE
	for skin in skin_buttons.keys():
		(skin_buttons[skin] as Button).modulate = Color(1, 0.85, 0.4) if skin == sel_skin else Color.WHITE
	style_desc.text = Loc.t("style_%s_desc" % sel_style)
	if current == "worlds":
		_rebuild_worlds()


func _rebuild_worlds() -> void:
	for c in worlds_list.get_children():
		c.queue_free()
	var worlds := GameState.list_worlds()
	if worlds.is_empty():
		var l := Label.new()
		l.text = Loc.t("no_worlds")
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		worlds_list.add_child(l)
	for w in worlds:
		var slot: int = w["slot"]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		var pb := Button.new()
		pb.focus_mode = Control.FOCUS_NONE
		pb.custom_minimum_size = Vector2(0, 40)
		pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pb.alignment = HORIZONTAL_ALIGNMENT_LEFT
		pb.icon = _skin_icon(int(w["skin"]), 1)
		pb.expand_icon = true
		pb.text = " %s - %s (%s, %s)" % [str(w["name"]), str(w["player"]), Loc.t("style_" + str(w["style"])), Loc.t("minutes") % int(float(w["play_seconds"]) / 60.0)]
		pb.pressed.connect(_on_play_world.bind(slot))
		var db := Button.new()
		db.focus_mode = Control.FOCUS_NONE
		db.custom_minimum_size = Vector2(70 if _pending_delete == slot else 40, 40)
		db.text = Loc.t("delete_confirm") if _pending_delete == slot else "X"
		db.pressed.connect(_on_delete.bind(slot))
		row.add_child(pb)
		row.add_child(db)
		worlds_list.add_child(row)


# ------------------------------------------------------------ acciones
func _process(delta: float) -> void:
	_t += delta
	if preview_atlas != null and current == "character":
		var cols := [1, 0, 1, 2]
		preview_atlas.region = Rect2(int(cols[int(_t * 4.0) % 4]) * 16, 0, 16, 20)
	for it in bg_items:
		if not (it is TextureRect):
			(it as ColorRect).modulate.a = 0.5 + 0.5 * sin(_t * 1.5 + float(it.get_meta("rx")) * 20.0)


func _go_world() -> void:
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.25)
	tw.tween_callback(_load_game_scene)


func _load_game_scene() -> void:
	get_tree().change_scene_to_file(GAME_SCENE)


func _on_play() -> void:
	Audio.play("click")
	_show("worlds")
	_rebuild_worlds()
	_refresh()


func _on_open_create() -> void:
	Audio.play("click")
	if GameState.list_worlds().size() >= GameState.MAX_WORLDS:
		Audio.play("error")
		info.text = Loc.t("max_worlds")
		return
	world_name_edit.text = ""
	world_name_edit.placeholder_text = Loc.t("default_world") % (GameState.list_worlds().size() + 1)
	seed_edit.text = ""
	_show("create")
	_refresh()


func _on_create_next() -> void:
	Audio.play("click")
	_show("character")
	_refresh()


func _on_pick_skin(skin: int) -> void:
	Audio.play("toggle")
	sel_skin = skin
	preview_atlas.atlas = load(Appearances.SHEET % skin)
	_refresh()


func _on_pick_style(sid: String) -> void:
	Audio.play("toggle")
	sel_style = sid
	_refresh()


func _on_enter_world() -> void:
	Audio.play("confirm")
	var wname := world_name_edit.text.strip_edges()
	if wname == "":
		wname = Loc.t("default_world") % (GameState.list_worlds().size() + 1)
	if GameState.new_world(wname, seed_edit.text, sel_skin, sel_style, char_name_edit.text):
		_go_world()
	else:
		Audio.play("error")
		info.text = Loc.t("max_worlds")


func _on_play_world(slot: int) -> void:
	Audio.play("confirm")
	if GameState.load_game(slot):
		_go_world()
	else:
		Audio.play("error")
		info.text = Loc.t("load_error")


func _on_delete(slot: int) -> void:
	if _pending_delete == slot:
		Audio.play("back")
		GameState.delete_world(slot)
		_pending_delete = -1
	else:
		Audio.play("toggle")
		_pending_delete = slot
	_rebuild_worlds()


func _on_pick_language(l: String) -> void:
	Audio.play("toggle")
	Loc.set_language(l)


func _on_volume(v: float) -> void:
	Settings.set_value("volume", v)
	Audio.play("click")


func _on_open_link(url: String) -> void:
	Audio.play("click")
	OS.shell_open(url)


func _on_calibrate() -> void:
	Audio.play("click")
	var c := Calib.new()
	add_child(c)
	c.setup({"title": Loc.t("calibrate"), "up": Loc.t("calib_up"), "right": Loc.t("calib_right"),
		"retry": Loc.t("calib_retry"), "done": Loc.t("calib_done"), "ok": Loc.t("calib_ok"),
		"cancel": Loc.t("calib_cancel")}, _on_calibrated)


func _on_calibrated(ix: bool, iy: bool) -> void:
	Settings.data["joy_invert_x"] = ix
	Settings.data["joy_invert_y"] = iy
	Settings.save_settings()
	Audio.play("confirm")


func _on_quit() -> void:
	get_tree().quit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and current != "main":
		var back := {"worlds": "main", "create": "worlds", "character": "create", "settings": "main", "credits": "main"}
		_go(str(back.get(current, "main")))
