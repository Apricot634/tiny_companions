extends Control
## Mochila en forma de libro: Equipo (muneco + huecos + mochila), Magia y rango, Fabricacion y Mapa/Diario.
## Mover objetos: tocar un objeto y luego un hueco (mochila o equipo) lo mueve, equipa o intercambia.

const WildTheme := preload("res://ui/wild_theme.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")
const Appearances := preload("res://data/appearances.gd")
const T := preload("res://data/tiles.gd")
const INK := Color8(70, 44, 22)
const TAB_KEYS := ["tab_equip", "tab_magic", "tab_craft", "tab_map"]
const MAP_COLORS := {0: Color8(30, 60, 130), 1: Color8(70, 140, 214), 2: Color8(236, 214, 150), 3: Color8(150, 190, 70), 4: Color8(90, 140, 60),
	5: Color8(226, 190, 110), 6: Color8(104, 104, 116), 7: Color8(170, 166, 150), 8: Color8(180, 130, 80), 14: Color8(236, 242, 250),
	15: Color8(84, 110, 78), 16: Color8(150, 204, 80), 17: Color8(150, 130, 100), 18: Color8(222, 230, 240), 19: Color8(120, 104, 96), 24: Color8(130, 90, 52)}

var hud = null
var tab := 0
var sel := {}
var content: HBoxContainer
var tab_btns: Array = []
var close_btn: Button
var info_label: Label
var preview: TextureRect
var preview_atlas: AtlasTexture
var _recipe_sel := "torch"
var _t := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.65)
	add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var book := PanelContainer.new()
	book.add_theme_stylebox_override("panel", _style(Color8(214, 188, 140), Color8(110, 70, 34), 8, 4))
	center.add_child(book)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	vb.custom_minimum_size = Vector2(560, 270)
	book.add_child(vb)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 4)
	vb.add_child(header)
	for i in TAB_KEYS.size():
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, 28)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_show_tab.bind(i))
		header.add_child(b)
		tab_btns.append(b)
	close_btn = Button.new()
	close_btn.text = "X"
	close_btn.focus_mode = Control.FOCUS_NONE
	close_btn.custom_minimum_size = Vector2(34, 28)
	close_btn.pressed.connect(_on_close)
	header.add_child(close_btn)
	content = HBoxContainer.new()
	content.add_theme_constant_override("separation", 6)
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(content)


func _style(bg: Color, border: Color, radius: int, width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(width)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 8
	s.content_margin_right = 8
	s.content_margin_top = 6
	s.content_margin_bottom = 6
	return s


func _page() -> VBoxContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(Color8(246, 236, 206), Color8(150, 110, 64), 4, 2))
	p.custom_minimum_size = Vector2(266, 230)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_child(p)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	p.add_child(vb)
	return vb


func _lbl(text: String, size_px: int = 11, bold: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", Color8(150, 70, 20) if bold else INK)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


func open_book() -> void:
	visible = true
	sel = {}
	_show_tab(0)


func _on_close() -> void:
	hud.close_inventory()


func _show_tab(i: int) -> void:
	tab = i
	for c in content.get_children():
		c.queue_free()
	for k in tab_btns.size():
		tab_btns[k].text = Loc.t(TAB_KEYS[k])
		tab_btns[k].modulate = Color(1, 0.85, 0.4) if k == i else Color.WHITE
	preview = null
	preview_atlas = null
	match i:
		0:
			_build_equip()
		1:
			_build_magic()
		2:
			_build_craft()
		3:
			_build_map()
	Audio.play("click")


func _process(delta: float) -> void:
	_t += delta
	if preview_atlas != null and visible:
		var cols := [1, 0, 1, 2]
		preview_atlas.region = Rect2(int(cols[int(_t * 3.0) % 4]) * 16, 0, 16, 20)


# ------------------------------------------------------------ equipo
func _icon_of(id: String) -> Texture2D:
	return load(Items.icon_path(id))


func _slot_button(slot_name: String, is_eq: bool, index: int) -> Button:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(40, 40)
	b.add_theme_font_size_override("font_size", 9)
	b.expand_icon = true
	b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.set("vertical_icon_alignment", VERTICAL_ALIGNMENT_TOP)
	var id := ""
	if is_eq:
		id = str(GameState.equipped[slot_name])
		if id == "":
			b.text = Loc.t("slot_" + slot_name)
		else:
			b.icon = _icon_of(id)
		if sel.get("kind", "") == "eq" and sel.get("slot", "") == slot_name:
			b.modulate = Color(1, 0.9, 0.45)
		b.pressed.connect(_on_eq_slot.bind(slot_name))
	else:
		id = str(GameState.bag[index])
		if id != "":
			b.icon = _icon_of(id)
			var n := GameState.item_count(id)
			b.text = "x%d" % n if n > 1 else ""
		if sel.get("kind", "") == "bag" and int(sel.get("i", -1)) == index:
			b.modulate = Color(1, 0.9, 0.45)
		b.pressed.connect(_on_bag_slot.bind(index))
	return b


func _build_equip() -> void:
	var left := _page()
	left.add_child(_lbl(Loc.t("tab_equip"), 12, true))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 8)
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	left.add_child(hb)
	var colL := VBoxContainer.new()
	var colR := VBoxContainer.new()
	colL.add_theme_constant_override("separation", 4)
	colR.add_theme_constant_override("separation", 4)
	for s in ["head", "body", "feet"]:
		colL.add_child(_slot_button(s, true, 0))
	for s in ["weapon", "offhand", "ranged"]:
		colR.add_child(_slot_button(s, true, 0))
	preview_atlas = AtlasTexture.new()
	preview_atlas.atlas = load(Appearances.SHEET % GameState.appearance)
	preview_atlas.region = Rect2(16, 0, 16, 20)
	preview = TextureRect.new()
	preview.texture = preview_atlas
	preview.custom_minimum_size = Vector2(80, 110)
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hb.add_child(colL)
	hb.add_child(preview)
	hb.add_child(colR)
	var st := "%s %d/%d   %s %d/%d\n%s %d   %s %d\n%s" % [Loc.t("hud_hp"), int(GameState.hp), int(GameState.max_hp), Loc.t("hud_mp"), int(GameState.mp), int(GameState.max_mp),
		Loc.t("stat_def"), int(GameState.defense()), Loc.t("stat_gold"), GameState.gold, Loc.t("rank_%d" % GameState.magic_rank)]
	left.add_child(_lbl(st, 10))
	left.add_child(_lbl(Loc.t("equip_hint"), 9))
	var right := _page()
	right.add_child(_lbl(Loc.t("btn_inventory"), 12, true))
	var grid := GridContainer.new()
	grid.columns = 6
	grid.add_theme_constant_override("h_separation", 3)
	grid.add_theme_constant_override("v_separation", 3)
	right.add_child(grid)
	for i in GameState.BAG_SIZE:
		grid.add_child(_slot_button("", false, i))
	info_label = _lbl(_selection_info(), 10)
	info_label.custom_minimum_size = Vector2(0, 30)
	right.add_child(info_label)
	var use := Button.new()
	use.focus_mode = Control.FOCUS_NONE
	use.text = Loc.t("btn_use_item")
	use.custom_minimum_size = Vector2(0, 26)
	use.pressed.connect(_on_use_selected)
	right.add_child(use)


func _selected_id() -> String:
	if sel.get("kind", "") == "bag":
		return str(GameState.bag[int(sel["i"])])
	if sel.get("kind", "") == "eq":
		return str(GameState.equipped[str(sel["slot"])])
	return ""


func _selection_info() -> String:
	var id := _selected_id()
	if id == "" or not Items.ITEMS.has(id):
		return ""
	var it: Dictionary = Items.ITEMS[id]
	var s := Loc.t("item_" + id)
	if it.has("dmg"):
		s += "  " + Loc.t("info_dmg") % int(it["dmg"])
	if it.has("def") and float(it["def"]) > 0.0:
		s += "  " + Loc.t("info_def") % int(it["def"])
	s += "  " + Loc.t("info_price") % int(it["price"])
	return s


func _after_change() -> void:
	sel = {}
	_show_tab(tab)


func _on_bag_slot(i: int) -> void:
	var kind: String = str(sel.get("kind", ""))
	if kind == "":
		if str(GameState.bag[i]) != "":
			sel = {"kind": "bag", "i": i}
		_show_tab(tab)
		return
	if kind == "bag":
		if int(sel["i"]) != i:
			GameState.swap_bag(int(sel["i"]), i)
			Audio.play("toggle")
			_after_change()
		else:
			sel = {}
			_show_tab(tab)
		return
	# desde un hueco de equipo hacia la mochila: desequipar y colocar en el hueco elegido
	var slot_name := str(sel["slot"])
	var id := str(GameState.equipped[slot_name])
	GameState.unequip(slot_name)
	var j := GameState.bag.find(id)
	if j >= 0 and j != i:
		GameState.swap_bag(j, i)
	Audio.play("toggle")
	_after_change()


func _on_eq_slot(slot_name: String) -> void:
	var kind: String = str(sel.get("kind", ""))
	if kind == "bag":
		var id := str(GameState.bag[int(sel["i"])])
		if Items.slot_of(id) == slot_name:
			GameState.equip_from_bag(int(sel["i"]))
			Audio.play("confirm")
			_after_change()
		else:
			Audio.play("error")
			sel = {}
			_show_tab(tab)
		return
	if kind == "eq" and str(sel["slot"]) == slot_name:
		GameState.unequip(slot_name)
		Audio.play("toggle")
		_after_change()
		return
	if str(GameState.equipped[slot_name]) != "":
		sel = {"kind": "eq", "slot": slot_name}
	else:
		sel = {}
	_show_tab(tab)


func _on_use_selected() -> void:
	var id := _selected_id()
	if id == "":
		return
	if sel.get("kind", "") == "eq":
		GameState.unequip(str(sel["slot"]))
		_after_change()
		return
	var res := GameState.use_item(id)
	if res != "":
		Audio.play("heal" if res == "used" else "confirm")
	_after_change()


# ------------------------------------------------------------ magia
func _build_magic() -> void:
	var left := _page()
	left.add_child(_lbl(Loc.t("skills_title"), 12, true))
	left.add_child(_lbl(Loc.t("rank_%d" % GameState.magic_rank), 12))
	if GameState.magic_rank > 0 and GameState.magic_rank < 5:
		left.add_child(_lbl("%s: %d / %d" % [Loc.t("stat_xp"), int(GameState.magic_xp), int(Spells.RANK_XP[GameState.magic_rank + 1])], 10))
	elif GameState.magic_rank >= 5:
		left.add_child(_lbl("%s: %d" % [Loc.t("stat_xp"), int(GameState.magic_xp)], 10))
	left.add_child(_lbl("%s %d   %s %d" % [Loc.t("stat_def"), int(GameState.defense()), Loc.t("stat_gold"), GameState.gold], 10))
	var w := GameState.weapon_id()
	if w != "" and Items.ITEMS.has(w):
		left.add_child(_lbl("%s: %s (%s)" % [Loc.t("slot_weapon"), Loc.t("item_" + w), Loc.t("info_dmg") % int(Items.ITEMS[w].get("dmg", 0))], 10))
	if GameState.known_spells.is_empty():
		left.add_child(_lbl(Loc.t("no_spells"), 10))
	var right := _page()
	right.add_child(_lbl(Loc.t("tab_magic"), 12, true))
	for sid in Spells.ORDER:
		var sp: Dictionary = Spells.SPELLS[sid]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		var icon := TextureRect.new()
		icon.texture = load(Spells.icon_path(sid))
		icon.custom_minimum_size = Vector2(24, 24)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		row.add_child(icon)
		var known: bool = GameState.known_spells.has(sid)
		var txt := "%s  (%s %d)" % [Loc.t("spell_" + sid), Loc.t("hud_mp"), int(sp["mana"])]
		if not known:
			if GameState.magic_rank < int(sp["rank"]):
				txt += "\n" + Loc.t("spell_locked") % int(sp["rank"])
			else:
				txt += "\n%d %s" % [int(sp["learn"]), Loc.t("hud_gold")]
		var l := _lbl(txt, 10)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		if known:
			var b := Button.new()
			b.focus_mode = Control.FOCUS_NONE
			b.text = Loc.t("spell_select")
			b.custom_minimum_size = Vector2(60, 24)
			if GameState.selected_spell == sid:
				b.modulate = Color(1, 0.85, 0.35)
			b.pressed.connect(_on_pick_spell.bind(str(sid)))
			row.add_child(b)
		else:
			row.modulate = Color(1, 1, 1, 0.7)
		right.add_child(row)


func _on_pick_spell(sid: String) -> void:
	GameState.selected_spell = sid
	Audio.play("toggle")
	GameState.changed.emit()
	_show_tab(tab)


# ------------------------------------------------------------ fabricacion
func _build_craft() -> void:
	var left := _page()
	left.add_child(_lbl(Loc.t("tab_craft"), 12, true))
	for rid in Items.RECIPE_ORDER:
		var r: Dictionary = Items.RECIPES[rid]
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.icon = _icon_of(str(r["out"]))
		b.text = " %s x%d" % [Loc.t("item_" + str(r["out"])), int(r["n"])]
		b.custom_minimum_size = Vector2(0, 30)
		if rid == _recipe_sel:
			b.modulate = Color(1, 0.88, 0.45)
		b.pressed.connect(_on_pick_recipe.bind(str(rid)))
		left.add_child(b)
	var right := _page()
	var r2: Dictionary = Items.RECIPES[_recipe_sel]
	right.add_child(_lbl("%s x%d" % [Loc.t("item_" + str(r2["out"])), int(r2["n"])], 12, true))
	right.add_child(_lbl(Loc.t("craft_needs"), 10))
	var needs: Dictionary = r2["needs"]
	for k in needs.keys():
		var have := GameState.item_count(str(k))
		var l := _lbl("%s: %d / %d" % [Loc.t("item_" + str(k)), have, int(needs[k])], 11)
		l.modulate = Color(0.2, 0.6, 0.2) if have >= int(needs[k]) else Color(0.8, 0.2, 0.2)
		right.add_child(l)
	if r2.has("needs_known") and not GameState.known_recipes.has(str(r2["needs_known"])):
		right.add_child(_lbl(Loc.t("needs_alchemy"), 10))
	var cb := Button.new()
	cb.focus_mode = Control.FOCUS_NONE
	cb.text = Loc.t("craft_button")
	cb.custom_minimum_size = Vector2(0, 32)
	cb.pressed.connect(_on_craft)
	right.add_child(cb)
	info_label = _lbl("", 10)
	right.add_child(info_label)


func _on_pick_recipe(rid: String) -> void:
	_recipe_sel = rid
	_show_tab(tab)


func _on_craft() -> void:
	var err := GameState.craft(_recipe_sel)
	if err == "":
		Audio.play("confirm")
		var out := str(Items.RECIPES[_recipe_sel]["out"])
		_show_tab(tab)
		info_label.text = Loc.t("craft_done") % Loc.t("item_" + out)
	else:
		Audio.play("error")
		info_label.text = Loc.t(err)


# ------------------------------------------------------------ mapa y diario
func _build_map() -> void:
	var left := _page()
	left.add_child(_lbl(Loc.t("journal_title"), 12, true))
	var q: Dictionary = GameState.quest
	if q.is_empty():
		left.add_child(_lbl(Loc.t("quest_none"), 10))
	elif str(q["type"]) == "kill":
		left.add_child(_lbl(Loc.t("quest_kill") % [int(q["need"]), Loc.t("sp_" + str(q["species"])), int(q["count"]), int(q["need"])], 11))
		left.add_child(_lbl("%s: %d %s" % [Loc.t("stat_gold"), int(q["reward"]), ""], 10))
	else:
		left.add_child(_lbl(Loc.t("quest_fetch") % [int(q["need"]), Loc.t("item_" + str(q["item"])), GameState.item_count(str(q["item"])), int(q["need"])], 11))
		left.add_child(_lbl("%s: %d" % [Loc.t("stat_gold"), int(q["reward"])], 10))
	left.add_child(_lbl("%s: %s" % [Loc.t("hud_gold"), str(GameState.gold)], 10))
	var right := _page()
	right.add_child(_lbl(Loc.t("map_title"), 12, true))
	if hud != null and hud.world != null and GameState.dimension == "overworld":
		var tr := TextureRect.new()
		tr.texture = _make_map()
		tr.custom_minimum_size = Vector2(216, 216)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		right.add_child(tr)
	else:
		right.add_child(_lbl("-", 11))


func _make_map() -> ImageTexture:
	var size_px := 72
	var step := 8
	var img := Image.create(size_px, size_px, false, Image.FORMAT_RGBA8)
	var ter = hud.world.terrain
	var pt := Vector2i(floori(GameState.pos.x / 16.0), floori(GameState.pos.y / 16.0))
	for y in size_px:
		for x in size_px:
			var t: int = ter.tile_at(pt.x + (x - size_px / 2) * step, pt.y + (y - size_px / 2) * step)
			img.set_pixel(x, y, MAP_COLORS.get(t, Color8(120, 120, 120)))
	var c0: Vector2i = ter._cell_of(pt.x, pt.y)
	for dx in range(-4, 5):
		for dy in range(-4, 5):
			var cell := Vector2i(c0.x + dx, c0.y + dy)
			var v: Dictionary = ter.village_in_cell(cell)
			if not v.is_empty():
				_dot(img, 36 + (int(v["tx"]) - pt.x) / step, 36 + (int(v["ty"]) - pt.y) / step, Color8(220, 60, 60), 1)
			var cave: Dictionary = ter.cave_in_cell(cell)
			if not cave.is_empty():
				_dot(img, 36 + (int(cave["tx"]) - pt.x) / step, 36 + (int(cave["ty"]) - pt.y) / step, Color8(20, 20, 30), 0)
	_dot(img, 36, 36, Color.WHITE, 1)
	return ImageTexture.create_from_image(img)


func _dot(img: Image, cx: int, cy: int, col: Color, r: int) -> void:
	for y in range(cy - r, cy + r + 1):
		for x in range(cx - r, cx + r + 1):
			if x >= 0 and y >= 0 and x < img.get_width() and y < img.get_height():
				img.set_pixel(x, y, col)
