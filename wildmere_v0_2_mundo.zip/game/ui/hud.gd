extends CanvasLayer
## Interfaz de juego: barras, botones tactiles (multitoque), selector de hechizo, dialogos con opciones,
## tiendas, mochila-libro, jefe, region, hora y pausa.

signal action_attack
signal action_bow_begin
signal action_bow_end
signal action_spell_begin
signal action_spell_end
signal action_block(is_on: bool)
signal action_dash
signal action_interact

const WildTheme := preload("res://ui/wild_theme.gd")
const Joystick := preload("res://ui/virtual_joystick.gd")
const TouchButton := preload("res://ui/touch_button.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const BookScript := preload("res://ui/book.gd")
const ShopScript := preload("res://ui/shop_panel.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")

var world = null
var ui: Control
var joystick
var bars := {}
var name_label: Label
var gold_label: Label
var spell_label: Label
var quest_label: Label
var toast_label: Label
var region_label: Label
var msg_label: Label
var boss_bar: ProgressBar
var boss_label: Label
var btns := {}
var spell_btns: Array = []
var interact_btn
var book
var shop
var menu_panel: PanelContainer
var menu_name: Label
var menu_text: Label
var menu_opts: VBoxContainer
var dlg_panel: PanelContainer
var dlg_name: Label
var dlg_text: Label
var pause_overlay: Control
var pause_title: Label
var pause_btns := {}
var volume_label: Label
var fade: ColorRect
var _toast_t := 0.0
var _msg_t := 0.0
var _region_t := 0.0
var _dlg_lines: Array = []
var _dlg_i := 0
var _dlg_cb: Callable
var _menu_cb: Callable
var _spell_sig := ""
var dialogue_open := false
var panel_open := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	ui = Control.new()
	ui.theme = WildTheme.make(11)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	joystick = Joystick.new()
	ui.add_child(joystick)
	_build_status()
	_build_buttons()
	_build_top()
	_build_texts()
	_build_dialogue()
	_build_menu()
	book = BookScript.new()
	book.visible = false
	ui.add_child(book)
	book.hud = self
	shop = ShopScript.new()
	shop.visible = false
	ui.add_child(shop)
	shop.hud = self
	_build_pause()
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 0)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.resized.connect(_layout)
	Loc.language_changed.connect(_refresh_texts)
	GameState.changed.connect(_refresh)
	_layout()
	_refresh_texts()


# ------------------------------------------------------------ construccion
func _bar(parent: Control, key: String, color: Color) -> void:
	var row := HBoxContainer.new()
	var lbl := Label.new()
	lbl.custom_minimum_size = Vector2(34, 0)
	lbl.add_theme_font_size_override("font_size", 10)
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(96, 9)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.show_percentage = false
	bar.max_value = 100.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(2)
	bar.add_theme_stylebox_override("fill", fill)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.05, 0.06, 0.1, 0.85)
	bg.set_corner_radius_all(2)
	bar.add_theme_stylebox_override("background", bg)
	row.add_child(lbl)
	row.add_child(bar)
	parent.add_child(row)
	bars[key] = {"bar": bar, "label": lbl}


func _build_status() -> void:
	var panel := PanelContainer.new()
	ui.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	panel.add_child(vb)
	name_label = Label.new()
	vb.add_child(name_label)
	_bar(vb, "hp", Color8(220, 70, 70))
	_bar(vb, "mp", Color8(80, 140, 240))
	_bar(vb, "food", Color8(230, 160, 60))
	gold_label = Label.new()
	vb.add_child(gold_label)
	spell_label = Label.new()
	spell_label.add_theme_font_size_override("font_size", 10)
	vb.add_child(spell_label)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT, Control.PRESET_MODE_MINSIZE, 10)
	quest_label = Label.new()
	quest_label.add_theme_font_size_override("font_size", 10)
	quest_label.add_theme_constant_override("outline_size", 3)
	quest_label.add_theme_color_override("font_outline_color", Color.BLACK)
	quest_label.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	ui.add_child(quest_label)


func _tb(id: String, r: float, icon_path: String = "", label: String = "") -> Control:
	var b = TouchButton.new()
	b.label = label
	b.radius = r
	if icon_path != "":
		b.icon = load(icon_path)
	ui.add_child(b)
	b.set_radius(r)
	btns[id] = b
	return b


func _build_buttons() -> void:
	var a = _tb("attack", 34.0, "res://assets/items/sword.png")
	a.pressed.connect(func(): action_attack.emit())
	var bw = _tb("bow", 26.0, "res://assets/items/bow.png")
	bw.pressed.connect(func(): action_bow_begin.emit())
	bw.released.connect(func(): action_bow_end.emit())
	var sp = _tb("spell", 26.0, "res://assets/items/sp_fire.png")
	sp.pressed.connect(func(): action_spell_begin.emit())
	sp.released.connect(func(): action_spell_end.emit())
	var sh = _tb("block", 24.0, "res://assets/items/shield.png")
	sh.pressed.connect(func(): action_block.emit(true))
	sh.released.connect(func(): action_block.emit(false))
	var dh = _tb("dash", 24.0, "res://assets/items/boots.png")
	dh.pressed.connect(func(): action_dash.emit())
	interact_btn = _tb("interact", 28.0, "", "")
	interact_btn.pressed.connect(func(): action_interact.emit())
	interact_btn.visible = false


func _build_top() -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	ui.add_child(row)
	var inv := Button.new()
	inv.focus_mode = Control.FOCUS_NONE
	inv.custom_minimum_size = Vector2(74, 32)
	inv.pressed.connect(_on_inventory_button)
	var pb := Button.new()
	pb.focus_mode = Control.FOCUS_NONE
	pb.custom_minimum_size = Vector2(36, 32)
	pb.text = "II"
	pb.pressed.connect(_on_pause_button)
	row.add_child(inv)
	row.add_child(pb)
	row.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 10)
	row.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	btns["inv_top"] = inv


func _label_outlined(size_px: int, col: Color) -> Label:
	var l := Label.new()
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_color_override("font_outline_color", Color8(30, 24, 10))
	l.add_theme_color_override("font_color", col)
	l.modulate.a = 0.0
	ui.add_child(l)
	return l


func _build_texts() -> void:
	toast_label = _label_outlined(13, Color.WHITE)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	toast_label.offset_top = 70
	toast_label.offset_bottom = 92
	msg_label = _label_outlined(22, Color8(255, 220, 120))
	msg_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	msg_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	msg_label.offset_top = -80
	msg_label.offset_bottom = -50
	region_label = _label_outlined(15, Color8(255, 240, 200))
	region_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	region_label.offset_top = 14
	region_label.offset_bottom = 38
	boss_label = _label_outlined(12, Color8(255, 190, 150))
	boss_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	boss_label.offset_top = 40
	boss_label.offset_bottom = 56
	boss_bar = ProgressBar.new()
	boss_bar.show_percentage = false
	boss_bar.max_value = 100.0
	boss_bar.custom_minimum_size = Vector2(220, 9)
	boss_bar.visible = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color8(200, 50, 50)
	boss_bar.add_theme_stylebox_override("fill", fill)
	ui.add_child(boss_bar)
	boss_bar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 58)
	boss_bar.grow_horizontal = Control.GROW_DIRECTION_BOTH


func _build_dialogue() -> void:
	dlg_panel = PanelContainer.new()
	dlg_panel.visible = false
	ui.add_child(dlg_panel)
	var vb := VBoxContainer.new()
	dlg_panel.add_child(vb)
	dlg_name = Label.new()
	dlg_name.add_theme_color_override("font_color", WildTheme.GOLD)
	dlg_text = Label.new()
	dlg_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dlg_text.custom_minimum_size = Vector2(400, 44)
	vb.add_child(dlg_name)
	vb.add_child(dlg_text)
	dlg_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 12)
	dlg_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	dlg_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	var tap := Button.new()
	tap.flat = true
	tap.focus_mode = Control.FOCUS_NONE
	tap.pressed.connect(_advance_dialogue)
	dlg_panel.add_child(tap)
	tap.modulate.a = 0.0


func _build_menu() -> void:
	menu_panel = PanelContainer.new()
	menu_panel.visible = false
	ui.add_child(menu_panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	menu_panel.add_child(vb)
	menu_name = Label.new()
	menu_name.add_theme_color_override("font_color", WildTheme.GOLD)
	menu_text = Label.new()
	menu_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_text.custom_minimum_size = Vector2(400, 36)
	menu_opts = VBoxContainer.new()
	menu_opts.add_theme_constant_override("separation", 3)
	vb.add_child(menu_name)
	vb.add_child(menu_text)
	vb.add_child(menu_opts)
	menu_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM, Control.PRESET_MODE_MINSIZE, 8)
	menu_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	menu_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN


func _build_pause() -> void:
	pause_overlay = ColorRect.new()
	(pause_overlay as ColorRect).color = Color(0, 0, 0, 0.6)
	pause_overlay.visible = false
	ui.add_child(pause_overlay)
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	pause_overlay.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 5)
	vb.custom_minimum_size = Vector2(190, 0)
	panel.add_child(vb)
	pause_title = Label.new()
	pause_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_title.add_theme_color_override("font_color", WildTheme.GOLD)
	vb.add_child(pause_title)
	var defs := {"resume": _on_resume, "save": _on_save, "language": _on_language, "calibrate": _on_calibrate, "main_menu": _on_main_menu}
	for id in defs.keys():
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 32)
		b.focus_mode = Control.FOCUS_NONE
		var cb: Callable = defs[id]
		b.pressed.connect(cb)
		vb.add_child(b)
		pause_btns[id] = b
	volume_label = Label.new()
	vb.add_child(volume_label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.1
	slider.value = float(Settings.data["volume"])
	slider.custom_minimum_size = Vector2(0, 20)
	slider.value_changed.connect(_on_volume)
	vb.add_child(slider)


# ------------------------------------------------------------ distribucion
func _layout() -> void:
	var s := ui.size
	var c := Vector2(s.x - 84.0, s.y - 84.0)
	_place("attack", c)
	_place("bow", c + Vector2(-74, 16))
	_place("spell", c + Vector2(-60, -60))
	_place("block", c + Vector2(14, -78))
	_place("dash", c + Vector2(-122, -34))
	_place("interact", c + Vector2(-20, -140))
	_layout_spells()
	quest_label.position = Vector2(12, 128)


func _layout_spells() -> void:
	var s := ui.size
	for i in spell_btns.size():
		var b = spell_btns[i]
		b.position = Vector2(s.x - 30.0 - b.radius, 62.0 + i * 36.0)


func _place(id: String, center_pos: Vector2) -> void:
	var b = btns[id]
	b.position = center_pos - Vector2(b.radius, b.radius)


func _rebuild_spell_strip() -> void:
	for b in spell_btns:
		b.queue_free()
	spell_btns.clear()
	for sid in GameState.known_spells:
		var b = TouchButton.new()
		b.radius = 15.0
		b.icon = load(Spells.icon_path(str(sid)))
		ui.add_child(b)
		b.set_radius(15.0)
		b.set_meta("spell_id", str(sid))
		b.pressed.connect(_on_spell_pick.bind(str(sid)))
		spell_btns.append(b)
	_layout_spells()


func _on_spell_pick(sid: String) -> void:
	GameState.selected_spell = sid
	Audio.play("toggle")
	toast_text(Loc.t("spell_selected") % Loc.t("spell_" + sid))
	GameState.changed.emit()


# ------------------------------------------------------------ textos y estado
func _refresh_texts() -> void:
	bars["hp"]["label"].text = Loc.t("hud_hp")
	bars["mp"]["label"].text = Loc.t("hud_mp")
	bars["food"]["label"].text = Loc.t("hud_food")
	btns["interact"].label = Loc.t("btn_interact")
	btns["interact"].queue_redraw()
	btns["inv_top"].text = Loc.t("btn_inventory")
	pause_title.text = Loc.t("pause")
	pause_btns["resume"].text = Loc.t("resume")
	pause_btns["save"].text = Loc.t("save")
	pause_btns["language"].text = "%s: %s" % [Loc.t("language"), Loc.LANG_NAMES[Loc.lang]]
	pause_btns["calibrate"].text = Loc.t("calibrate")
	pause_btns["main_menu"].text = Loc.t("main_menu")
	volume_label.text = Loc.t("sound")
	_refresh()


func _refresh() -> void:
	if not GameState.active:
		return
	name_label.text = GameState.player_name
	(bars["hp"]["bar"] as ProgressBar).value = GameState.hp / maxf(1.0, GameState.max_hp) * 100.0
	(bars["mp"]["bar"] as ProgressBar).value = GameState.mp / maxf(1.0, GameState.max_mp) * 100.0
	(bars["food"]["bar"] as ProgressBar).value = GameState.hunger
	gold_label.text = "%s: %d   %s" % [Loc.t("hud_gold"), GameState.gold, GameState.clock_text()]
	var sid := GameState.selected_spell
	spell_label.text = Loc.t("spell_" + sid) if sid != "" else ""
	var sig := str(GameState.known_spells)
	if sig != _spell_sig:
		_spell_sig = sig
		_rebuild_spell_strip()
	for b in spell_btns:
		b.selected = str(b.get_meta("spell_id")) == sid
		b.queue_redraw()
	btns["spell"].dim = (sid == "")
	if sid != "":
		btns["spell"].icon = load(Spells.icon_path(sid))
	btns["bow"].dim = str(GameState.equipped["ranged"]) != "bow"
	btns["block"].dim = str(GameState.equipped["offhand"]) != "shield"
	var w := GameState.weapon_id()
	if w != "" and Items.ITEMS.has(w):
		btns["attack"].icon = load(Items.icon_path(w))
	btns["attack"].queue_redraw()
	btns["spell"].queue_redraw()
	_refresh_quest()
	if world != null:
		world.player.refresh_weapon()


func _refresh_quest() -> void:
	var q: Dictionary = GameState.quest
	if q.is_empty():
		quest_label.text = ""
		return
	if str(q["type"]) == "kill":
		quest_label.text = Loc.t("quest_kill") % [int(q["need"]), Loc.t("sp_" + str(q["species"])), int(q["count"]), int(q["need"])]
	else:
		quest_label.text = Loc.t("quest_fetch") % [int(q["need"]), Loc.t("item_" + str(q["item"])), GameState.item_count(str(q["item"])), int(q["need"])]


func process_cooldowns(p) -> void:
	btns["attack"].cooldown = clampf(p.attack_cd / 0.42, 0.0, 1.0)
	btns["bow"].cooldown = clampf(p.bow_cd / 0.55, 0.0, 1.0)
	btns["spell"].cooldown = clampf(p.spell_cd / 1.2, 0.0, 1.0)
	btns["dash"].cooldown = clampf(p.dash_cd / 0.9, 0.0, 1.0)
	for k in ["attack", "bow", "spell", "dash"]:
		btns[k].queue_redraw()


func set_interact(show_btn: bool) -> void:
	interact_btn.visible = show_btn


# ------------------------------------------------------------ avisos
func toast(key: String) -> void:
	toast_label.text = Loc.t(key)
	_toast_t = 2.2


func toast_text(text: String) -> void:
	toast_label.text = text
	_toast_t = 2.2


func big_message(key: String) -> void:
	msg_label.text = Loc.t(key)
	_msg_t = 3.0


func big_message_text(text: String) -> void:
	msg_label.text = text
	_msg_t = 3.0


func show_region(text: String) -> void:
	region_label.text = text
	_region_t = 3.5


func show_boss(boss_name: String) -> void:
	boss_label.text = boss_name
	boss_label.modulate.a = 1.0
	boss_bar.value = 100.0
	boss_bar.visible = true


func update_boss(ratio: float) -> void:
	boss_bar.value = clampf(ratio, 0.0, 1.0) * 100.0


func hide_boss() -> void:
	boss_bar.visible = false
	boss_label.modulate.a = 0.0


func do_fade() -> void:
	fade.color = Color(0, 0, 0, 1)
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 0.0, 0.5)


func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		toast_label.modulate.a = clampf(_toast_t / 0.5, 0.0, 1.0)
	if _msg_t > 0.0:
		_msg_t -= delta
		msg_label.modulate.a = clampf(_msg_t / 0.8, 0.0, 1.0)
	if _region_t > 0.0:
		_region_t -= delta
		region_label.modulate.a = clampf(_region_t / 0.8, 0.0, 1.0)


# ------------------------------------------------------------ dialogos
func show_dialogue(speaker: String, lines: Array, cb: Callable = Callable()) -> void:
	_dlg_lines = lines
	_dlg_i = 0
	_dlg_cb = cb
	dlg_name.text = speaker
	menu_panel.visible = false
	dlg_panel.visible = true
	dialogue_open = true
	_show_line()


func _show_line() -> void:
	dlg_text.text = str(_dlg_lines[_dlg_i])
	Audio.play("dialog")


func _advance_dialogue() -> void:
	if not dialogue_open or not dlg_panel.visible:
		return
	_dlg_i += 1
	if _dlg_i >= _dlg_lines.size():
		dlg_panel.visible = false
		dialogue_open = false
		if _dlg_cb.is_valid():
			_dlg_cb.call()
	else:
		_show_line()


## Dialogo con opciones. options = [{id, label}]; cb(option_id).
func show_menu(speaker: String, text: String, options: Array, cb: Callable) -> void:
	menu_name.text = speaker
	menu_text.text = text
	_menu_cb = cb
	for c in menu_opts.get_children():
		c.queue_free()
	for o in options:
		var b := Button.new()
		b.text = str(o["label"])
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, 30)
		b.pressed.connect(_on_menu_pick.bind(str(o["id"])))
		menu_opts.add_child(b)
	dlg_panel.visible = false
	menu_panel.visible = true
	dialogue_open = true


func _on_menu_pick(opt_id: String) -> void:
	menu_panel.visible = false
	dialogue_open = false
	Audio.play("click")
	if _menu_cb.is_valid():
		_menu_cb.call(opt_id)


# ------------------------------------------------------------ paneles (mochila, tienda)
func _on_inventory_button() -> void:
	Audio.play("open")
	open_inventory()


func open_inventory() -> void:
	if get_tree().paused or panel_open:
		return
	panel_open = true
	get_tree().paused = true
	book.open_book()


func close_inventory() -> void:
	Audio.play("back")
	book.visible = false
	panel_open = false
	get_tree().paused = false
	if world != null:
		world.player.refresh_weapon()


func open_shop(kind: String, ctx: Dictionary) -> void:
	if panel_open:
		return
	panel_open = true
	get_tree().paused = true
	shop.open_shop(kind, ctx)


func open_teacher() -> void:
	if panel_open:
		return
	panel_open = true
	get_tree().paused = true
	shop.open_teacher()


func close_shop() -> void:
	shop.visible = false
	panel_open = false
	get_tree().paused = false
	Audio.play("back")


# ------------------------------------------------------------ pausa
func _on_pause_button() -> void:
	Audio.play("click")
	set_paused(true)


func set_paused(v: bool) -> void:
	if panel_open:
		return
	if get_tree().paused == v:
		return
	get_tree().paused = v
	pause_overlay.visible = v
	joystick.reset()
	for k in ["attack", "bow", "spell", "block", "dash", "interact"]:
		btns[k].cancel()
	for b in spell_btns:
		b.cancel()
	Audio.play("open" if v else "back")
	if v:
		GameState.save_game()


func _on_resume() -> void:
	set_paused(false)


func _on_save() -> void:
	if GameState.save_game():
		Audio.play("confirm")
		toast("saved")
	else:
		Audio.play("error")
		toast("save_failed")


func _on_language() -> void:
	Audio.play("toggle")
	Loc.next_language()


func _on_volume(v: float) -> void:
	Settings.set_value("volume", v)


func _on_calibrate() -> void:
	Audio.play("click")
	var c := Calib.new()
	ui.add_child(c)
	c.setup({"title": Loc.t("calibrate"), "up": Loc.t("calib_up"), "right": Loc.t("calib_right"),
		"retry": Loc.t("calib_retry"), "done": Loc.t("calib_done"), "ok": Loc.t("calib_ok"),
		"cancel": Loc.t("calib_cancel")}, _on_calibrated)


func _on_calibrated(ix: bool, iy: bool) -> void:
	Settings.data["joy_invert_x"] = ix
	Settings.data["joy_invert_y"] = iy
	Settings.save_settings()


func _on_main_menu() -> void:
	GameState.save_game()
	GameState.active = false
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _cycle_spell() -> void:
	if GameState.known_spells.size() <= 1:
		return
	var i := GameState.known_spells.find(GameState.selected_spell)
	_on_spell_pick(str(GameState.known_spells[(i + 1) % GameState.known_spells.size()]))


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if book.visible:
			close_inventory()
		elif shop.visible:
			close_shop()
		else:
			set_paused(not get_tree().paused)
		get_viewport().set_input_as_handled()
		return
	if get_tree().paused:
		return
	if dialogue_open:
		if dlg_panel.visible and (event.is_action_pressed("interact") or event.is_action_pressed("act_attack")):
			_advance_dialogue()
		return
	if event.is_action_pressed("act_attack"):
		action_attack.emit()
	elif event.is_action_pressed("act_bow"):
		action_bow_begin.emit()
	elif event.is_action_released("act_bow"):
		action_bow_end.emit()
	elif event.is_action_pressed("act_spell"):
		action_spell_begin.emit()
	elif event.is_action_released("act_spell"):
		action_spell_end.emit()
	elif event.is_action_pressed("act_dash"):
		action_dash.emit()
	elif event.is_action_pressed("act_cycle"):
		_cycle_spell()
	elif event.is_action_pressed("interact"):
		action_interact.emit()
	elif event.is_action_pressed("inventory"):
		open_inventory()
	if event.is_action_pressed("act_block"):
		action_block.emit(true)
	elif event.is_action_released("act_block"):
		action_block.emit(false)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if book.visible:
			close_inventory()
		elif shop.visible:
			close_shop()
		else:
			set_paused(not get_tree().paused)
