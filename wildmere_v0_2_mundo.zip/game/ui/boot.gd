extends Control
## Pantalla de arranque con el nombre del juego. Tocar o pulsar una tecla = saltar.

const WildTheme := preload("res://ui/wild_theme.gd")

var title: TextureRect
var sub: Label
var _t := 0.0
var _done := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = WildTheme.make(14)
	var bg := ColorRect.new()
	bg.color = WildTheme.BG
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	title = TextureRect.new()
	title.texture = load("res://assets/ui/logo.png")
	title.stretch_mode = TextureRect.STRETCH_KEEP_CENTERED
	title.modulate.a = 0.0
	add_child(title)
	sub = Label.new()
	sub.text = Loc.t("subtitle")
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.modulate.a = 0.0
	add_child(sub)
	resized.connect(_layout)
	_layout()
	if "--autotest" in OS.get_cmdline_user_args():
		_run_autotest.call_deferred()


func _layout() -> void:
	title.position = Vector2((size.x - 480.0) / 2.0, size.y * 0.30)
	title.size = Vector2(480, 144)
	sub.position = Vector2(0, size.y * 0.30 + 150)
	sub.size = Vector2(size.x, 24)


func _process(delta: float) -> void:
	_t += delta
	title.modulate.a = clampf(_t / 0.8, 0.0, 1.0)
	sub.modulate.a = clampf((_t - 0.5) / 0.8, 0.0, 1.0)
	if _t > 2.4 and not _done:
		_finish()


func _input(event: InputEvent) -> void:
	if _done:
		return
	if (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed) \
			or (event is InputEventKey and event.pressed):
		_finish()


func _finish() -> void:
	_done = true
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _run_autotest() -> void:
	_done = true
	var script: GDScript = load("res://tests/autotest.gd")
	var node: Node = script.new()
	add_child(node)
	node.run()
