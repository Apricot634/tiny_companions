extends RefCounted
## Aldeas y pueblos con diseños distintos: cruce, plaza circular, calle, fortaleza y granja.
## Devuelve edificios, decorado, habitantes y los tiles de caminos/murallas/campos.

const T := preload("res://data/tiles.gd")
const Names := preload("res://data/names.gd")
const KINDS := ["crossroads", "ring", "street", "fortress", "farm"]
const NPC_SKINS := [6, 10, 14, 15, 17, 18, 19, 22, 29, 30, 31, 32, 12, 20, 27]


## Huella de un edificio relativa a su ancla (centro-base): x desde, ancho, y desde, alto.
static func footprint(btype: String) -> Rect2i:
	match btype:
		"hut":
			return Rect2i(-1, -1, 3, 2)
		"tower":
			return Rect2i(-1, -2, 3, 3)
		"stall":
			return Rect2i(-1, 0, 3, 1)
		"well", "haystack":
			return Rect2i(0, 0, 1, 1)
		"castle_tower":
			return Rect2i(-1, -2, 2, 3)
	return Rect2i(-2, -2, 5, 3)


static func sprite_for(btype: String, variant: int) -> String:
	var k := variant % 3 + 1
	match btype:
		"shop":
			return "house%d_coin" % k
		"inn":
			return "house%d_bed" % k
		"smith":
			return "house%d_anvil" % k
		"hut", "tower":
			return "hut" if btype == "hut" else "wizard_tower"
		"house":
			return "house%d" % k
	return btype


static func _pick_types(r: RandomNumberGenerator, slots: int) -> Array:
	var types: Array = ["shop"]
	if r.randf() < 0.8:
		types.append("inn")
	if r.randf() < 0.55:
		types.append("smith")
	if r.randf() < 0.3:
		types.append("tower")
	if r.randf() < 0.4:
		types.append("hut")
	while types.size() < slots:
		types.append("house")
	types.resize(slots)
	# mezclar
	for i in range(types.size() - 1, 0, -1):
		var j := r.randi_range(0, i)
		var tmp = types[i]
		types[i] = types[j]
		types[j] = tmp
	return types


static func build(vx: int, vy: int, id: String, seed_value: int, forced_kind: String = "") -> Dictionary:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value
	var kind := forced_kind if forced_kind != "" else KINDS[r.randi() % KINDS.size()]
	var tiles := {}
	var slots: Array = []
	var decor: Array = []
	var guards: Array = []
	var radius := 16
	var plaza := Vector2i(3, 3)
	var path_tile := T.PATH
	match kind:
		"crossroads":
			radius = 15
			for d in range(-radius, radius + 1):
				for w in range(-1, 2):
					tiles[Vector2i(vx + d, vy + w)] = T.PATH
					tiles[Vector2i(vx + w, vy + d)] = T.PATH
			slots = [Vector2i(-9, -4), Vector2i(9, -4), Vector2i(-9, 9), Vector2i(9, 9)]
			if r.randf() < 0.6:
				slots.append(Vector2i(-9, -13))
			decor.append({"type": "well", "tx": vx + 3, "ty": vy + 4})
		"ring":
			radius = 17
			for dx in range(-radius, radius + 1):
				for dy in range(-radius, radius + 1):
					var dd := Vector2(dx, dy).length()
					if dd <= 4.0 or (dd >= 7.5 and dd <= 8.8) or (absi(dx) <= 0 and dd < 9.0) or (absi(dy) <= 0 and dd < 9.0):
						tiles[Vector2i(vx + dx, vy + dy)] = T.PATH
			for k in 6:
				var a := deg_to_rad(30.0 + k * 60.0)
				slots.append(Vector2i(roundi(cos(a) * 13.0), roundi(sin(a) * 13.0)))
			decor.append({"type": "well", "tx": vx, "ty": vy})
			decor.append({"type": "stall", "tx": vx - 3, "ty": vy + 6})
			decor.append({"type": "stall", "tx": vx + 4, "ty": vy - 4})
			plaza = Vector2i(2, 5)
		"street":
			radius = 18
			for d in range(-radius + 1, radius):
				for w in range(0, 2):
					tiles[Vector2i(vx + d, vy + w)] = T.PATH
			for x in [-12, -4, 4, 12]:
				slots.append(Vector2i(x, -3))
				slots.append(Vector2i(x, 8))
			decor.append({"type": "well", "tx": vx, "ty": vy + 3})
			decor.append({"type": "stall", "tx": vx + 8, "ty": vy + 3})
			plaza = Vector2i(-3, 3)
		"fortress":
			radius = 20
			path_tile = T.CASTLE
			for x in range(-17, 18):
				for y in range(-13, 14):
					var edge := (x == -17 or x == 17 or y == -13 or y == 13)
					if edge and not (y == 13 and absi(x) <= 1):
						tiles[Vector2i(vx + x, vy + y)] = T.BRICK
					elif absi(x) <= 1 or absi(y) <= 1:
						tiles[Vector2i(vx + x, vy + y)] = T.CASTLE
			for d in range(14, 20):
				for w in range(-1, 2):
					tiles[Vector2i(vx + w, vy + d)] = T.PATH
			slots = [Vector2i(-10, -6), Vector2i(10, -6), Vector2i(-10, 8), Vector2i(10, 8)]
			for c in [Vector2i(-17, -13), Vector2i(17, -13), Vector2i(-17, 13), Vector2i(17, 13)]:
				decor.append({"type": "castle_tower", "tx": vx + c.x, "ty": vy + c.y + 1})
			decor.append({"type": "well", "tx": vx + 3, "ty": vy + 4})
			guards = [Vector2i(-3, 11), Vector2i(3, 11), Vector2i(-5, -2), Vector2i(5, 2)]
		"farm":
			radius = 18
			for d in range(-radius + 1, radius):
				for w in range(0, 2):
					tiles[Vector2i(vx + d, vy + w)] = T.PATH
			for fx in [-14, 2]:
				for x in range(fx, fx + 10):
					for y in range(-13, -7):
						tiles[Vector2i(vx + x, vy + y)] = T.FARM
			for x in range(-14, 12):
				for y in range(11, 16):
					tiles[Vector2i(vx + x, vy + y)] = T.FARM
			slots = [Vector2i(-12, -3), Vector2i(12, -3), Vector2i(-4, 8), Vector2i(8, 8)]
			for p in [Vector2i(-6, -6), Vector2i(14, -6), Vector2i(-15, 6)]:
				decor.append({"type": "haystack", "tx": vx + p.x, "ty": vy + p.y})
			decor.append({"type": "well", "tx": vx, "ty": vy + 4})
	# nombre y edificios
	var vname := Names.place(r)
	var types := _pick_types(r, slots.size())
	var buildings: Array = []
	var idx := 0
	for s in slots:
		var t: String = types[idx]
		var variant := r.randi_range(0, 2)
		var b := {"type": t, "tx": vx + s.x, "ty": vy + s.y, "variant": variant, "idx": idx,
			"sprite": sprite_for(t, variant), "id": "%s_b%d" % [id, idx]}
		buildings.append(b)
		idx += 1
	# habitantes exteriores
	var npcs: Array = []
	var npc_r := RandomNumberGenerator.new()
	npc_r.seed = seed_value + 99
	npcs.append({"role": "elder", "name": Names.person(npc_r), "tx": vx + plaza.x, "ty": vy + plaza.y, "skin": 26, "id": id + "_elder"})
	if kind != "farm" and npc_r.randf() < 0.6:
		npcs.append({"role": "healer", "name": Names.first_name(npc_r), "tx": vx + plaza.x - 7, "ty": vy + plaza.y, "skin": 12, "id": id + "_healer"})
	if npc_r.randf() < 0.5:
		npcs.append({"role": "bard", "name": Names.first_name(npc_r), "tx": vx + plaza.x + 3, "ty": vy + plaza.y + 1, "skin": 27, "id": id + "_bard"})
	var path_cells: Array = []
	for k in tiles.keys():
		if tiles[k] == path_tile or tiles[k] == T.PATH:
			path_cells.append(k)
	var villagers := mini(buildings.size() + 1, 7)
	for i in villagers:
		if path_cells.is_empty():
			break
		var cell: Vector2i = path_cells[npc_r.randi() % path_cells.size()]
		var role := "farmer" if kind == "farm" and npc_r.randf() < 0.6 else "villager"
		npcs.append({"role": role, "name": Names.person(npc_r), "tx": cell.x, "ty": cell.y, "skin": NPC_SKINS[npc_r.randi() % NPC_SKINS.size()], "id": "%s_v%d" % [id, i]})
	for gi in guards.size():
		var g: Vector2i = guards[gi]
		npcs.append({"role": "guard", "name": Names.first_name(npc_r), "tx": vx + g.x, "ty": vy + g.y, "skin": 23, "id": "%s_g%d" % [id, gi]})
	return {"tx": vx, "ty": vy, "id": id, "name": vname, "kind": kind, "r": radius, "buildings": buildings,
		"decor": decor, "npcs": npcs, "tiles": tiles, "plaza": Vector2i(vx + plaza.x, vy + plaza.y)}
