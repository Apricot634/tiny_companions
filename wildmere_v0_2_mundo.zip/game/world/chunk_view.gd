extends Node2D
## Carga y descarga de chunks alrededor del jugador. Cada chunk = 16x16 tiles dibujado como UNA textura.
## Objetos, edificios, criaturas y luces se crean al cargar el chunk y se liberan al descargarlo.

const T := preload("res://data/tiles.gd")
const NpcScript := preload("res://entities/npc.gd")
const LightNode := preload("res://entities/light_node.gd")
const VillageGen := preload("res://world/village_gen.gd")
const CHUNK := 16
const PX := 256
const ENTERABLE := ["house", "shop", "inn", "smith", "tower", "hut"]

var source = null
var entities: Node2D
var world = null
var radius := 2
var chunks := {}
var blocked := {}
var interactables: Array = []
var harvestables: Array = []
var _atlas: Image = null
var _tex_cache := {}


func setup(src, entities_node: Node2D, world_ref) -> void:
	source = src
	entities = entities_node
	world = world_ref
	if _atlas == null:
		var tex: Texture2D = load(T.ATLAS)
		_atlas = tex.get_image()
		if _atlas.is_compressed():
			_atlas.decompress()
		_atlas.convert(Image.FORMAT_RGBA8)


func clear_all() -> void:
	for key in chunks.keys():
		_unload_chunk(key)
	chunks.clear()
	blocked.clear()
	interactables.clear()
	harvestables.clear()


func _tex(path: String) -> Texture2D:
	if not _tex_cache.has(path):
		_tex_cache[path] = load(path)
	return _tex_cache[path]


func chunk_of(px: Vector2) -> Vector2i:
	return Vector2i(floori(px.x / PX), floori(px.y / PX))


func _in_bounds(key: Vector2i) -> bool:
	if not source.finite:
		return true
	var x0: int = key.x * CHUNK
	var y0: int = key.y * CHUNK
	return x0 < source.w and y0 < source.h and x0 + CHUNK > 0 and y0 + CHUNK > 0


func load_around(center_px: Vector2, rad: int = 1) -> void:
	var c := chunk_of(center_px)
	for dy in range(-rad, rad + 1):
		for dx in range(-rad, rad + 1):
			var key := Vector2i(c.x + dx, c.y + dy)
			if not chunks.has(key) and _in_bounds(key):
				_load_chunk(key)


func update(center_px: Vector2) -> void:
	var c := chunk_of(center_px)
	for key in chunks.keys():
		if absi(key.x - c.x) > radius + 1 or absi(key.y - c.y) > radius + 1:
			_unload_chunk(key)
			chunks.erase(key)
	var best := Vector2i.ZERO
	var best_d := 9999
	var found := false
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			var key := Vector2i(c.x + dx, c.y + dy)
			if chunks.has(key) or not _in_bounds(key):
				continue
			var d := absi(dx) + absi(dy)
			if d < best_d:
				best_d = d
				best = key
				found = true
	if found:
		_load_chunk(best)


# ------------------------------------------------------------ tiles
func tile_cached(tx: int, ty: int) -> int:
	var key := Vector2i(floori(float(tx) / CHUNK), floori(float(ty) / CHUNK))
	if chunks.has(key):
		var tiles: PackedByteArray = chunks[key]["tiles"]
		var lx := tx - key.x * CHUNK
		var ly := ty - key.y * CHUNK
		return tiles[ly * CHUNK + lx]
	return source.tile_at(tx, ty)


func is_blocked_tile(tx: int, ty: int) -> bool:
	return T.is_solid(tile_cached(tx, ty)) or blocked.has(Vector2i(tx, ty))


func is_blocked_px(p: Vector2) -> bool:
	return is_blocked_tile(floori(p.x / 16.0), floori(p.y / 16.0))


func tile_at_px(p: Vector2) -> int:
	return tile_cached(floori(p.x / 16.0), floori(p.y / 16.0))


# ------------------------------------------------------------ carga / descarga
func _load_chunk(key: Vector2i) -> void:
	var img := Image.create(PX, PX, false, Image.FORMAT_RGBA8)
	var tiles := PackedByteArray()
	tiles.resize(CHUNK * CHUNK)
	for ly in CHUNK:
		for lx in CHUNK:
			var tx: int = key.x * CHUNK + lx
			var ty: int = key.y * CHUNK + ly
			var tid: int = source.tile_at(tx, ty)
			tiles[ly * CHUNK + lx] = tid
			var variant: int = absi(tx * 73 + ty * 31 + tx * ty) % 4
			img.blit_rect(_atlas, Rect2i(variant * 16, tid * 16, 16, 16), Vector2i(lx * 16, ly * 16))
	var spr := Sprite2D.new()
	spr.texture = ImageTexture.create_from_image(img)
	spr.centered = false
	spr.position = Vector2(key.x * PX, key.y * PX)
	spr.z_index = -10
	add_child(spr)
	var entry := {"sprite": spr, "nodes": [], "blocked": [], "tiles": tiles}
	chunks[key] = entry
	for o in source.chunk_objects(key.x, key.y):
		_spawn_object(key, entry, o)
	for c in source.chunk_creatures(key.x, key.y):
		if world != null and not GameState.is_depleted(str(c["id"])):
			var node: Node2D = world.spawn_creature(c)
			if node != null:
				entry["nodes"].append(node)


func _unload_chunk(key: Vector2i) -> void:
	var entry: Dictionary = chunks[key]
	(entry["sprite"] as Sprite2D).queue_free()
	for n in entry["nodes"]:
		if is_instance_valid(n):
			n.queue_free()
	for t in entry["blocked"]:
		var cnt: int = int(blocked.get(t, 0)) - 1
		if cnt <= 0:
			blocked.erase(t)
		else:
			blocked[t] = cnt
	var keep: Array = []
	for it in interactables:
		if it["key"] != key:
			keep.append(it)
	interactables = keep
	var keep_h: Array = []
	for h in harvestables:
		if h["key"] != key:
			keep_h.append(h)
	harvestables = keep_h


func _block(entry: Dictionary, tx: int, ty: int) -> void:
	var t := Vector2i(tx, ty)
	blocked[t] = int(blocked.get(t, 0)) + 1
	entry["blocked"].append(t)


func _block_sprite(entry: Dictionary, tex: Texture2D, tx: int, ty: int) -> void:
	var wt: int = maxi(1, ceili(tex.get_width() / 16.0))
	var rows: int = mini(2, maxi(1, ceili(tex.get_height() / 16.0)))
	var start: int = tx - int((wt - 1) / 2)
	for ix in range(start, start + wt):
		for iy in range(ty - rows + 1, ty + 1):
			_block(entry, ix, iy)


func _sprite(path: String, pos: Vector2, foot: bool = true) -> Sprite2D:
	var s := Sprite2D.new()
	var tex := _tex(path)
	s.texture = tex
	s.centered = false
	if foot:
		s.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height() + 3.0)
	s.position = pos
	entities.add_child(s)
	return s


func _light(parent: Node, radius_px: float, energy: float, col: Color) -> void:
	var l = LightNode.new()
	parent.add_child(l)
	l.setup(radius_px, energy, col)


func _add_interactable(key: Vector2i, itype: String, pos: Vector2, node, o: Dictionary) -> void:
	interactables.append({"type": itype, "pos": pos, "id": str(o.get("id", "")), "node": node, "key": key,
		"role": str(o.get("role", "")), "data": o})


func _spawn_object(key: Vector2i, entry: Dictionary, o: Dictionary) -> void:
	var tx: int = int(o["tx"])
	var ty: int = int(o["ty"])
	var foot := Vector2(tx * 16 + 8, ty * 16 + 15)
	var typ := str(o["type"])
	var variant: int = int(o.get("variant", 0))
	var oid := str(o.get("id", ""))
	var node = null
	if typ == "tree":
		if GameState.is_depleted(oid):
			node = _sprite("res://assets/props/stump.png", foot)
		else:
			node = _sprite("res://assets/trees/%s.png" % str(o.get("tex", "oak1")), foot)
			_block(entry, tx, ty)
			harvestables.append({"kind": "tree", "pos": foot, "id": oid, "node": node, "hp": 4, "key": key, "tex": str(o.get("tex", "oak1"))})
	elif typ == "rock":
		if not GameState.is_depleted(oid):
			node = _sprite("res://assets/props/rock.png", foot)
			_block(entry, tx, ty)
			harvestables.append({"kind": "rock", "pos": foot, "id": oid, "node": node, "hp": 3, "key": key, "tex": "rock"})
	elif typ == "shrub":
		node = _sprite("res://assets/props/shrub%d.png" % (variant % 2 + 1), foot)
		var fruit := Sprite2D.new()
		fruit.texture = _tex("res://assets/items/apple.png")
		fruit.position = Vector2(-8, -44)
		fruit.name = "Fruit"
		fruit.visible = not GameState.is_depleted(oid)
		node.add_child(fruit)
		_block(entry, tx, ty)
		_add_interactable(key, "shrub", foot, node, o)
	elif typ == "herb":
		node = _sprite("res://assets/props/herb_patch.png", foot)
		node.visible = not GameState.is_depleted(oid)
		_add_interactable(key, "herb", foot, node, o)
	elif typ == "cactus":
		node = _sprite("res://assets/props/cactus.png", foot)
		_block(entry, tx, ty)
	elif typ == "bones":
		node = _sprite("res://assets/props/bones.png", foot)
	elif typ == "peak":
		node = _sprite("res://assets/peaks/peak%d.png" % (variant + 1), foot)
	elif typ == "building":
		node = _sprite("res://assets/buildings/%s.png" % str(o["sprite"]), foot)
		var bt := str(o["btype"])
		var fp := VillageGen.footprint(bt)
		for hx in range(fp.position.x, fp.end.x):
			for hy in range(fp.position.y, fp.end.y):
				_block(entry, tx + hx, ty + hy)
		if ENTERABLE.has(bt):
			_add_interactable(key, "door", Vector2(tx * 16 + 8, (ty + 1) * 16 + 8), node, o)
	elif typ == "decor":
		node = _sprite("res://assets/buildings/%s.png" % str(o["sprite"]), foot)
		var fp2 := VillageGen.footprint(str(o["sprite"]))
		for hx in range(fp2.position.x, fp2.end.x):
			for hy in range(fp2.position.y, fp2.end.y):
				_block(entry, tx + hx, ty + hy)
	elif typ == "tent":
		node = _sprite("res://assets/buildings/tent.png", foot)
		for hx in range(tx - 1, tx + 2):
			_block(entry, hx, ty)
	elif typ == "campfire":
		node = _sprite("res://assets/buildings/campfire.png", foot)
		_light(node, 90.0, 0.9, Color(1.0, 0.7, 0.35))
	elif typ == "npc":
		var npc: Node2D = NpcScript.new()
		npc.setup(o)
		npc.world = world
		npc.position = foot
		entities.add_child(npc)
		node = npc
		_add_interactable(key, "npc", foot, npc, o)
	elif typ == "cave":
		node = _sprite("res://assets/props/cave.png", foot)
		var tint := {"ice": Color(0.7, 0.85, 1.0), "bog": Color(0.7, 0.9, 0.7), "crypt": Color(0.8, 0.75, 0.9), "ruins": Color(0.9, 0.8, 0.7), "nest": Color(0.9, 0.8, 0.8)}
		node.modulate = tint.get(str(o.get("theme", "cave")), Color.WHITE)
		_block(entry, tx, ty)
		_block(entry, tx - 1, ty)
		_add_interactable(key, "cave", foot + Vector2(0, 8), node, o)
	elif typ == "boss_gate":
		node = _sprite("res://assets/props/boss_gate.png", foot)
		_block(entry, tx, ty)
		_add_interactable(key, "boss_gate", foot + Vector2(0, 8), node, o)
	elif typ == "chest":
		node = _sprite("res://assets/props/chest.png", foot)
		_block(entry, tx, ty)
		if bool(o.get("big", false)):
			node.scale = Vector2(1.4, 1.4)
		if GameState.is_depleted("chest_" + oid):
			node.modulate = Color(0.5, 0.5, 0.5, 0.8)
		_add_interactable(key, "chest", foot, node, o)
	elif typ == "furn":
		node = _sprite("res://assets/furniture/%s.png" % str(o["sprite"]), foot)
		_block_sprite(entry, node.texture, tx, ty)
	elif typ == "bed_rent":
		node = _sprite("res://assets/furniture/%s.png" % str(o["sprite"]), foot)
		_block_sprite(entry, node.texture, tx, ty)
		_add_interactable(key, "bed_rent", foot, node, o)
	elif typ == "prop":
		var sp := str(o["sprite"])
		node = _sprite("res://assets/props/%s.png" % sp, foot)
		if bool(o.get("block", false)):
			_block(entry, tx, ty)
		if sp == "glow_crystal":
			_light(node, 70.0, 0.8, Color(0.5, 0.9, 1.0))
	elif typ == "torch_fixed":
		node = _sprite("res://assets/props/torch.png", foot)
		_block(entry, tx, ty)
		_light(node, 120.0, 1.0, Color(1.0, 0.75, 0.4))
	elif typ == "crystal":
		node = _sprite("res://assets/props/crystal.png", foot)
		_light(node, 90.0, 0.9, Color(0.5, 0.9, 1.0))
	elif typ == "exit":
		_add_interactable(key, "exit", Vector2(tx * 16 + 8, ty * 16 + 12), null, o)
	if node != null:
		entry["nodes"].append(node)


func nearest_interactable(pos: Vector2, max_dist: float) -> Dictionary:
	var best := {}
	var best_d := max_dist
	for it in interactables:
		if it["type"] == "herb" and GameState.is_depleted(str(it["id"])):
			continue
		var d: float = pos.distance_to(it["pos"])
		if d < best_d:
			best_d = d
			best = it
	return best


## Elemento golpeable (arbol/roca) delante de pos. Devuelve la entrada o {}.
func harvest_near(pos: Vector2, dir: Vector2, reach: float) -> Dictionary:
	var best := {}
	var best_d := reach
	for h in harvestables:
		var to: Vector2 = h["pos"] - pos
		var d := to.length()
		if d < best_d and (d < 10.0 or to.normalized().dot(dir) > 0.2):
			best_d = d
			best = h
	return best


func deplete_harvestable(h: Dictionary) -> void:
	harvestables.erase(h)
	var node = h["node"]
	var p: Vector2 = h["pos"]
	var tx := floori(p.x / 16.0)
	var ty := floori(p.y / 16.0)
	var t := Vector2i(tx, ty)
	var cnt: int = int(blocked.get(t, 0)) - 1
	if cnt <= 0:
		blocked.erase(t)
	else:
		blocked[t] = cnt
	if is_instance_valid(node):
		if str(h["kind"]) == "tree":
			(node as Sprite2D).texture = _tex("res://assets/props/stump.png")
			(node as Sprite2D).offset = Vector2(-7, -12 + 3)
		else:
			(node as CanvasItem).visible = false
