extends RefCounted
## Mazmorras: salas+pasillos o cavernas (automata celular), grandes, con temas, jefe y cofres.
## Tambien contiene la arena FIJA del jefe final (identica en todos los mundos).

const T := preload("res://data/tiles.gd")
const Species := preload("res://data/species.gd")
const CHUNK := 16
const FLOORS := {"cave": 7, "mine": 7, "grove": 4, "ice": 14, "bog": 15, "crypt": 9, "ruins": 22, "nest": 5, "lair": 9}
const WALLS := {"cave": 6, "mine": 10, "grove": 10, "ice": 6, "bog": 10, "crypt": 10, "ruins": 10, "nest": 10, "lair": 6}

var finite := true
var w := 96
var h := 96
var tiles := PackedInt32Array()
var theme := "cave"
var rooms: Array = []
var start := Vector2i.ZERO
var exit_tile := Vector2i.ZERO
var chests: Array = []
var spawns: Array = []
var props: Array = []
var is_boss := false
var boss_spawn := Vector2i.ZERO
var dungeon_id := ""
var floor_tile := 9
var wall_tile := 10
var boss_room_center := Vector2i.ZERO
var floor_cells: Array = []


func tile_at(tx: int, ty: int) -> int:
	if tx < 0 or ty < 0 or tx >= w or ty >= h:
		return T.DWALL
	return tiles[ty * w + tx]


func start_pos() -> Vector2:
	return Vector2(start.x * 16 + 8, start.y * 16 + 8)


func _fill(v: int) -> void:
	tiles = PackedInt32Array()
	tiles.resize(w * h)
	for i in tiles.size():
		tiles[i] = v


func _carve(r: Rect2i, tile: int) -> void:
	for y in range(r.position.y, r.end.y):
		for x in range(r.position.x, r.end.x):
			if x > 0 and y > 0 and x < w - 1 and y < h - 1:
				tiles[y * w + x] = tile


func generate(seed_value: int, id: String, theme_id: String, danger: float = 1.0) -> void:
	dungeon_id = id
	theme = theme_id if Species.THEMES.has(theme_id) else "cave"
	is_boss = false
	w = 96
	h = 96
	floor_tile = int(FLOORS[theme])
	wall_tile = int(WALLS[theme])
	var r := RandomNumberGenerator.new()
	r.seed = seed_value
	var style := str(Species.THEMES[theme]["style"])
	var ok := false
	if style == "caves":
		ok = _gen_cave(r)
	if not ok:
		_gen_rooms(r)
	_collect_floor()
	_place_points(r)
	_spawn_creatures(r, danger)
	_decorate(r)


func _gen_rooms(r: RandomNumberGenerator) -> void:
	_fill(wall_tile)
	rooms = []
	var tries := 0
	while rooms.size() < 16 and tries < 300:
		tries += 1
		var rw := r.randi_range(6, 14)
		var rh := r.randi_range(6, 12)
		var rx := r.randi_range(2, w - rw - 3)
		var ry := r.randi_range(2, h - rh - 3)
		var cand := Rect2i(rx, ry, rw, rh)
		var good := true
		for other in rooms:
			if cand.grow(3).intersects(other):
				good = false
		if good:
			rooms.append(cand)
	for rm in rooms:
		_carve(rm, floor_tile)
	for i in range(rooms.size() - 1):
		_connect(rooms[i], rooms[i + 1], r)
	for k in 4:
		var a: Rect2i = rooms[r.randi() % rooms.size()]
		var b: Rect2i = rooms[r.randi() % rooms.size()]
		if a != b:
			_connect(a, b, r)


func _connect(a: Rect2i, b: Rect2i, r: RandomNumberGenerator) -> void:
	var ca := a.position + a.size / 2
	var cb := b.position + b.size / 2
	var wd := r.randi_range(2, 3)
	_carve(Rect2i(mini(ca.x, cb.x), ca.y - 1, absi(cb.x - ca.x) + wd, wd), floor_tile)
	_carve(Rect2i(cb.x - 1, mini(ca.y, cb.y), wd, absi(cb.y - ca.y) + wd), floor_tile)


func _gen_cave(r: RandomNumberGenerator) -> bool:
	var grid := PackedByteArray()
	grid.resize(w * h)
	for y in h:
		for x in w:
			var wall := x < 2 or y < 2 or x >= w - 2 or y >= h - 2 or r.randf() < 0.46
			grid[y * w + x] = 1 if wall else 0
	for it in 5:
		var nxt := grid.duplicate()
		for y in range(1, h - 1):
			for x in range(1, w - 1):
				var n := 0
				for oy in range(-1, 2):
					for ox in range(-1, 2):
						if (ox != 0 or oy != 0) and grid[(y + oy) * w + x + ox] == 1:
							n += 1
				nxt[y * w + x] = 1 if (n >= 5 or (n == 4 and grid[y * w + x] == 1)) else 0
		grid = nxt
	# componente mayor
	var comp := PackedInt32Array()
	comp.resize(w * h)
	var best_id := 0
	var best_size := 0
	var cid := 0
	for sy in h:
		for sx in w:
			if grid[sy * w + sx] == 0 and comp[sy * w + sx] == 0:
				cid += 1
				var stack: Array = [Vector2i(sx, sy)]
				comp[sy * w + sx] = cid
				var size := 0
				while not stack.is_empty():
					var cur: Vector2i = stack.pop_back()
					size += 1
					for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
						var nx: Vector2i = cur + d
						if nx.x > 0 and nx.y > 0 and nx.x < w - 1 and nx.y < h - 1 and grid[nx.y * w + nx.x] == 0 and comp[nx.y * w + nx.x] == 0:
							comp[nx.y * w + nx.x] = cid
							stack.append(nx)
				if size > best_size:
					best_size = size
					best_id = cid
	if best_size < w * h * 0.22:
		return false
	_fill(wall_tile)
	rooms = []
	for y in h:
		for x in w:
			if comp[y * w + x] == best_id:
				tiles[y * w + x] = floor_tile
	return true


func _collect_floor() -> void:
	floor_cells = []
	for y in h:
		for x in w:
			if tiles[y * w + x] == floor_tile:
				floor_cells.append(Vector2i(x, y))


func _bfs(from_t: Vector2i) -> Dictionary:
	var dist := {from_t: 0}
	var queue: Array = [from_t]
	var qi := 0
	while qi < queue.size():
		var cur: Vector2i = queue[qi]
		qi += 1
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var nx: Vector2i = cur + d
			if not dist.has(nx) and not T.is_solid(tile_at(nx.x, nx.y)):
				dist[nx] = int(dist[cur]) + 1
				queue.append(nx)
	return dist


func _place_points(r: RandomNumberGenerator) -> void:
	# inicio: celda del suelo mas cercana a la esquina inferior izquierda
	var best := floor_cells[0] as Vector2i
	var bd := 999999.0
	for c in floor_cells:
		var dd := Vector2(c.x - 6, c.y - (h - 7)).length()
		if dd < bd:
			bd = dd
			best = c
	exit_tile = best
	tiles[exit_tile.y * w + exit_tile.x] = T.STAIRS
	start = Vector2i(exit_tile.x, exit_tile.y)
	var dist := _bfs(start)
	# sala del jefe: lo mas lejano
	var far := start
	var fd := 0
	for c in dist.keys():
		if int(dist[c]) > fd:
			fd = int(dist[c])
			far = c
	boss_room_center = far
	_carve(Rect2i(far.x - 5, far.y - 5, 11, 11), floor_tile)
	boss_spawn = far
	chests = []
	chests.append({"tx": far.x + 3, "ty": far.y - 3, "id": "%s_bosschest" % dungeon_id, "boss": true})
	# cofres repartidos
	var tries := 0
	while chests.size() < 6 and tries < 400:
		tries += 1
		var c: Vector2i = floor_cells[r.randi() % floor_cells.size()]
		if dist.has(c) and int(dist[c]) > 18 and tile_at(c.x, c.y) == floor_tile:
			var ok := true
			for ch in chests:
				if Vector2(int(ch["tx"]) - c.x, int(ch["ty"]) - c.y).length() < 12.0:
					ok = false
			if ok:
				chests.append({"tx": c.x, "ty": c.y, "id": "%s_chest%d" % [dungeon_id, chests.size()], "boss": false})
	_collect_floor()


func _spawn_creatures(r: RandomNumberGenerator, danger: float) -> void:
	spawns = []
	var info: Dictionary = Species.THEMES[theme]
	var mobs: Array = info["mobs"]
	var minis: Array = info["minis"]
	var dist := _bfs(start)
	var count := mini(70, floor_cells.size() / 120)
	var tries := 0
	while spawns.size() < count and tries < 1500:
		tries += 1
		var c: Vector2i = floor_cells[r.randi() % floor_cells.size()]
		if not dist.has(c) or int(dist[c]) < 12:
			continue
		var sp := str(mobs[r.randi() % mobs.size()])
		if r.randf() < 0.1:
			sp = str(minis[r.randi() % minis.size()])
		spawns.append({"species": sp, "tx": c.x, "ty": c.y, "id": "%s_c%d" % [dungeon_id, spawns.size()]})
	# guardianes del jefe
	for k in 4:
		var a := k * PI / 2.0 + 0.7
		spawns.append({"species": str(mobs[r.randi() % mobs.size()]), "tx": boss_spawn.x + roundi(cos(a) * 4.0), "ty": boss_spawn.y + roundi(sin(a) * 4.0), "id": "%s_g%d" % [dungeon_id, k]})
	spawns.append({"species": str(info["boss"]), "tx": boss_spawn.x, "ty": boss_spawn.y, "id": "%s_boss" % dungeon_id})


func _decorate(r: RandomNumberGenerator) -> void:
	props = []
	var sprites: Array = ["rubble", "bones", "pillar"]
	if theme == "crypt" or theme == "ruins":
		sprites = ["grave", "bones", "pillar", "rubble"]
	if theme == "cave" or theme == "mine" or theme == "ice" or theme == "bog":
		sprites = ["rubble", "glow_crystal", "bones", "glow_crystal"]
	var n := floor_cells.size() / 55
	for i in n:
		var c: Vector2i = floor_cells[r.randi() % floor_cells.size()]
		if Vector2(c.x - start.x, c.y - start.y).length() < 4.0 or tile_at(c.x, c.y) != floor_tile:
			continue
		var sp := str(sprites[r.randi() % sprites.size()])
		props.append({"sprite": sp, "tx": c.x, "ty": c.y, "block": sp == "pillar" or sp == "grave" or sp == "glow_crystal"})


## Arena del jefe final: fija, no depende de la semilla del mundo.
func boss_arena() -> void:
	dungeon_id = "boss"
	theme = "ruins"
	is_boss = true
	w = 40
	h = 30
	floor_tile = T.BFLOOR
	wall_tile = T.DWALL
	_fill(T.DWALL)
	_carve(Rect2i(2, 2, 36, 25), T.BFLOOR)
	for p in [Vector2i(9, 8), Vector2i(29, 8), Vector2i(9, 18), Vector2i(29, 18)]:
		_carve(Rect2i(p.x, p.y, 2, 2), T.DWALL)
	_carve(Rect2i(2, 2, 3, 3), T.LAVA)
	_carve(Rect2i(35, 2, 3, 3), T.LAVA)
	exit_tile = Vector2i(20, 26)
	tiles[exit_tile.y * w + exit_tile.x] = T.STAIRS
	tiles[exit_tile.y * w + exit_tile.x - 1] = T.STAIRS
	start = Vector2i(20, 24)
	boss_spawn = Vector2i(20, 6)
	rooms = [Rect2i(2, 2, 36, 25)]
	chests = []
	spawns = []
	props = []
	_collect_floor()


func chunk_objects(cx: int, cy: int) -> Array:
	var out: Array = []
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	if exit_tile.x >= x0 and exit_tile.x < x0 + CHUNK and exit_tile.y >= y0 and exit_tile.y < y0 + CHUNK:
		out.append({"type": "exit", "tx": exit_tile.x, "ty": exit_tile.y, "variant": 0, "id": "exit"})
	for c in chests:
		if int(c["tx"]) >= x0 and int(c["tx"]) < x0 + CHUNK and int(c["ty"]) >= y0 and int(c["ty"]) < y0 + CHUNK:
			out.append({"type": "chest", "tx": int(c["tx"]), "ty": int(c["ty"]), "variant": 0, "id": str(c["id"]), "owned": false, "big": bool(c.get("boss", false))})
	for p in props:
		if int(p["tx"]) >= x0 and int(p["tx"]) < x0 + CHUNK and int(p["ty"]) >= y0 and int(p["ty"]) < y0 + CHUNK:
			out.append({"type": "prop", "sprite": str(p["sprite"]), "tx": int(p["tx"]), "ty": int(p["ty"]), "block": bool(p["block"]), "id": "p_%d_%d" % [int(p["tx"]), int(p["ty"])]})
	if is_boss:
		if boss_spawn.x >= x0 and boss_spawn.x < x0 + CHUNK and boss_spawn.y >= y0 and boss_spawn.y < y0 + CHUNK:
			out.append({"type": "crystal", "tx": boss_spawn.x, "ty": boss_spawn.y - 4, "variant": 0, "id": "boss_crystal"})
		for p2 in [Vector2i(8, 7), Vector2i(31, 7), Vector2i(8, 20), Vector2i(31, 20), Vector2i(14, 3), Vector2i(26, 3)]:
			if p2.x >= x0 and p2.x < x0 + CHUNK and p2.y >= y0 and p2.y < y0 + CHUNK:
				out.append({"type": "torch_fixed", "tx": p2.x, "ty": p2.y, "id": "tf_%d_%d" % [p2.x, p2.y]})
	return out


func chunk_creatures(cx: int, cy: int) -> Array:
	var out: Array = []
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	for s in spawns:
		if int(s["tx"]) >= x0 and int(s["tx"]) < x0 + CHUNK and int(s["ty"]) >= y0 and int(s["ty"]) < y0 + CHUNK:
			out.append(s)
	if is_boss and boss_spawn.x >= x0 and boss_spawn.x < x0 + CHUNK and boss_spawn.y >= y0 and boss_spawn.y < y0 + CHUNK:
		out.append({"species": "demon", "tx": boss_spawn.x, "ty": boss_spawn.y, "id": "boss_demon"})
	return out


func reachable(from_t: Vector2i, to_t: Vector2i) -> bool:
	return _bfs(from_t).has(to_t)
