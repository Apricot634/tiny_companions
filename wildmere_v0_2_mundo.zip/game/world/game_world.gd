extends Node2D
## Escena de juego: mundo abierto, aldeas con interiores, cuevas y mazmorras oscuras, arena del jefe final,
## combate, tiendas, posadas, misiones, reputacion, dia y noche.

const Terrain := preload("res://world/terrain.gd")
const DungeonGen := preload("res://world/dungeon_gen.gd")
const InteriorGen := preload("res://world/interior_gen.gd")
const ChunkViewScript := preload("res://world/chunk_view.gd")
const PlayerScript := preload("res://entities/player.gd")
const CreatureScript := preload("res://entities/creature.gd")
const FxScript := preload("res://entities/fx_sprite.gd")
const ProjScript := preload("res://entities/projectile.gd")
const LightNode := preload("res://entities/light_node.gd")
const HudScript := preload("res://ui/hud.gd")
const Spells := preload("res://data/spells.gd")
const Species := preload("res://data/species.gd")
const Items := preload("res://data/items.gd")
const T := preload("res://data/tiles.gd")
const Dialogue := preload("res://data/dialogue.gd")

const DIRS := ["dir_e", "dir_se", "dir_s", "dir_sw", "dir_w", "dir_nw", "dir_n", "dir_ne"]
const SHOP_ROLES := ["merchant", "smith", "witch", "mage", "innkeeper"]
const QUEST_KILLS := ["mushroom", "wolf", "goblin", "spider", "slime", "skeleton", "bandit", "bat", "boar", "orc", "zombie", "scorpion"]
const QUEST_ITEMS := ["wood", "herb", "stone", "fish", "meat", "apple"]
const RESPAWN_POS := Vector2(280, -104)

var terrain
var source
var chunk_view
var entities: Node2D
var player
var cam: Camera2D
var hud
var canvas_mod: CanvasModulate
var player_light
var _respawn_t := -1.0
var _hint_t := 0.0
var _region_t := 0.0
var _last_region := ""
var _danger := 1.0
var _shake_t := 0.0
var _cine_busy := false
var _torch_nodes: Array = []


func _ready() -> void:
	get_tree().paused = false
	if not GameState.active:
		GameState.new_world("Prueba", "", 1, "adventurer", "Heroe")
	terrain = Terrain.new(GameState.world_seed)
	canvas_mod = CanvasModulate.new()
	add_child(canvas_mod)
	chunk_view = ChunkViewScript.new()
	add_child(chunk_view)
	entities = Node2D.new()
	entities.y_sort_enabled = true
	add_child(entities)
	player = PlayerScript.new()
	player.world = self
	entities.add_child(player)
	cam = Camera2D.new()
	cam.zoom = Vector2(2, 2)
	cam.position = Vector2(0, -8)
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 9.0
	player.add_child(cam)
	cam.make_current()
	player_light = LightNode.new()
	player.add_child(player_light)
	player_light.position = Vector2(0, -8)
	player_light.setup(70.0, 0.0, Color(1.0, 0.9, 0.7))
	hud = HudScript.new()
	hud.world = self
	add_child(hud)
	hud.action_attack.connect(player.do_attack)
	hud.action_bow_begin.connect(player.begin_bow)
	hud.action_bow_end.connect(player.release_bow)
	hud.action_spell_begin.connect(player.begin_spell)
	hud.action_spell_end.connect(player.release_spell)
	hud.action_block.connect(player.set_block)
	hud.action_dash.connect(player.do_dash)
	hud.action_interact.connect(interact)
	var dim: String = GameState.dimension
	if dim != "overworld" and dim != "boss" and not dim.begins_with("dungeon:") and not dim.begins_with("interior:"):
		dim = "overworld"
	_enter_dimension(dim, GameState.pos)
	hud.toast("hint_start")


# ------------------------------------------------------------ dimensiones
func _dungeon_seed(id: String) -> int:
	return absi(id.hash() ^ GameState.world_seed) % 2000000000


func _enter_dimension(dim: String, pos_px: Vector2) -> void:
	chunk_view.clear_all()
	for c in entities.get_children():
		if c != player:
			c.queue_free()
	_torch_nodes.clear()
	GameState.dimension = dim
	if dim == "overworld":
		source = terrain
	elif dim == "boss":
		var b = DungeonGen.new()
		b.boss_arena()
		source = b
	elif dim.begins_with("interior:"):
		var parts := dim.split(":")
		var ig = InteriorGen.new()
		ig.generate(str(parts[1]), _dungeon_seed(str(parts[2])), str(parts[2]), str(GameState.interior_ctx.get("vname", "")))
		source = ig
	else:
		var did := dim.substr(8)
		var theme := str(did.split("@")[0])
		var d = DungeonGen.new()
		_danger = 1.0 + clampf(GameState.return_pos.length() / 16.0 / 200.0, 0.0, 1.2)
		d.generate(_dungeon_seed(did), did, theme, _danger)
		source = d
	chunk_view.setup(source, entities, self)
	var p := pos_px
	if source.finite and (dim == "boss" or not _walkable_px(p)):
		p = source.start_pos()
	if dim == "overworld":
		p = _safe_pos(p)
	player.position = p
	GameState.pos = p
	if source.finite:
		cam.limit_left = 0
		cam.limit_top = 0
		cam.limit_right = source.w * 16
		cam.limit_bottom = source.h * 16
	else:
		cam.limit_left = -10000000
		cam.limit_top = -10000000
		cam.limit_right = 10000000
		cam.limit_bottom = 10000000
	chunk_view.load_around(p, 1)
	cam.reset_smoothing()
	_spawn_saved_torches()
	_last_region = ""
	hud.do_fade()
	hud.hide_boss()


func _walkable_px(p: Vector2) -> bool:
	return not chunk_view.is_blocked_px(p)


func _safe_pos(p: Vector2) -> Vector2:
	chunk_view.load_around(p, 1)
	if _point_ok(p, "player") and _point_ok(p + Vector2(4, 0), "player") and _point_ok(p + Vector2(-4, 0), "player") and not chunk_view.blocked.has(Vector2i(floori(p.x / 16.0), floori(p.y / 16.0))):
		return p
	for r in range(1, 40):
		for k in 8:
			var a := k * PI / 4.0
			var q := p + Vector2(cos(a), sin(a)) * r * 8.0
			if _point_ok(q, "player") and not chunk_view.blocked.has(Vector2i(floori(q.x / 16.0), floori(q.y / 16.0))):
				return q
	return p


func _change_dimension(dim: String) -> void:
	_enter_dimension(dim, Vector2.ZERO)
	GameState.save_game()


func _exit_dimension() -> void:
	_enter_dimension("overworld", GameState.return_pos)
	GameState.save_game()


func in_dungeon() -> bool:
	return GameState.dimension == "boss" or GameState.dimension.begins_with("dungeon:")


func in_interior() -> bool:
	return GameState.dimension.begins_with("interior:")


func is_night() -> bool:
	return GameState.is_night() and GameState.dimension == "overworld"


# ------------------------------------------------------------ luz y hora
func _ambient_color() -> Color:
	if in_interior():
		return Color(1.0, 0.96, 0.9)
	if GameState.dimension == "boss":
		return Color(0.32, 0.26, 0.34)
	if in_dungeon():
		return Color(0.1, 0.1, 0.16)
	var h := GameState.hour
	var day := Color(1, 1, 1)
	var night_c := Color(0.3, 0.34, 0.58)
	var dusk := Color(1.0, 0.78, 0.66)
	if h >= 7.5 and h < 17.5:
		return day
	if h >= 17.5 and h < 18.75:
		return day.lerp(dusk, (h - 17.5) / 1.25)
	if h >= 18.75 and h < 20.0:
		return dusk.lerp(night_c, (h - 18.75) / 1.25)
	if h >= 20.0 or h < 5.0:
		return night_c
	if h < 6.5:
		return night_c.lerp(dusk, (h - 5.0) / 1.5)
	return dusk.lerp(day, (h - 6.5) / 1.0)


func _update_light() -> void:
	canvas_mod.color = canvas_mod.color.lerp(_ambient_color(), 0.1)
	if in_interior():
		player_light.energy = 0.0
	elif in_dungeon():
		player_light.set_radius(74.0)
		player_light.energy = 0.95
	else:
		var dark := GameState.is_night()
		player_light.set_radius(60.0)
		player_light.energy = lerpf(player_light.energy, 0.6 if dark else 0.0, 0.05)


func _spawn_saved_torches() -> void:
	var list: Array = GameState.torches.get(GameState.dimension, [])
	for t in list:
		_make_torch(Vector2(float(t[0]), float(t[1])))


func _make_torch(p: Vector2) -> void:
	var s := Sprite2D.new()
	s.texture = load("res://assets/props/torch.png")
	s.centered = false
	s.offset = Vector2(-4, -15)
	s.position = p
	entities.add_child(s)
	var l = LightNode.new()
	s.add_child(l)
	l.position = Vector2(0, -10)
	l.setup(125.0, 1.0, Color(1.0, 0.75, 0.4))
	_torch_nodes.append(s)


func _place_torch() -> void:
	var list: Array = GameState.torches.get(GameState.dimension, [])
	if list.size() >= 60:
		return
	if not GameState.remove_item("torch", 1):
		hud.toast("no_torch")
		Audio.play("error")
		return
	var p: Vector2 = player.position + player.facing * 10.0
	list.append([p.x, p.y])
	GameState.torches[GameState.dimension] = list
	_make_torch(p)
	hud.toast("torch_placed")
	Audio.play("pickup")


# ------------------------------------------------------------ bucle
func _process(delta: float) -> void:
	terrain.night = GameState.is_night()
	chunk_view.update(player.position)
	hud.process_cooldowns(player)
	_update_light()
	_hint_t -= delta
	if _hint_t <= 0.0:
		_hint_t = 0.15
		var it: Dictionary = chunk_view.nearest_interactable(player.position, 30.0)
		var show_use := (not it.is_empty()) or (in_dungeon() and GameState.has_item("torch"))
		hud.set_interact(show_use and not hud.dialogue_open)
	_region_t -= delta
	if _region_t <= 0.0:
		_region_t = 1.0
		_update_region()
	if _respawn_t >= 0.0:
		_respawn_t -= delta
		if _respawn_t < 0.0:
			_respawn()
	if _shake_t > 0.0 and not _cine_busy:
		_shake_t -= delta
		cam.offset = Vector2(randf_range(-3.0, 3.0), randf_range(-3.0, 3.0))
		if _shake_t <= 0.0:
			cam.offset = Vector2.ZERO


func _update_region() -> void:
	if GameState.dimension != "overworld":
		return
	var tile := Vector2i(floori(player.position.x / 16.0), floori(player.position.y / 16.0))
	var r: Dictionary = terrain.region_at(tile.x, tile.y)
	var label := str(r["name"]) if str(r["biome"]) == "village" else Loc.t("region_fmt") % [Loc.t("biome_" + str(r["biome"])), str(r["name"])]
	if label != _last_region:
		_last_region = label
		hud.show_region(label)


func input_locked() -> bool:
	return hud.dialogue_open or _respawn_t >= 0.0 or _cine_busy or hud.panel_open


func player_dead() -> bool:
	return player.dead


func camera_shake(t: float) -> void:
	_shake_t = maxf(_shake_t, t)


func boss_intro(c) -> void:
	if _cine_busy:
		return
	_cine_busy = true
	player.release_bow()
	player.release_spell()
	var off: Vector2 = c.position - player.position
	hud.show_boss(Loc.t("sp_" + c.species_id))
	hud.big_message_text(Loc.t("sp_" + c.species_id))
	var tw := create_tween()
	tw.tween_property(cam, "offset", off * 0.8, 0.5)
	tw.parallel().tween_property(cam, "zoom", Vector2(2.7, 2.7), 0.5)
	tw.tween_interval(1.0)
	tw.tween_property(cam, "offset", Vector2.ZERO, 0.4)
	tw.parallel().tween_property(cam, "zoom", Vector2(2, 2), 0.4)
	tw.tween_callback(_cine_end)


func _cine_end() -> void:
	_cine_busy = false


# ------------------------------------------------------------ movimiento y consultas
func _point_ok(p: Vector2, hab: String) -> bool:
	var tx := floori(p.x / 16.0)
	var ty := floori(p.y / 16.0)
	var t := chunk_view.tile_cached(tx, ty)
	if hab == "air":
		return not T.is_wall(t)
	if chunk_view.blocked.has(Vector2i(tx, ty)):
		return false
	if hab == "player":
		return not T.is_solid(t)
	if hab == "water":
		return T.is_water(t)
	return not T.is_solid(t) and not T.is_water(t)


func _habitat_of(e) -> String:
	if "habitat" in e:
		return str(e.habitat)
	return "land"


func free_ahead(e, dir: Vector2, dist: float) -> bool:
	return _point_ok(e.position + dir * dist, _habitat_of(e))


func move_entity(e: Node2D, delta_v: Vector2, r: float) -> void:
	var hab := _habitat_of(e)
	var p := e.position
	var nx := Vector2(p.x + delta_v.x, p.y)
	if _can_stand(nx, r, hab):
		p = nx
	var ny := Vector2(p.x, p.y + delta_v.y)
	if _can_stand(ny, r, hab):
		p = ny
	e.position = p


func _can_stand(p: Vector2, r: float, hab: String) -> bool:
	return _point_ok(p, hab) and _point_ok(p + Vector2(r, 0), hab) and _point_ok(p + Vector2(-r, 0), hab) and _point_ok(p + Vector2(0, -r * 0.5), hab)


func creature_at(p: Vector2, r: float):
	for c in get_tree().get_nodes_in_group("creatures"):
		if c.body_center().distance_to(p) < r + c.radius:
			return c
	return null


func creatures_in_cone(origin: Vector2, dir: Vector2, reach: float) -> Array:
	var out: Array = []
	for c in get_tree().get_nodes_in_group("creatures"):
		var to: Vector2 = c.position - origin
		var d := to.length()
		if d <= reach + c.radius and (d < 12.0 or to.normalized().dot(dir) > 0.25):
			out.append(c)
	return out


func nearest_creatures(origin: Vector2, r: float, n: int) -> Array:
	var all: Array = []
	for c in get_tree().get_nodes_in_group("creatures"):
		var d: float = c.position.distance_to(origin)
		if d <= r:
			all.append([d, c])
	all.sort_custom(_cmp_pair)
	var out: Array = []
	for e in all:
		if out.size() >= n:
			break
		out.append(e[1])
	return out


func _cmp_pair(a, b) -> bool:
	return float(a[0]) < float(b[0])


func area_damage(center: Vector2, r: float, dmg: float, magic: bool = false) -> void:
	for c in get_tree().get_nodes_in_group("creatures"):
		if c.body_center().distance_to(center) <= r + c.radius:
			c.take_damage(dmg, center, 80.0)
			if magic:
				GameState.add_magic_xp(dmg * 0.04)


func area_damage_player(center: Vector2, r: float, dmg: float) -> void:
	if not player.dead and player.position.distance_to(center) <= r:
		player.take_damage(dmg, center)


func damage_player(amount: float, from_pos: Vector2) -> void:
	player.take_damage(amount, from_pos)


# ------------------------------------------------------------ entidades
func _valid_spawn(p: Vector2, hab: String) -> bool:
	return _point_ok(p, hab) and _point_ok(p + Vector2(5, 0), hab) and _point_ok(p + Vector2(-5, 0), hab)


func spawn_creature(c: Dictionary) -> Node2D:
	var sid := str(c["species"])
	var data := Species.get_species(sid)
	if data.is_empty():
		return null
	var pos := Vector2(int(c["tx"]) * 16 + 8, int(c["ty"]) * 16 + 12)
	var hab := str(data.get("habitat", "land"))
	if not _valid_spawn(pos, hab):
		return null
	var mult := _danger
	if GameState.dimension == "overworld":
		mult = 1.0 + clampf(pos.length() / 16.0 / 220.0, 0.0, 1.2)
	var cr = CreatureScript.new()
	cr.setup(sid, str(c["id"]), self, mult)
	cr.position = pos
	entities.add_child(cr)
	return cr


func spawn_fx(id: String, pos: Vector2, rot: float = 0.0, scl: float = 1.0, loop_seconds: float = -1.0) -> Node:
	var f = FxScript.new()
	f.setup(id, pos, rot, scl, loop_seconds)
	f.z_index = 4
	entities.add_child(f)
	return f


func spawn_projectile(kind: String, pos: Vector2, dir: Vector2, dmg: float, radius: float = 26.0, spd: float = -1.0) -> void:
	var p = ProjScript.new()
	p.world = self
	p.kind = kind
	p.position = pos
	p.dir = dir.normalized()
	p.dmg = dmg
	p.radius = radius
	if spd > 0.0:
		p.speed = spd
	elif kind == "arrow" or kind == "enemy_arrow":
		p.speed = 240.0 if kind == "arrow" else 130.0
	else:
		p.speed = 190.0
	entities.add_child(p)


# ------------------------------------------------------------ recoleccion
func hit_harvest(origin: Vector2, dir: Vector2, mult: float) -> void:
	var h: Dictionary = chunk_view.harvest_near(origin, dir, 24.0)
	if h.is_empty():
		return
	h["hp"] = float(h["hp"]) - mult
	var node = h["node"]
	if is_instance_valid(node):
		var tw := create_tween()
		tw.tween_property(node, "rotation", 0.06, 0.05)
		tw.tween_property(node, "rotation", -0.06, 0.05)
		tw.tween_property(node, "rotation", 0.0, 0.05)
	spawn_fx("hit_spark", h["pos"] + Vector2(0, -10), 0.0, 0.4)
	Audio.play("hit")
	if float(h["hp"]) > 0.0:
		return
	GameState.mark_depleted(str(h["id"]))
	chunk_view.deplete_harvestable(h)
	if str(h["kind"]) == "tree":
		var n := randi_range(2, 4)
		GameState.add_item("wood", n)
		if str(h["tex"]) == "fruit":
			GameState.add_item("apple", 2)
		hud.toast_text(Loc.t("chop_got") % n)
	else:
		var n2 := randi_range(1, 3)
		GameState.add_item("stone", n2)
		if randf() < 0.1:
			GameState.add_item("gem", 1)
		hud.toast_text(Loc.t("mine_got") % n2)
	Audio.play("collect")


# ------------------------------------------------------------ eventos
func on_creature_killed(c) -> void:
	GameState.mark_depleted(c.cid)
	var drops: Dictionary = c.data.get("drops", {})
	var got_gold := 0
	for k in drops.keys():
		if str(k) == "gold":
			got_gold = int(float(drops[k]) * randf_range(0.7, 1.4))
			GameState.gold += got_gold
		elif randf() < float(drops[k]):
			GameState.add_item(str(k), 1)
	if got_gold > 0:
		hud.toast_text("+%d %s" % [got_gold, Loc.t("hud_gold")])
	if str(c.data["behavior"]) == "hostile" and (c.species_id.begins_with("bandit") or c.species_id == "thief"):
		GameState.change_rep(2)
	if str(c.data["behavior"]) == "guard":
		GameState.change_rep(-30)
		GameState.wanted_until = GameState.game_time + 600.0
	if not GameState.quest.is_empty() and str(GameState.quest.get("type", "")) == "kill":
		var q: Dictionary = GameState.quest
		var target := str(q["species"])
		if c.species_id == target or (target == "bandit" and c.species_id.begins_with("bandit")):
			q["count"] = mini(int(q["need"]), int(q["count"]) + 1)
	if c.species_id == "demon":
		GameState.boss_defeated = true
		hud.big_message("boss_win")
		spawn_fx("big_explosion", c.position, 0.0, 1.0)
		Audio.play("death")
		camera_shake(0.6)
	elif bool(c.data.get("boss", false)):
		hud.big_message("miniboss_down")
		spawn_fx("big_explosion", c.position, 0.0, 0.8)
		camera_shake(0.5)
	elif bool(c.data.get("mini_boss", false)):
		hud.toast("miniboss_down")
	GameState.changed.emit()


func on_player_died() -> void:
	hud.big_message("died")
	Audio.play("death")
	_respawn_t = 2.6


func _respawn() -> void:
	GameState.hp = GameState.max_hp * 0.5
	GameState.hunger = maxf(GameState.hunger, 40.0)
	GameState.gold = int(GameState.gold * 0.5)
	player.dead = false
	player.poison_t = 0.0
	player.sprite.modulate = Color.WHITE
	_enter_dimension("overworld", RESPAWN_POS)
	GameState.save_game()


# ------------------------------------------------------------ interacciones
func interact() -> void:
	if hud.dialogue_open or input_locked():
		return
	var it: Dictionary = chunk_view.nearest_interactable(player.position, 30.0)
	if it.is_empty():
		if in_dungeon() and GameState.has_item("torch"):
			_place_torch()
		else:
			hud.toast("nothing_here")
		return
	var d: Dictionary = it["data"]
	match str(it["type"]):
		"npc":
			_talk_npc(it)
		"cave":
			GameState.return_pos = it["pos"]
			Audio.play("open")
			_change_dimension("dungeon:" + str(it["id"]))
		"boss_gate":
			GameState.return_pos = it["pos"]
			Audio.play("open")
			_change_dimension("boss")
		"door":
			_enter_building(d, it["pos"])
		"exit":
			Audio.play("back")
			_exit_dimension()
		"chest":
			_open_chest(it)
		"shrub":
			_gather(it)
		"herb":
			_gather_herb(it)
		"bed_rent":
			_rent_bed(25)


func _enter_building(d: Dictionary, door_pos: Vector2) -> void:
	var bt := str(d["btype"])
	if is_night() and bt in ["shop", "smith", "tower", "hut"]:
		hud.toast("closed_night")
		Audio.play("error")
		return
	GameState.return_pos = door_pos
	GameState.interior_ctx = {"vname": str(d.get("vname", "")), "village": str(d.get("village", "")), "btype": bt}
	Audio.play("open")
	hud.toast_text(Loc.t("entering") % Loc.t("place_" + bt))
	_change_dimension("interior:%s:%s" % [bt, str(d["id"])])


func _gather(it: Dictionary) -> void:
	var id := str(it["id"])
	if GameState.is_depleted(id):
		hud.toast("bush_empty")
		return
	GameState.mark_depleted(id)
	var n := randi_range(1, 3)
	GameState.add_item("apple", n)
	var fruit: Node = (it["node"] as Node).get_node_or_null("Fruit")
	if fruit != null:
		fruit.visible = false
	hud.toast_text("+%d %s" % [n, Loc.t("item_apple")])
	Audio.play("collect")
	if randf() < 0.12 and GameState.dimension == "overworld":
		_ambush()


func _ambush() -> void:
	hud.big_message("ambush")
	camera_shake(0.5)
	var pool := ["mushroom", "spider", "slime"]
	for i in 3:
		var a := i * TAU / 3.0 + randf()
		var tx := floori(player.position.x / 16.0) + roundi(cos(a) * 3.0)
		var ty := floori(player.position.y / 16.0) + roundi(sin(a) * 3.0)
		spawn_creature({"species": pool[i % pool.size()], "tx": tx, "ty": ty, "id": "ambush_%d_%d" % [Time.get_ticks_msec(), i]})


func _gather_herb(it: Dictionary) -> void:
	var id := str(it["id"])
	if GameState.is_depleted(id):
		return
	GameState.mark_depleted(id)
	GameState.add_item("herb", 1)
	(it["node"] as CanvasItem).visible = false
	hud.toast("herb_got")
	Audio.play("collect")


func _open_chest(it: Dictionary) -> void:
	var d: Dictionary = it["data"]
	var id := str(it["id"])
	var key := "chest_" + id
	if GameState.is_depleted(key):
		hud.toast("chest_empty")
		return
	GameState.mark_depleted(key)
	var node = it["node"]
	if node != null:
		(node as CanvasItem).modulate = Color(0.5, 0.5, 0.5, 0.8)
	if bool(d.get("owned", false)):
		GameState.change_rep(-8)
		hud.toast("chest_theft")
		if randf() < 0.35:
			GameState.wanted_until = GameState.game_time + 300.0
			hud.toast("wanted")
	var big := bool(d.get("big", false))
	var gold := randi_range(120, 300) if big else randi_range(15, 60)
	GameState.gold += gold
	var loot: Array = []
	var roll := randf()
	if roll < 0.3:
		loot.append("potion_hp")
	elif roll < 0.5:
		loot.append("potion_mp")
	elif roll < 0.65:
		loot.append("herb")
	elif roll < 0.8:
		loot.append("scroll")
	if randf() < 0.2:
		loot.append("gem")
	if randf() < 0.07:
		loot.append("ring")
	if big:
		loot.append("gem")
		loot.append(["sword2", "axe", "spear", "helm2", "armor2", "boots", "amulet"][randi() % 7])
	GameState.add_item("arrow", 6)
	var names := ""
	for l in loot:
		GameState.add_item(str(l), 1)
		names += ", " + Loc.t("item_" + str(l))
	hud.toast_text("+%d %s%s" % [gold, Loc.t("hud_gold"), names])
	Audio.play("pickup")


# ------------------------------------------------------------ dialogos con habitantes
func _price_mult() -> float:
	var rep := GameState.reputation
	if rep > 40:
		return 0.9
	if rep < -20:
		return 1.4
	return 1.0


func _talk_npc(it: Dictionary) -> void:
	var d: Dictionary = it["data"]
	var role := str(d.get("role", "villager"))
	var nid := str(d.get("id", ""))
	if str(d.get("village", "")) == "":
		d["village"] = str(GameState.interior_ctx.get("village", ""))
	var talks := int(GameState.talk_counts.get(nid, 0))
	GameState.talk_counts[nid] = talks + 1
	var key := Dialogue.greeting_key(role, GameState.reputation, GameState.is_night(), talks, absi(nid.hash()) % 10000)
	var speaker := "%s - %s" % [str(d.get("name", "")), Loc.t("role_" + role)]
	Audio.play("dialog")
	var opts: Array = []
	var banned: bool = GameState.shop_ban.has(str(d.get("village", ""))) and GameState.game_time < float(GameState.shop_ban[str(d.get("village", ""))])
	var hostile: bool = GameState.reputation < -50 or banned
	if role in ["merchant", "smith"]:
		if not hostile:
			opts.append({"id": "trade", "label": Loc.t("opt_trade")})
	elif role == "witch":
		if not hostile:
			opts.append({"id": "trade", "label": Loc.t("opt_trade")})
			if not GameState.known_recipes.has("alchemy"):
				opts.append({"id": "alchemy", "label": Loc.t("opt_alchemy") % 80})
	elif role == "mage":
		if not hostile:
			opts.append({"id": "learn", "label": Loc.t("opt_learn")})
			if GameState.magic_rank > 0 and GameState.magic_rank < 5:
				opts.append({"id": "rank", "label": Loc.t("opt_rank") % GameState.rank_up_cost()})
			if GameState.magic_rank == 0:
				opts.append({"id": "start_magic", "label": Loc.t("opt_rank") % 100})
	elif role == "innkeeper":
		if not hostile:
			opts.append({"id": "rest", "label": Loc.t("opt_rest") % int(25 * _price_mult())})
	elif role == "healer":
		opts.append({"id": "heal", "label": Loc.t("opt_heal")})
	elif role == "elder" or role == "guard":
		if not GameState.quest.is_empty() and _quest_ready():
			opts.append({"id": "turnin", "label": Loc.t("opt_turnin")})
		elif GameState.quest.is_empty() and not hostile:
			opts.append({"id": "quest", "label": Loc.t("opt_quest") if role == "elder" else Loc.t("opt_bounty")})
	opts.append({"id": "talk", "label": Loc.t("opt_rumor")})
	opts.append({"id": "bye", "label": Loc.t("opt_bye")})
	hud.show_menu(speaker, Loc.t(key), opts, _on_npc_option.bind(d))


func _on_npc_option(opt: String, d: Dictionary) -> void:
	var role := str(d.get("role", "villager"))
	var speaker := "%s - %s" % [str(d.get("name", "")), Loc.t("role_" + role)]
	match opt:
		"talk":
			hud.show_dialogue(speaker, [_rumor_text(d)])
		"trade":
			var kind := {"merchant": "shop", "smith": "smith", "witch": "hut", "mage": "tower"}.get(role, "shop") as String
			hud.open_shop(kind, {"village": str(d.get("village", "")), "price_mult": _price_mult(), "steal_cb": _attempt_steal.bind(d)})
		"learn":
			hud.open_teacher()
		"rank":
			if GameState.magic_rank >= 5:
				hud.toast("rank_max")
			elif not GameState.can_rank_up():
				hud.toast_text(Loc.t("rank_need_xp") % int(Spells.RANK_XP[GameState.magic_rank + 1]))
			elif GameState.rank_up():
				hud.toast("rank_up_done")
				Audio.play("confirm")
				spawn_fx("holy_heal", player.position, 0.0, 0.6)
			else:
				hud.toast("not_enough_gold")
		"start_magic":
			if GameState.spend(100):
				GameState.magic_rank = 1
				hud.toast("rank_up_done")
				Audio.play("confirm")
			else:
				hud.toast("not_enough_gold")
		"alchemy":
			if GameState.spend(80):
				GameState.known_recipes.append("alchemy")
				hud.toast("learned_alchemy")
				Audio.play("confirm")
			else:
				hud.toast("not_enough_gold")
		"rest":
			_rent_bed(int(25 * _price_mult()))
		"heal":
			GameState.hp = GameState.max_hp
			GameState.mp = GameState.max_mp
			player.poison_t = 0.0
			GameState.changed.emit()
			spawn_fx("holy_heal", player.position, 0.0, 0.6)
			Audio.play("heal")
		"quest":
			_offer_quest(d)
		"turnin":
			_turn_in_quest()


func _rumor_text(d: Dictionary) -> String:
	var talks := int(GameState.talk_counts.get(str(d.get("id", "")), 0))
	var n := Dialogue.rumor_key(talks, absi(str(d.get("id", "")).hash()) % 10000)
	var tile := Vector2i(floori(player.position.x / 16.0), floori(player.position.y / 16.0))
	if n == 1 and GameState.dimension == "overworld":
		var cave: Dictionary = terrain.nearest_cave(tile)
		if not cave.is_empty():
			var info: Dictionary = terrain.direction_to(tile, Vector2i(int(cave["tx"]), int(cave["ty"])))
			return Loc.t("rumor_1") % [Loc.t(DIRS[int(info["idx"])]), int(info["dist"])]
		n = 3
	if n == 2 and GameState.dimension == "overworld":
		var info2: Dictionary = terrain.direction_to(tile, terrain.boss_gate_tile())
		return Loc.t("rumor_2") % [Loc.t(DIRS[int(info2["idx"])]), int(info2["dist"])]
	if n <= 2:
		n = 3
	return Loc.t("rumor_%d" % n)


func _attempt_steal(item_id: String, d: Dictionary) -> bool:
	var chance := 0.5
	if randf() < chance:
		GameState.add_item(item_id, 1)
		GameState.change_rep(-5)
		hud.toast("steal_ok")
		return true
	GameState.change_rep(-25)
	GameState.wanted_until = GameState.game_time + 300.0
	GameState.shop_ban[str(d.get("village", ""))] = GameState.game_time + 600.0
	hud.toast("steal_fail")
	hud.toast_text(Loc.t("wanted"))
	hud.close_shop()
	return false


func _rent_bed(cost: int) -> void:
	if not GameState.spend(cost):
		hud.toast("not_enough_gold")
		Audio.play("error")
		return
	var wait_hours := fposmod(7.0 - GameState.hour, 24.0)
	GameState.game_time += wait_hours / GameState.DAY_SPEED
	GameState.hour = 7.0
	GameState.hp = GameState.max_hp
	GameState.mp = GameState.max_mp
	GameState.hunger = minf(100.0, GameState.hunger + 20.0)
	player.poison_t = 0.0
	hud.do_fade()
	hud.toast("rested")
	Audio.play("heal")
	GameState.save_game()


# ------------------------------------------------------------ misiones
func _quest_ready() -> bool:
	var q: Dictionary = GameState.quest
	if q.is_empty():
		return false
	if str(q["type"]) == "kill":
		return int(q["count"]) >= int(q["need"])
	return GameState.item_count(str(q["item"])) >= int(q["need"])


func _offer_quest(d: Dictionary) -> void:
	var q := {}
	if randf() < 0.55:
		var sp := str(QUEST_KILLS[randi() % QUEST_KILLS.size()])
		var need := randi_range(3, 6)
		q = {"type": "kill", "species": sp, "need": need, "count": 0, "reward": 40 + need * 18}
	else:
		var item := str(QUEST_ITEMS[randi() % QUEST_ITEMS.size()])
		var need2 := randi_range(4, 8)
		q = {"type": "fetch", "item": item, "need": need2, "count": 0, "reward": 30 + need2 * 9}
	GameState.quest = q
	var speaker := "%s - %s" % [str(d.get("name", "")), Loc.t("role_" + str(d.get("role", "elder")))]
	var text := ""
	if str(q["type"]) == "kill":
		text = Loc.t("quest_offer_kill") % [int(q["need"]), Loc.t("sp_" + str(q["species"])), int(q["reward"])]
	else:
		text = Loc.t("quest_offer_fetch") % [int(q["need"]), Loc.t("item_" + str(q["item"])), int(q["reward"])]
	hud.show_dialogue(speaker, [text])
	hud.toast("quest_accepted")
	GameState.changed.emit()


func _turn_in_quest() -> void:
	var q: Dictionary = GameState.quest
	if q.is_empty() or not _quest_ready():
		hud.toast("quest_ready")
		return
	if str(q["type"]) == "fetch":
		GameState.remove_item(str(q["item"]), int(q["need"]))
	GameState.gold += int(q["reward"])
	GameState.quests_done += 1
	GameState.change_rep(5)
	hud.toast_text(Loc.t("quest_complete") % int(q["reward"]))
	GameState.quest = {}
	Audio.play("pickup")
	GameState.changed.emit()
