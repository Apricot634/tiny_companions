extends RefCounted
## Mundo abierto generado por semilla: biomas, rios, montañas con senderos, aldeas, cuevas, campamentos.
## Interfaz comun con DungeonGen/InteriorGen: tile_at, chunk_objects, chunk_creatures, start_pos, finite.

const T := preload("res://data/tiles.gd")
const Species := preload("res://data/species.gd")
const VillageGen := preload("res://world/village_gen.gd")
const Names := preload("res://data/names.gd")
const CHUNK := 16
const CELL := 48

var world_seed: int
var finite := false
var night := false
var _elev := FastNoiseLite.new()
var _moist := FastNoiseLite.new()
var _temp := FastNoiseLite.new()
var _river := FastNoiseLite.new()
var _trail := FastNoiseLite.new()
var _detail := FastNoiseLite.new()
var _village_cache := {}
var _cave_cache := {}
var _camp_cache := {}
var _gate_tile := Vector2i.ZERO


func _init(seed_value: int) -> void:
	world_seed = seed_value
	_setup(_elev, seed_value, 0.011, 4)
	_setup(_moist, seed_value + 101, 0.016, 3)
	_setup(_temp, seed_value + 202, 0.008, 2)
	_setup(_river, seed_value + 303, 0.012, 1)
	_setup(_trail, seed_value + 404, 0.03, 2)
	_setup(_detail, seed_value + 505, 0.05, 2)
	_gate_tile = _find_gate()


func _setup(n: FastNoiseLite, s: int, freq: float, octaves: int) -> void:
	n.seed = s
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = freq
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = octaves


func start_pos() -> Vector2:
	return Vector2(8.0, 8.0)


func _hash(a: int, b: int, c: int) -> int:
	var h: int = (world_seed * 73856093) ^ (a * 19349663) ^ (b * 83492791) ^ (c * 2654435761)
	h = (h ^ (h >> 13)) * 1274126177
	return (h ^ (h >> 16)) & 0x7fffffff


func _rng(a: int, b: int, c: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = _hash(a, b, c)
	return r


# ------------------------------------------------------------ terreno
func elevation(tx: int, ty: int) -> float:
	var e := _elev.get_noise_2d(tx, ty)
	var d := sqrt(float(tx * tx + ty * ty))
	if d < 34.0:
		var k := clampf((d - 12.0) / 22.0, 0.0, 1.0)
		e = lerpf(0.1, e, k)
	return e


func tile_at(tx: int, ty: int) -> int:
	var e := elevation(tx, ty)
	var d := sqrt(float(tx * tx + ty * ty))
	if e < -0.46:
		return T.DEEP
	if e < -0.22:
		return T.WATER
	if d > 16.0 and e < 0.4 and absf(_river.get_noise_2d(tx, ty)) < 0.028:
		return T.WATER
	if e < -0.13:
		return T.SAND
	if e > 0.4:
		if absf(_trail.get_noise_2d(tx, ty)) < 0.075:
			return T.TRAIL
		if e > 0.6:
			return T.PEAK
		return T.STONE
	if e > 0.32:
		return T.GRAVEL
	var v := village_at_tile(tx, ty)
	if not v.is_empty():
		var tl: Dictionary = v["tiles"]
		var key := Vector2i(tx, ty)
		if tl.has(key):
			return int(tl[key])
		return T.GRASS
	var m := _moist.get_noise_2d(tx, ty)
	var t := _temp.get_noise_2d(tx, ty)
	if t < -0.2 and d > 30.0:
		return T.SNOW
	if t > 0.22 and m < 0.05 and d > 30.0:
		return T.DESERT
	if m > 0.32 and t > -0.05 and e < 0.12 and d > 30.0:
		return T.SWAMP
	if m > 0.1 and d > 12.0:
		return T.FOREST
	if d > 10.0 and _detail.get_noise_2d(tx, ty) > 0.28:
		return T.MEADOW
	return T.GRASS


func biome_of_tile(t: int) -> String:
	if t == T.DEEP or t == T.WATER:
		return "water"
	elif t == T.SAND:
		return "beach"
	elif t == T.FOREST:
		return "forest"
	elif t == T.DESERT:
		return "desert"
	elif t == T.SNOW:
		return "snow"
	elif t == T.SWAMP:
		return "swamp"
	elif t == T.MEADOW:
		return "meadow"
	elif t == T.STONE or t == T.GRAVEL or t == T.TRAIL or t == T.PEAK:
		return "mountain"
	return "plains"


func biome_at(tx: int, ty: int) -> String:
	return biome_of_tile(tile_at(tx, ty))


## Nombre de region para mostrar: {biome, name, village}.
func region_at(tx: int, ty: int) -> Dictionary:
	var v := village_at_tile(tx, ty)
	if not v.is_empty():
		return {"biome": "village", "name": str(v["name"]), "village": str(v["id"])}
	var b := biome_at(tx, ty)
	var r := _rng(floori(float(tx) / 90.0), floori(float(ty) / 90.0), 31)
	return {"biome": b, "name": Names.place(r), "village": ""}


# ------------------------------------------------------------ aldeas, cuevas y campamentos
func _cell_of(tx: int, ty: int) -> Vector2i:
	return Vector2i(floori(float(tx) / CELL), floori(float(ty) / CELL))


func village_at_tile(tx: int, ty: int) -> Dictionary:
	var v := village_in_cell(_cell_of(tx, ty))
	if v.is_empty():
		return v
	var rad: int = int(v["r"]) + 2
	if absi(tx - int(v["tx"])) <= rad and absi(ty - int(v["ty"])) <= rad:
		return v
	return {}


func village_in_cell(c: Vector2i) -> Dictionary:
	if _village_cache.has(c):
		return _village_cache[c]
	var out := {}
	if c == Vector2i(0, -1):
		out = VillageGen.build(14, -10, "v_0_m1", _hash(c.x, c.y, 11), "crossroads")
	else:
		var r := _rng(c.x, c.y, 11)
		if r.randf() < 0.5:
			var tx := c.x * CELL + r.randi_range(21, CELL - 21)
			var ty := c.y * CELL + r.randi_range(21, CELL - 21)
			var e := elevation(tx, ty)
			var m := _moist.get_noise_2d(tx, ty)
			if e > -0.05 and e < 0.3 and m < 0.3:
				out = VillageGen.build(tx, ty, "v_%d_%d" % [c.x, c.y], _hash(c.x, c.y, 12))
	_village_cache[c] = out
	return out


func _theme_for(tx: int, ty: int, r: RandomNumberGenerator) -> String:
	var b := biome_at(tx, ty)
	match b:
		"snow":
			return "ice"
		"swamp":
			return "bog"
		"forest":
			return ["grove", "cave", "nest", "lair"][r.randi() % 4]
		"desert":
			return ["ruins", "mine", "crypt", "nest"][r.randi() % 4]
		"mountain":
			return ["mine", "cave", "ice" if r.randf() < 0.3 else "cave"][r.randi() % 3]
	return ["crypt", "lair", "cave", "ruins", "grove"][r.randi() % 5]


func cave_in_cell(c: Vector2i) -> Dictionary:
	if _cave_cache.has(c):
		return _cave_cache[c]
	var out := {}
	if c == Vector2i(-1, 0):
		out = {"tx": -16, "ty": 14, "id": "cave@m1_0", "theme": "cave"}
	else:
		var r := _rng(c.x, c.y, 23)
		if r.randf() < 0.55:
			var tx := c.x * CELL + r.randi_range(6, CELL - 6)
			var ty := c.y * CELL + r.randi_range(6, CELL - 6)
			var t := tile_at(tx, ty)
			if T.is_land(t) and t != T.PATH and t != T.SAND and t != T.FARM and t != T.TRAIL:
				var v := village_in_cell(c)
				if v.is_empty() or Vector2(tx - int(v["tx"]), ty - int(v["ty"])).length() > float(v["r"]) + 6.0:
					var theme := _theme_for(tx, ty, r)
					out = {"tx": tx, "ty": ty, "id": "%s@%d_%d" % [theme, c.x, c.y], "theme": theme}
	_cave_cache[c] = out
	return out


func camp_in_cell(c: Vector2i) -> Dictionary:
	if _camp_cache.has(c):
		return _camp_cache[c]
	var out := {}
	var r := _rng(c.x, c.y, 41)
	if r.randf() < 0.3 and (absi(c.x) + absi(c.y)) > 1:
		var tx := c.x * CELL + r.randi_range(8, CELL - 8)
		var ty := c.y * CELL + r.randi_range(8, CELL - 8)
		var t := tile_at(tx, ty)
		if (t == T.GRASS or t == T.FOREST or t == T.MEADOW or t == T.DESERT) and village_at_tile(tx, ty).is_empty():
			out = {"tx": tx, "ty": ty, "id": "camp_%d_%d" % [c.x, c.y]}
	_camp_cache[c] = out
	return out


func boss_gate_tile() -> Vector2i:
	return _gate_tile


func _find_gate() -> Vector2i:
	var r := _rng(7, 7, 7)
	var base := r.randf() * TAU
	var dist := 80
	while dist < 260:
		for k in 12:
			var a := base + k * 0.52
			var tx := roundi(cos(a) * dist)
			var ty := roundi(sin(a) * dist)
			var ok := true
			for ox in range(-1, 2):
				for oy in range(-1, 2):
					var t := tile_at(tx + ox, ty + oy)
					if not (t == T.GRASS or t == T.FOREST or t == T.DESERT or t == T.GRAVEL or t == T.MEADOW or t == T.SNOW):
						ok = false
			if ok:
				return Vector2i(tx, ty)
		dist += 8
	return Vector2i(120, 0)


## Direccion aproximada (0..7: este, sureste, sur, ...) y distancia a un tile.
func direction_to(from_t: Vector2i, to_t: Vector2i) -> Dictionary:
	var v := Vector2(to_t.x - from_t.x, to_t.y - from_t.y)
	return {"idx": posmod(roundi(v.angle() / (PI / 4.0)), 8), "dist": int(roundf(v.length() / 10.0)) * 10}


func nearest_cave(from_t: Vector2i) -> Dictionary:
	var best := {}
	var best_d := 99999.0
	var c0 := _cell_of(from_t.x, from_t.y)
	for dx in range(-3, 4):
		for dy in range(-3, 4):
			var cave := cave_in_cell(Vector2i(c0.x + dx, c0.y + dy))
			if cave.is_empty():
				continue
			var d := Vector2(int(cave["tx"]) - from_t.x, int(cave["ty"]) - from_t.y).length()
			if d < best_d:
				best_d = d
				best = cave
	return best


# ------------------------------------------------------------ objetos por chunk
func _tree_for(t: int, r: RandomNumberGenerator) -> String:
	if t == T.FOREST:
		return ["moss", "moss2", "oak1", "oak2", "autumn", "oak3"][r.randi() % 6]
	elif t == T.GRASS:
		return ["oak1", "oak2", "oak3", "autumn2"][r.randi() % 4]
	elif t == T.MEADOW:
		return ["flower", "fruit", "oak2"][r.randi() % 3]
	elif t == T.SNOW:
		return ["snow1", "snow2", "snow3"][r.randi() % 3]
	elif t == T.SWAMP:
		return ["burned", "broken", "broken2"][r.randi() % 3]
	elif t == T.DESERT or t == T.SAND:
		return ["palm1", "palm2"][r.randi() % 2]
	return "oak1"


func chunk_objects(cx: int, cy: int) -> Array:
	var out: Array = []
	var r := _rng(cx, cy, 1)
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	var used: Array = []
	var gate := _gate_tile
	if gate.x >= x0 and gate.x < x0 + CHUNK and gate.y >= y0 and gate.y < y0 + CHUNK:
		out.append({"type": "boss_gate", "tx": gate.x, "ty": gate.y, "variant": 0, "id": "boss_gate"})
		used.append(gate)
	var c := _cell_of(x0 + 8, y0 + 8)
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var cc := Vector2i(c.x + dx, c.y + dy)
			var cave := cave_in_cell(cc)
			if not cave.is_empty():
				var ct := Vector2i(int(cave["tx"]), int(cave["ty"]))
				if _in_chunk(ct.x, ct.y, x0, y0):
					out.append({"type": "cave", "tx": ct.x, "ty": ct.y, "variant": 0, "id": str(cave["id"]), "theme": str(cave["theme"])})
					used.append(ct)
			var camp := camp_in_cell(cc)
			if not camp.is_empty():
				_camp_objects(camp, x0, y0, out, used)
			var v := village_in_cell(cc)
			if not v.is_empty():
				_village_objects(v, x0, y0, out, used)
	for i in 26:
		var tx := x0 + r.randi_range(0, CHUNK - 1)
		var ty := y0 + r.randi_range(0, CHUNK - 1)
		var roll := r.randf()
		var d := sqrt(float(tx * tx + ty * ty))
		if d < 5.0 or not village_at_tile(tx, ty).is_empty():
			continue
		var p := Vector2i(tx, ty)
		var near := false
		for u in used:
			if absi(u.x - p.x) <= 1 and absi(u.y - p.y) <= 1:
				near = true
		if near:
			continue
		var t := tile_at(tx, ty)
		var typ := ""
		var tex := ""
		if t == T.FOREST:
			if roll < 0.5:
				typ = "tree"
			elif roll < 0.56:
				typ = "shrub"
			elif roll < 0.6:
				typ = "rock"
			elif roll < 0.66:
				typ = "herb"
		elif t == T.GRASS:
			if roll < 0.09:
				typ = "tree"
			elif roll < 0.14:
				typ = "shrub"
			elif roll < 0.18:
				typ = "rock"
			elif roll < 0.21:
				typ = "herb"
		elif t == T.MEADOW:
			if roll < 0.06:
				typ = "tree"
			elif roll < 0.16:
				typ = "herb"
			elif roll < 0.2:
				typ = "shrub"
		elif t == T.DESERT:
			if roll < 0.09:
				typ = "cactus"
			elif roll < 0.13:
				typ = "rock"
			elif roll < 0.15:
				typ = "bones"
			elif roll < 0.17:
				typ = "tree"
		elif t == T.SAND:
			if roll < 0.03:
				typ = "tree"
		elif t == T.SNOW:
			if roll < 0.22:
				typ = "tree"
			elif roll < 0.26:
				typ = "rock"
		elif t == T.SWAMP:
			if roll < 0.15:
				typ = "tree"
			elif roll < 0.2:
				typ = "herb"
			elif roll < 0.22:
				typ = "bones"
		elif t == T.GRAVEL:
			if roll < 0.18:
				typ = "rock"
		elif t == T.STONE:
			if roll < 0.3:
				typ = "peak"
		if typ == "tree":
			tex = _tree_for(t, r)
		if typ != "":
			used.append(p)
			out.append({"type": typ, "tx": tx, "ty": ty, "variant": r.randi_range(0, 2), "tex": tex, "id": "o_%d_%d_%d" % [cx, cy, i]})
	return out


func _in_chunk(tx: int, ty: int, x0: int, y0: int) -> bool:
	return tx >= x0 and tx < x0 + CHUNK and ty >= y0 and ty < y0 + CHUNK


func _camp_objects(camp: Dictionary, x0: int, y0: int, out: Array, used: Array) -> void:
	var tx: int = int(camp["tx"])
	var ty: int = int(camp["ty"])
	var parts := [["tent", -3, -1], ["tent", 3, -1], ["campfire", 0, 1], ["chest", 0, -3]]
	for p in parts:
		var px: int = tx + int(p[1])
		var py: int = ty + int(p[2])
		if _in_chunk(px, py, x0, y0):
			var o := {"type": str(p[0]), "tx": px, "ty": py, "variant": 0, "id": "%s_%s" % [str(camp["id"]), str(p[0])]}
			if str(p[0]) == "chest":
				o["owned"] = false
			out.append(o)
			used.append(Vector2i(px, py))


func _village_objects(v: Dictionary, x0: int, y0: int, out: Array, used: Array) -> void:
	for b in v["buildings"]:
		if _in_chunk(int(b["tx"]), int(b["ty"]), x0, y0):
			out.append({"type": "building", "tx": int(b["tx"]), "ty": int(b["ty"]), "variant": int(b["variant"]), "btype": str(b["type"]),
				"sprite": str(b["sprite"]), "id": str(b["id"]), "bidx": int(b["idx"]), "village": str(v["id"]), "vname": str(v["name"])})
			used.append(Vector2i(int(b["tx"]), int(b["ty"])))
	for dcr in v["decor"]:
		if _in_chunk(int(dcr["tx"]), int(dcr["ty"]), x0, y0):
			out.append({"type": "decor", "tx": int(dcr["tx"]), "ty": int(dcr["ty"]), "variant": 0, "sprite": str(dcr["type"]),
				"id": "%s_d%d_%d" % [str(v["id"]), int(dcr["tx"]), int(dcr["ty"])]})
			used.append(Vector2i(int(dcr["tx"]), int(dcr["ty"])))
	for n in v["npcs"]:
		if _in_chunk(int(n["tx"]), int(n["ty"]), x0, y0):
			out.append({"type": "npc", "tx": int(n["tx"]), "ty": int(n["ty"]), "variant": 0, "role": str(n["role"]), "name": str(n["name"]),
				"skin": int(n["skin"]), "id": str(n["id"]), "village": str(v["id"]), "vname": str(v["name"])})
			used.append(Vector2i(int(n["tx"]), int(n["ty"])))


# ------------------------------------------------------------ criaturas por chunk
func _weighted(table: Array, r: RandomNumberGenerator) -> String:
	var total := 0
	for e in table:
		total += int(e[1])
	var roll := r.randi_range(1, maxi(1, total))
	for e in table:
		roll -= int(e[1])
		if roll <= 0:
			return str(e[0])
	return str(table[0][0])


func chunk_creatures(cx: int, cy: int) -> Array:
	var out: Array = []
	var r := _rng(cx, cy, 2)
	var count := r.randi_range(1, 4)
	for i in count:
		var tx := cx * CHUNK + r.randi_range(1, CHUNK - 2)
		var ty := cy * CHUNK + r.randi_range(1, CHUNK - 2)
		var d := sqrt(float(tx * tx + ty * ty))
		if d < 10.0 or not village_at_tile(tx, ty).is_empty():
			continue
		var t := tile_at(tx, ty)
		var biome := biome_of_tile(t)
		if t == T.PATH:
			biome = "plains"
		if not Species.BIOME_SPAWNS.has(biome):
			continue
		var sp := _weighted(Species.BIOME_SPAWNS[biome], r)
		if night and biome != "water" and d > 24.0 and r.randf() < 0.45:
			sp = _weighted(Species.NIGHT_EXTRA, r)
		var data := Species.get_species(sp)
		if data.is_empty():
			continue
		if d < 36.0 and str(data["behavior"]) == "hostile":
			sp = "bunny"
		out.append({"species": sp, "tx": tx, "ty": ty, "id": "c_%d_%d_%d" % [cx, cy, i]})
	# animales de granja cerca de aldeas agricolas
	var c := _cell_of(cx * CHUNK + 8, cy * CHUNK + 8)
	var v := village_in_cell(c)
	if not v.is_empty() and str(v["kind"]) == "farm":
		var tx2: int = int(v["tx"]) + r.randi_range(-14, 14)
		var ty2: int = int(v["ty"]) + r.randi_range(2, 14)
		if _in_chunk(tx2, ty2, cx * CHUNK, cy * CHUNK):
			out.append({"species": ["cow", "sheep", "chicken", "goat"][r.randi() % 4], "tx": tx2, "ty": ty2, "id": "farm_%d_%d_%d" % [cx, cy, tx2]})
	# bandidos de campamento
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var camp := camp_in_cell(Vector2i(c.x + dx, c.y + dy))
			if camp.is_empty():
				continue
			for k in 3:
				var bx: int = int(camp["tx"]) + k * 2 - 2
				var by: int = int(camp["ty"]) + 3
				if _in_chunk(bx, by, cx * CHUNK, cy * CHUNK):
					out.append({"species": ["bandit", "bandit_archer", "bandit"][k], "tx": bx, "ty": by, "id": "%s_b%d" % [str(camp["id"]), k]})
			if _in_chunk(int(camp["tx"]), int(camp["ty"]) - 5, cx * CHUNK, cy * CHUNK) and _hash(int(camp["tx"]), int(camp["ty"]), 5) % 3 == 0:
				out.append({"species": "bandit_chief", "tx": int(camp["tx"]), "ty": int(camp["ty"]) - 5, "id": "%s_chief" % str(camp["id"])})
	return out
