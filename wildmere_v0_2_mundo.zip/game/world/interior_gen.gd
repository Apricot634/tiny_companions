extends RefCounted
## Interiores de casas y tiendas. Misma interfaz que Terrain/DungeonGen (finite, w, h, tile_at, chunk_objects...).
## Tipos: house, shop, inn, smith, tower (maestro de magia), hut (bruja/alquimista).

const T := preload("res://data/tiles.gd")
const Names := preload("res://data/names.gd")
const CHUNK := 16

var finite := true
var w := 14
var h := 10
var tiles := PackedInt32Array()
var objs: Array = []
var kind := "house"
var door := Vector2i.ZERO
var key := ""
var vname := ""
var npc_name := ""

const SKINS := {
	"merchant": [17, 21, 22], "innkeeper": [14, 15, 6], "smith": [9, 13, 23], "mage": [25, 3, 18],
	"witch": [5, 12, 19], "resident": [6, 10, 14, 15, 17, 18, 19, 22, 29, 30, 31, 32],
}


func tile_at(tx: int, ty: int) -> int:
	if tx < 0 or ty < 0 or tx >= w or ty >= h:
		return T.INTWALL
	return tiles[ty * w + tx]


func start_pos() -> Vector2:
	return Vector2(door.x * 16 + 8, (door.y - 1) * 16 + 12)


func _dims(k: String) -> Vector2i:
	match k:
		"shop":
			return Vector2i(16, 11)
		"inn":
			return Vector2i(18, 12)
		"smith":
			return Vector2i(15, 11)
		"tower":
			return Vector2i(14, 12)
		"hut":
			return Vector2i(11, 9)
	return Vector2i(12, 10)


func _add(o: Dictionary) -> void:
	objs.append(o)


func _furn(sprite: String, tx: int, ty: int) -> void:
	_add({"type": "furn", "sprite": sprite, "tx": tx, "ty": ty, "id": "%s_f%d" % [key, objs.size()]})


func _npc(role: String, tx: int, ty: int, r: RandomNumberGenerator, skin_key: String) -> void:
	var skins: Array = SKINS[skin_key]
	npc_name = Names.person(r)
	_add({"type": "npc", "tx": tx, "ty": ty, "role": role, "name": npc_name, "skin": int(skins[r.randi() % skins.size()]),
		"id": "%s_npc" % key, "village": "", "vname": vname, "indoor": true})


func generate(btype: String, seed_value: int, interior_key: String, village_name: String) -> void:
	kind = btype
	key = interior_key
	vname = village_name
	objs = []
	var d := _dims(btype)
	w = d.x
	h = d.y
	tiles = PackedInt32Array()
	tiles.resize(w * h)
	for i in tiles.size():
		tiles[i] = T.INTWALL
	for y in range(2, h - 1):
		for x in range(1, w - 1):
			tiles[y * w + x] = T.WOOD
	door = Vector2i(w / 2, h - 1)
	tiles[door.y * w + door.x] = T.WOOD
	var r := RandomNumberGenerator.new()
	r.seed = seed_value
	# alfombra central
	for y in range(h / 2 - 1, h / 2 + 2):
		for x in range(w / 2 - 2, w / 2 + 3):
			if r.randf() < 0.95:
				tiles[y * w + x] = T.CARPET
	_add({"type": "exit", "tx": door.x, "ty": door.y, "id": "exit"})
	match btype:
		"shop":
			_layout_shop(r)
		"inn":
			_layout_inn(r)
		"smith":
			_layout_smith(r)
		"tower":
			_layout_tower(r)
		"hut":
			_layout_hut(r)
		_:
			_layout_house(r)


func _layout_house(r: RandomNumberGenerator) -> void:
	_furn("bed" if r.randf() < 0.5 else "bed_blue", 2, 4)
	if r.randf() < 0.5:
		_furn("bed_blue", 4, 4)
	var tops := ["stove", "bookshelf", "shelf_goods", "herb_shelf"]
	_furn(str(tops[r.randi() % tops.size()]), w - 4, 3)
	_furn(str(tops[r.randi() % tops.size()]), w / 2 - 1, 3)
	_furn("table", w / 2, h / 2 + 1)
	_furn("chair", w / 2 - 2, h / 2 + 1)
	_furn("chair", w / 2 + 2, h / 2 + 1)
	_furn("barrel", w - 2, h - 3)
	_furn("plant", 1 + r.randi_range(0, 1), h - 3)
	_add({"type": "chest", "tx": w - 3, "ty": h / 2 + 2, "id": "%s_chest" % key, "owned": true})
	_npc("villager", w / 2 + 1, h / 2 - 1, r, "resident")


func _layout_shop(r: RandomNumberGenerator) -> void:
	for x in [3, 6, 9, 12]:
		_furn("shelf_goods" if x != 9 else "shelf_goods", x, 3)
	_furn("counter", w / 2 - 1, 6)
	_npc("merchant", w / 2, 5, r, "merchant")
	_furn("barrel", 1, 4)
	_furn("crate", 2, 4)
	_furn("crate", w - 2, 4)
	_furn("plant", w - 2, h - 3)
	_add({"type": "chest", "tx": w - 2, "ty": 3, "id": "%s_stock" % key, "owned": true})


func _layout_inn(r: RandomNumberGenerator) -> void:
	_furn("fireplace", w / 2 - 1, 3)
	for i in 4:
		_add({"type": "bed_rent", "sprite": "bed" if i % 2 == 0 else "bed_blue", "tx": 2 + i * 2, "ty": 6, "id": "%s_bed%d" % [key, i]})
	_furn("counter", w - 6, 5)
	_npc("innkeeper", w - 5, 4, r, "innkeeper")
	_furn("table", 4, h - 4)
	_furn("chair", 2, h - 4)
	_furn("table", w - 5, h - 3)
	_furn("barrel", 1, 3)
	_furn("barrel", w - 2, 3)
	_furn("plant", w - 2, h - 3)


func _layout_smith(r: RandomNumberGenerator) -> void:
	_furn("forge", 3, 3)
	_furn("anvil", 6, 5)
	_furn("rack", w - 4, 3)
	_furn("counter", w / 2 - 1, 7)
	_npc("smith", w / 2, 6, r, "smith")
	_furn("barrel", 1, 6)
	_furn("crate", w - 2, 6)
	_furn("crate", w - 2, h - 3)
	_add({"type": "chest", "tx": 1, "ty": h - 3, "id": "%s_chest" % key, "owned": true})


func _layout_tower(r: RandomNumberGenerator) -> void:
	for x in [3, 6, 9]:
		_furn("bookshelf", x, 3)
	_furn("desk", w / 2, 6)
	_npc("mage", w / 2, 5, r, "mage")
	_add({"type": "prop", "sprite": "glow_crystal", "tx": 2, "ty": h - 3, "id": "%s_cr" % key})
	_add({"type": "prop", "sprite": "glow_crystal", "tx": w - 3, "ty": h - 3, "id": "%s_cr2" % key})
	_furn("bookshelf", w - 3, 8)
	_add({"type": "chest", "tx": 2, "ty": 5, "id": "%s_chest" % key, "owned": true})


func _layout_hut(r: RandomNumberGenerator) -> void:
	_furn("herb_shelf", w / 2 - 1, 3)
	_furn("cauldron", w / 2, h / 2)
	_npc("witch", w / 2 + 2, h / 2 - 1, r, "witch")
	_furn("bed_blue", 2, 4)
	_furn("plant", w - 2, 3)
	_furn("plant", 1, h - 3)
	_furn("barrel", w - 2, h - 3)
	_add({"type": "chest", "tx": w - 2, "ty": h / 2, "id": "%s_chest" % key, "owned": true})


func chunk_objects(cx: int, cy: int) -> Array:
	var out: Array = []
	var x0 := cx * CHUNK
	var y0 := cy * CHUNK
	for o in objs:
		if int(o["tx"]) >= x0 and int(o["tx"]) < x0 + CHUNK and int(o["ty"]) >= y0 and int(o["ty"]) < y0 + CHUNK:
			out.append(o)
	return out


func chunk_creatures(_cx: int, _cy: int) -> Array:
	return []
