extends RefCounted
## Criaturas y enemigos. Tres tipos de grafico:
##  - anims: hojas de animacion (animales y monstruos con sprites propios)
##  - tiny: sprite 16x16 de Tiny Creatures (CC0) animado por codigo (saltitos, balanceo)
##  - human: personaje de SuperRetroWorld (bandidos, guardias...) con 4 direcciones
## attack: melee | charge | ranged | explode | thief | none

const C := "res://assets/creatures/"
const TINY := "res://assets/tiny/t%03d.png"

const BIOME_SPAWNS := {
	"plains": [["bunny", 4], ["deer", 3], ["fox", 2], ["sheep", 2], ["horse", 1], ["slime", 2], ["wolf", 2], ["goblin", 1], ["bandit", 1], ["spider", 1]],
	"meadow": [["bunny", 4], ["deer", 3], ["sheep", 3], ["cow", 2], ["chicken", 2], ["horse", 1], ["slime", 1], ["goblin", 1]],
	"forest": [["deer", 3], ["boar", 3], ["wolf", 3], ["mushroom", 3], ["goblin", 2], ["goblin_archer", 1], ["spider", 2], ["owl", 1], ["bear", 1], ["snake", 1], ["treant", 1], ["bandit", 1], ["thief", 1]],
	"desert": [["scorpion", 4], ["snake2", 3], ["camel", 2], ["lion", 1], ["skeleton", 2], ["bandit", 2], ["bandit_archer", 1], ["thief", 1]],
	"snow": [["polar_bear", 2], ["yeti", 2], ["wolf", 3], ["ice_golem", 1], ["fox", 2], ["bunny", 2]],
	"swamp": [["frog", 4], ["snake", 3], ["slime", 2], ["ghost", 2], ["spider", 2], ["zombie", 2], ["evil_eye", 1]],
	"mountain": [["wolf", 3], ["golem", 2], ["goblin", 2], ["bat", 2], ["ogre", 1], ["goblin_archer", 1], ["bandit", 1]],
	"beach": [["bunny", 1], ["slime", 1], ["snake2", 1]],
	"water": [["fish", 3], ["fish2", 3]],
}
const NIGHT_EXTRA := [["skeleton", 3], ["zombie", 3], ["werewolf", 2], ["ghost", 2], ["bat", 3], ["bandit", 2], ["thief", 2]]

# Temas de mazmorra: monstruos comunes, mini jefes y jefe
const THEMES := {
	"cave": {"style": "caves", "mobs": ["bat", "spider", "slime", "goblin", "mushroom", "goblin_archer"], "minis": ["troll", "ogre"], "boss": "boss_troll"},
	"crypt": {"style": "rooms", "mobs": ["skeleton", "skeleton_archer", "ghost", "zombie", "bat"], "minis": ["vampire", "knight"], "boss": "boss_vampire"},
	"mine": {"style": "caves", "mobs": ["golem", "scorpion", "goblin", "bat", "slime_fire"], "minis": ["ogre", "golem"], "boss": "boss_golem"},
	"ruins": {"style": "rooms", "mobs": ["cultist", "imp", "knight", "evil_eye", "wisp"], "minis": ["vampire", "blood"], "boss": "boss_dragon"},
	"nest": {"style": "caves", "mobs": ["spider", "snake", "slime", "bat"], "minis": ["ogre", "troll"], "boss": "boss_spider"},
	"ice": {"style": "caves", "mobs": ["yeti", "ice_golem", "wolf", "bat", "wisp"], "minis": ["polar_bear", "ogre"], "boss": "boss_yeti"},
	"bog": {"style": "caves", "mobs": ["frog", "snake", "ghost", "zombie", "evil_eye"], "minis": ["treant", "troll"], "boss": "boss_hydra"},
	"grove": {"style": "caves", "mobs": ["mushroom", "treant_sprout", "wolf", "spider", "goblin"], "minis": ["treant", "bear"], "boss": "boss_treant"},
	"lair": {"style": "rooms", "mobs": ["goblin", "goblin_archer", "orc", "bandit", "thief"], "minis": ["ogre", "bandit_chief"], "boss": "boss_lich"},
}
const THEME_IDS := ["cave", "crypt", "mine", "ruins", "nest", "ice", "bog", "grove", "lair"]


static func strip(file: String, fw: int, fh: int, n: int, fps: float, loop: bool = true) -> Dictionary:
	return {"tex": C + file, "fw": fw, "fh": fh, "row": 0, "n": n, "fps": fps, "loop": loop}


static func row(file: String, row_i: int, n: int, fps: float, loop: bool = true) -> Dictionary:
	return {"tex": C + file, "fw": 32, "fh": 32, "row": row_i, "n": n, "fps": fps, "loop": loop}


static func _legacy(d: Dictionary) -> Dictionary:
	var base := {"habitat": "land", "abilities": [], "xp": 1.0}
	for k in d.keys():
		base[k] = d[k]
	return base


static func _tiny(tile: int, scl: float, hp: float, spd: float, dmg: float, beh: String, atk: String, extra: Dictionary) -> Dictionary:
	var d := {"tiny": tile, "scale": scl, "hp": hp, "speed": spd, "dmg": dmg, "behavior": beh, "attack": atk,
		"sight": 90.0, "range": 8.0 + scl * 6.0, "habitat": "land", "radius": 3.0 + scl * 2.0, "height": 14.0,
		"drops": {}, "abilities": [], "xp": hp / 12.0}
	if atk == "ranged":
		d["range"] = 90.0
	for k in extra.keys():
		d[k] = extra[k]
	return d


static func _human(skin: int, atk: String, hp: float, spd: float, dmg: float, extra: Dictionary) -> Dictionary:
	var d := {"human": skin, "scale": 1.0, "hp": hp, "speed": spd, "dmg": dmg, "behavior": "hostile", "attack": atk,
		"sight": 110.0, "range": 16.0, "habitat": "land", "radius": 5.0, "height": 19.0, "drops": {}, "abilities": [], "xp": hp / 10.0}
	if atk == "ranged":
		d["range"] = 100.0
	if atk == "thief":
		d["range"] = 12.0
	for k in extra.keys():
		d[k] = extra[k]
	if d.has("behavior_override"):
		d["behavior"] = d["behavior_override"]
	return d


static func get_species(id: String) -> Dictionary:
	match id:

		"mushroom":
			return _legacy({"hp": 22.0, "speed": 36.0, "dmg": 6.0, "behavior": "hostile", "attack": "melee", "sight": 90.0, "range": 18.0,
				"foot": Vector2(40, 63), "height": 33.0, "scale": 1.0, "drops": {"gold": 3, "herb": 0.2}, "radius": 6.0,
				"anims": {"idle": strip("mushroom_idle.png", 80, 64, 7, 8.0), "move": strip("mushroom_run.png", 80, 64, 8, 12.0),
					"attack": strip("mushroom_attack.png", 80, 64, 10, 14.0, false), "hit": strip("mushroom_hit.png", 80, 64, 5, 14.0, false),
					"die": strip("mushroom_die.png", 80, 64, 15, 14.0, false)}})
		"wolf":
			return _legacy({"hp": 30.0, "speed": 62.0, "dmg": 8.0, "behavior": "hostile", "attack": "charge", "sight": 110.0, "range": 16.0,
				"foot": Vector2(16, 31), "height": 12.0, "scale": 1.0, "drops": {"meat": 0.5, "gold": 3}, "radius": 6.0,
				"anims": {"idle": row("wolf.png", 0, 4, 6.0), "move": row("wolf.png", 1, 6, 12.0)}})
		"boar":
			return _legacy({"hp": 38.0, "speed": 50.0, "dmg": 10.0, "behavior": "territorial", "attack": "charge", "sight": 70.0, "range": 16.0,
				"foot": Vector2(16, 31), "height": 11.0, "scale": 1.0, "drops": {"meat": 0.8, "gold": 2}, "radius": 6.0,
				"anims": {"idle": row("boar.png", 0, 4, 6.0), "move": row("boar.png", 1, 4, 10.0)}})
		"fox":
			return _legacy({"hp": 12.0, "speed": 72.0, "dmg": 0.0, "behavior": "passive", "attack": "none", "sight": 70.0, "range": 0.0,
				"foot": Vector2(16, 31), "height": 12.0, "scale": 1.0, "drops": {"meat": 0.3}, "radius": 5.0,
				"anims": {"idle": row("fox.png", 0, 4, 6.0), "move": row("fox.png", 1, 4, 12.0)}})
		"deer":
			return _legacy({"hp": 20.0, "speed": 66.0, "dmg": 0.0, "behavior": "passive", "attack": "none", "sight": 80.0, "range": 0.0,
				"foot": Vector2(16, 31), "height": 15.0, "scale": 1.0, "drops": {"meat": 0.9}, "radius": 5.0,
				"anims": {"idle": row("deer1.png", 0, 4, 6.0), "move": row("deer1.png", 1, 4, 10.0)}})
		"bunny":
			return _legacy({"hp": 6.0, "speed": 56.0, "dmg": 0.0, "behavior": "passive", "attack": "none", "sight": 60.0, "range": 0.0,
				"foot": Vector2(16, 31), "height": 9.0, "scale": 1.0, "drops": {"meat": 0.4}, "radius": 4.0,
				"anims": {"idle": row("bunny.png", 0, 4, 6.0), "move": row("bunny.png", 1, 4, 10.0)}})
		"blood":
			return _legacy({"hp": 140.0, "speed": 40.0, "dmg": 14.0, "behavior": "hostile", "attack": "melee", "sight": 150.0, "range": 26.0,
				"foot": Vector2(52, 58), "height": 16.0, "scale": 2.0, "drops": {"gold": 40, "potion_hp": 1.0, "gem": 0.5}, "radius": 12.0, "mini_boss": true,
				"anims": {"idle": strip("blood_idle.png", 100, 100, 6, 8.0), "move": strip("blood_walk.png", 100, 100, 8, 10.0),
					"attack": strip("blood_attack.png", 100, 100, 8, 12.0, false), "hit": strip("blood_hurt.png", 100, 100, 4, 12.0, false),
					"die": strip("blood_death.png", 100, 100, 4, 8.0, false)}})
		"demon":
			return _legacy({"hp": 480.0, "speed": 46.0, "dmg": 22.0, "behavior": "hostile", "attack": "melee", "sight": 400.0, "range": 30.0,
				"foot": Vector2(53, 59), "height": 21.0, "scale": 3.0, "drops": {"gold": 400, "sword2": 1.0, "gem": 1.0}, "radius": 15.0, "boss": true,
				"abilities": ["slam", "summon:mushroom", "volley"],
				"anims": {"idle": strip("demon_idle.png", 100, 100, 6, 8.0), "move": strip("demon_walk.png", 100, 100, 8, 10.0),
					"attack": strip("demon_attack.png", 100, 100, 7, 12.0, false), "hit": strip("demon_hurt.png", 100, 100, 4, 12.0, false),
					"die": strip("demon_death.png", 100, 100, 4, 8.0, false)}})
		"chicken":
			return _tiny(151, 1.5, 6.0, 40.0, 0.0, "passive", "none", {"drops": {"meat": 0.3}, "domestic": true})
		"cow":
			return _tiny(152, 2.0, 30.0, 24.0, 0.0, "passive", "none", {"drops": {"meat": 0.9}, "domestic": true})
		"sheep":
			return _tiny(154, 1.8, 20.0, 28.0, 0.0, "passive", "none", {"drops": {"meat": 0.6}, "domestic": true})
		"goat":
			return _tiny(153, 1.8, 18.0, 34.0, 0.0, "passive", "none", {"drops": {"meat": 0.5}, "domestic": true})
		"horse":
			return _tiny(51, 2.2, 35.0, 62.0, 0.0, "passive", "none", {"drops": {"meat": 0.5}})
		"camel":
			return _tiny(130, 2.2, 38.0, 34.0, 0.0, "passive", "none", {"drops": {"meat": 0.7}})
		"owl":
			return _tiny(118, 1.4, 8.0, 50.0, 0.0, "passive", "none", {"habitat": "air", "drops": {}})
		"fish":
			return _tiny(63, 1.2, 4.0, 34.0, 0.0, "passive", "none", {"habitat": "water", "drops": {"fish": 1.0}})
		"fish2":
			return _tiny(61, 1.2, 4.0, 40.0, 0.0, "passive", "none", {"habitat": "water", "drops": {"fish": 1.0}})
		"bear":
			return _tiny(164, 2.4, 85.0, 38.0, 14.0, "territorial", "charge", {"drops": {"meat": 0.9, "gold": 8}, "sight": 80.0})
		"polar_bear":
			return _tiny(165, 2.4, 95.0, 38.0, 15.0, "territorial", "charge", {"drops": {"meat": 0.9, "gold": 10}, "sight": 80.0})
		"lion":
			return _tiny(157, 2.0, 55.0, 56.0, 13.0, "hostile", "charge", {"drops": {"meat": 0.7, "gold": 8}, "sight": 110.0})
		"slime":
			return _tiny(82, 2.0, 26.0, 26.0, 6.0, "hostile", "melee", {"drops": {"gold": 3}, "split": "slime_small"})
		"slime_small":
			return _tiny(83, 1.5, 8.0, 34.0, 3.0, "hostile", "melee", {"drops": {"gold": 1}})
		"slime_fire":
			return _tiny(84, 2.0, 18.0, 38.0, 14.0, "hostile", "explode", {"drops": {"gold": 4}})
		"bat":
			return _tiny(138, 1.5, 8.0, 74.0, 4.0, "hostile", "melee", {"habitat": "air", "erratic": true, "drops": {"gold": 2}, "sight": 100.0})
		"spider":
			return _tiny(40, 1.8, 22.0, 52.0, 6.0, "hostile", "melee", {"drops": {"gold": 4}, "poison": true})
		"scorpion":
			return _tiny(146, 1.8, 24.0, 44.0, 8.0, "hostile", "melee", {"drops": {"gold": 4}, "poison": true})
		"snake":
			return _tiny(41, 1.6, 14.0, 46.0, 5.0, "hostile", "melee", {"drops": {"gold": 2}, "poison": true})
		"snake2":
			return _tiny(42, 1.6, 14.0, 46.0, 5.0, "hostile", "melee", {"drops": {"gold": 2}, "poison": true})
		"frog":
			return _tiny(147, 1.4, 10.0, 40.0, 3.0, "hostile", "melee", {"drops": {"gold": 1}, "sight": 60.0})
		"goblin":
			return _tiny(125, 1.7, 28.0, 50.0, 7.0, "hostile", "melee", {"drops": {"gold": 6, "wood": 0.2}})
		"goblin_archer":
			return _tiny(12, 1.7, 22.0, 40.0, 6.0, "hostile", "ranged", {"drops": {"gold": 6, "arrow": 0.5}})
		"orc":
			return _tiny(43, 2.1, 60.0, 40.0, 12.0, "hostile", "melee", {"drops": {"gold": 10, "meat": 0.2}})
		"ogre":
			return _tiny(126, 2.5, 100.0, 34.0, 16.0, "hostile", "charge", {"drops": {"gold": 18, "gem": 0.2}})
		"troll":
			return _tiny(99, 3.0, 170.0, 32.0, 18.0, "hostile", "melee", {"mini_boss": true, "drops": {"gold": 40, "gem": 0.6, "potion_hp": 0.6}})
		"skeleton":
			return _tiny(2, 1.8, 30.0, 40.0, 9.0, "hostile", "melee", {"drops": {"gold": 5, "stone": 0.2}})
		"skeleton_archer":
			return _tiny(96, 1.8, 22.0, 34.0, 7.0, "hostile", "ranged", {"drops": {"gold": 6, "arrow": 0.6}})
		"zombie":
			return _tiny(26, 1.8, 45.0, 22.0, 10.0, "hostile", "melee", {"drops": {"gold": 5}})
		"ghost":
			return _tiny(87, 1.8, 22.0, 44.0, 8.0, "hostile", "melee", {"habitat": "air", "drops": {"gold": 6, "gem": 0.1}})
		"wisp":
			return _tiny(56, 1.5, 10.0, 48.0, 7.0, "hostile", "ranged", {"habitat": "air", "drops": {"gold": 4}, "bolt": "fire"})
		"imp":
			return _tiny(103, 1.7, 24.0, 56.0, 7.0, "hostile", "ranged", {"drops": {"gold": 7}, "bolt": "fire"})
		"evil_eye":
			return _tiny(6, 2.0, 24.0, 30.0, 8.0, "hostile", "ranged", {"habitat": "air", "drops": {"gold": 8, "gem": 0.1}, "bolt": "shadow"})
		"cultist":
			return _tiny(20, 1.8, 32.0, 34.0, 9.0, "hostile", "ranged", {"drops": {"gold": 10, "scroll": 0.15}, "bolt": "shadow"})
		"vampire":
			return _tiny(3, 2.2, 130.0, 52.0, 14.0, "hostile", "charge", {"mini_boss": true, "drops": {"gold": 50, "gem": 0.6, "ring": 0.3}})
		"golem":
			return _tiny(48, 2.3, 95.0, 26.0, 16.0, "hostile", "melee", {"drops": {"gold": 14, "stone": 0.8, "gem": 0.3}})
		"ice_golem":
			return _tiny(50, 2.3, 95.0, 26.0, 16.0, "hostile", "melee", {"drops": {"gold": 14, "gem": 0.4}})
		"yeti":
			return _tiny(44, 2.3, 85.0, 38.0, 14.0, "hostile", "charge", {"drops": {"gold": 14, "meat": 0.4}})
		"treant":
			return _tiny(114, 2.6, 125.0, 22.0, 16.0, "hostile", "melee", {"mini_boss": true, "drops": {"gold": 40, "wood": 1.0, "gem": 0.5}})
		"werewolf":
			return _tiny(24, 1.9, 60.0, 64.0, 12.0, "hostile", "charge", {"drops": {"gold": 12, "meat": 0.4}})
		"fire_elemental":
			return _tiny(46, 2.0, 50.0, 40.0, 12.0, "hostile", "melee", {"drops": {"gold": 9, "gem": 0.3}})
		"knight":
			return _tiny(17, 1.9, 75.0, 36.0, 13.0, "hostile", "melee", {"drops": {"gold": 14, "armor": 0.05}})
		"boss_troll":
			return _tiny(99, 5.0, 420.0, 34.0, 22.0, "hostile", "melee", {"boss": true, "abilities": ["slam", "summon:goblin"], "drops": {"gold": 220, "gem": 1.0, "armor2": 0.4}})
		"boss_vampire":
			return _tiny(3, 4.5, 380.0, 56.0, 18.0, "hostile", "charge", {"boss": true, "abilities": ["volley", "summon:bat"], "drops": {"gold": 250, "gem": 1.0, "amulet": 0.6}})
		"boss_golem":
			return _tiny(129, 5.0, 520.0, 24.0, 24.0, "hostile", "melee", {"boss": true, "abilities": ["slam"], "drops": {"gold": 260, "gem": 1.0, "helm2": 0.5}})
		"boss_spider":
			return _tiny(40, 6.0, 360.0, 56.0, 16.0, "hostile", "charge", {"boss": true, "abilities": ["summon:spider", "volley"], "drops": {"gold": 220, "gem": 1.0}, "poison": true})
		"boss_hydra":
			return _tiny(122, 5.0, 450.0, 30.0, 18.0, "hostile", "melee", {"boss": true, "abilities": ["volley", "slam"], "drops": {"gold": 240, "gem": 1.0, "ring": 0.5}})
		"boss_treant":
			return _tiny(116, 5.5, 480.0, 22.0, 22.0, "hostile", "melee", {"boss": true, "abilities": ["slam", "summon:treant_sprout"], "drops": {"gold": 230, "wood": 3.0, "gem": 1.0}})
		"boss_yeti":
			return _tiny(44, 5.0, 440.0, 40.0, 20.0, "hostile", "charge", {"boss": true, "abilities": ["slam", "volley"], "drops": {"gold": 240, "gem": 1.0, "boots": 0.5}})
		"boss_lich":
			return _tiny(5, 4.5, 400.0, 36.0, 18.0, "hostile", "ranged", {"boss": true, "abilities": ["volley", "summon:skeleton"], "drops": {"gold": 280, "gem": 1.0, "scroll": 1.0}})
		"boss_dragon":
			return _tiny(111, 5.0, 600.0, 40.0, 24.0, "hostile", "charge", {"boss": true, "abilities": ["volley", "slam"], "drops": {"gold": 320, "gem": 2.0, "armor2": 0.5}})
		"treant_sprout":
			return _tiny(115, 1.6, 30.0, 34.0, 8.0, "hostile", "melee", {"drops": {"wood": 0.5}})
		"bandit":
			return _human(8, "melee", 45.0, 48.0, 9.0, {"drops": {"gold": 14, "bread": 0.3}, "sight": 110.0})
		"bandit_archer":
			return _human(24, "ranged", 34.0, 40.0, 8.0, {"drops": {"gold": 14, "arrow": 0.7}, "sight": 140.0})
		"thief":
			return _human(20, "thief", 30.0, 70.0, 0.0, {"drops": {"gold": 6}, "sight": 130.0})
		"bandit_chief":
			return _human(23, "charge", 150.0, 52.0, 16.0, {"mini_boss": true, "drops": {"gold": 90, "gem": 0.6, "sword2": 0.3}, "sight": 140.0})
		"guard":
			return _human(23, "melee", 90.0, 52.0, 12.0, {"behavior_override": "guard", "drops": {}, "sight": 120.0})
	return {}
