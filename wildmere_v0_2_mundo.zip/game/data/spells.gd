extends RefCounted
## Hechizos con rango (1 Aprendiz ... 5 Santo). Se aprenden con un maestro de magia (cuesta oro).

const RANK_NAMES := ["rank_0", "rank_1", "rank_2", "rank_3", "rank_4", "rank_5"]
const RANK_XP := [0.0, 0.0, 60.0, 220.0, 650.0, 1600.0]       # xp necesaria para aspirar a cada rango
const RANK_GOLD := [0, 0, 120, 350, 900, 2400]                # coste de la prueba de rango
const SPELLS := {
	"fireball": {"rank": 1, "learn": 60, "mana": 8.0, "dmg": 18.0, "cooldown": 0.7, "kind": "projectile", "radius": 26.0, "icon": "sp_fire", "fx": "fireball_impact"},
	"ice": {"rank": 2, "learn": 150, "mana": 14.0, "dmg": 26.0, "cooldown": 1.2, "kind": "ground", "radius": 24.0, "range": 44.0, "icon": "sp_ice", "fx": "ice_spike"},
	"heal": {"rank": 2, "learn": 120, "mana": 16.0, "heal": 35.0, "cooldown": 1.5, "kind": "self", "icon": "sp_heal", "fx": "holy_heal"},
	"bolt": {"rank": 3, "learn": 400, "mana": 24.0, "dmg": 30.0, "cooldown": 1.4, "kind": "chain", "radius": 110.0, "icon": "sp_bolt", "fx": "lightning_strike"},
	"meteor": {"rank": 4, "learn": 1000, "mana": 45.0, "dmg": 80.0, "cooldown": 3.0, "kind": "meteor", "radius": 44.0, "range": 80.0, "icon": "sp_meteor", "fx": "meteor_strike"},
	"smite": {"rank": 5, "learn": 2500, "mana": 70.0, "dmg": 70.0, "heal": 25.0, "cooldown": 4.0, "kind": "nova", "radius": 80.0, "icon": "sp_smite", "fx": "holy_smite"},
}
const ORDER := ["fireball", "ice", "heal", "bolt", "meteor", "smite"]


static func icon_path(id: String) -> String:
	return "res://assets/items/%s.png" % str(SPELLS[id]["icon"])
