extends RefCounted
## Identificadores de tiles. El orden coincide con las filas de assets/tiles/wild_tiles.png (4 variantes por fila).

const DEEP := 0
const WATER := 1       # agua poco profunda: se puede cruzar (mas lento)
const SAND := 2
const GRASS := 3
const FOREST := 4
const DESERT := 5
const STONE := 6       # pared de montana: solida (se sube por senderos)
const GRAVEL := 7
const PATH := 8
const DFLOOR := 9
const DWALL := 10
const BFLOOR := 11
const LAVA := 12
const STAIRS := 13
const SNOW := 14
const SWAMP := 15
const MEADOW := 16
const TRAIL := 17      # sendero de montana
const PEAK := 18       # cima nevada (transitable)
const BRICK := 19      # muralla
const WOOD := 20
const INTWALL := 21
const CASTLE := 22
const CARPET := 23
const FARM := 24

const SIZE := 16
const ATLAS := "res://assets/tiles/wild_tiles.png"


static func is_solid(t: int) -> bool:
	return t == DEEP or t == STONE or t == DWALL or t == LAVA or t == BRICK or t == INTWALL


static func is_water(t: int) -> bool:
	return t == DEEP or t == WATER


static func is_wall(t: int) -> bool:
	return t == DWALL or t == BRICK or t == INTWALL


static func speed_mult(t: int) -> float:
	if t == WATER:
		return 0.6
	if t == SWAMP:
		return 0.75
	if t == SNOW:
		return 0.9
	return 1.0


static func is_land(t: int) -> bool:
	return not is_solid(t) and t != WATER and t < DFLOOR or t == SNOW or t == SWAMP or t == MEADOW or t == TRAIL or t == PEAK or t == FARM
