extends RefCounted
## Apariencias de jugador (hojas SuperRetroWorld 16x20, 3 columnas x 4 filas) y estilos iniciales.

const SKINS := [1, 2, 3, 4, 5, 7, 9, 11, 13, 16, 21, 28]
const SHEET := "res://assets/characters/char_%02d.png"
const CELL := Vector2i(16, 20)
# Filas de la hoja: abajo, izquierda, derecha, arriba (convencion RPG Maker; si alguna direccion se ve
# invertida en el juego, basta con cambiar estos numeros).
const ROW_DOWN := 0
const ROW_LEFT := 1
const ROW_RIGHT := 2
const ROW_UP := 3

const STYLES := {
	"adventurer": {"hp": 100.0, "mp": 30.0, "speed": 80.0, "rank": 0, "spells": [],
		"items": {"sword": 1, "bow": 1, "arrow": 14, "apple": 3, "bread": 1, "potion_hp": 1, "torch": 3},
		"equip": {"weapon": "sword", "ranged": "bow"}},
	"warrior": {"hp": 130.0, "mp": 20.0, "speed": 76.0, "rank": 0, "spells": [],
		"items": {"sword2": 1, "shield": 1, "armor": 1, "apple": 3, "bread": 1, "potion_hp": 2, "torch": 3},
		"equip": {"weapon": "sword2", "offhand": "shield", "body": "armor"}},
	"mage": {"hp": 80.0, "mp": 70.0, "speed": 80.0, "rank": 1, "spells": ["fireball"],
		"items": {"staff": 1, "hat": 1, "apple": 3, "bread": 1, "potion_mp": 3, "potion_hp": 1, "torch": 3},
		"equip": {"weapon": "staff", "head": "hat"}},
	"archer": {"hp": 90.0, "mp": 30.0, "speed": 90.0, "rank": 0, "spells": [],
		"items": {"dagger": 1, "bow": 1, "arrow": 40, "apple": 3, "bread": 1, "potion_hp": 1, "torch": 3, "boots": 1},
		"equip": {"weapon": "dagger", "ranged": "bow", "feet": "boots"}},
}
const STYLE_IDS := ["adventurer", "warrior", "mage", "archer"]
