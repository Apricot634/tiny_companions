extends RefCounted
## Objetos. Nombres en Loc ("item_<id>"). slot: weapon, offhand, ranged, head, body, feet.
## price = precio de compra base; se vende al 40%.

const ICON := "res://assets/items/%s.png"
const SLOTS := ["head", "body", "feet", "weapon", "offhand", "ranged"]
const ITEMS := {
	"sword": {"kind": "equip", "slot": "weapon", "dmg": 10.0, "icon": "sword", "price": 60},
	"sword2": {"kind": "equip", "slot": "weapon", "dmg": 17.0, "icon": "sword2", "price": 200},
	"dagger": {"kind": "equip", "slot": "weapon", "dmg": 7.0, "icon": "dagger", "price": 30, "fast": true},
	"axe": {"kind": "equip", "slot": "weapon", "dmg": 14.0, "icon": "axe", "price": 130, "chop": 2.0},
	"spear": {"kind": "equip", "slot": "weapon", "dmg": 13.0, "icon": "spear", "price": 110, "reach": 40.0},
	"staff": {"kind": "equip", "slot": "weapon", "dmg": 5.0, "icon": "staff", "price": 90, "spell_bonus": 1.5},
	"shield": {"kind": "equip", "slot": "offhand", "def": 0.0, "icon": "shield", "price": 70},
	"bow": {"kind": "equip", "slot": "ranged", "icon": "bow", "price": 90},
	"hat": {"kind": "equip", "slot": "head", "def": 1.0, "icon": "hat", "price": 60, "spell_bonus": 1.2},
	"helm": {"kind": "equip", "slot": "head", "def": 2.0, "icon": "helm", "price": 80},
	"helm2": {"kind": "equip", "slot": "head", "def": 3.0, "icon": "helm2", "price": 170},
	"armor": {"kind": "equip", "slot": "body", "def": 3.0, "icon": "armor", "price": 130},
	"armor2": {"kind": "equip", "slot": "body", "def": 5.0, "icon": "armor2", "price": 280},
	"boots": {"kind": "equip", "slot": "feet", "def": 1.0, "icon": "boots", "price": 50, "speed": 6.0},
	"arrow": {"kind": "ammo", "icon": "arrow", "icon_path": "res://assets/props/arrow.png", "price": 2},
	"torch": {"kind": "tool", "icon": "torch", "price": 6},
	"potion_hp": {"kind": "consumable", "heal": 50.0, "icon": "potion_hp", "price": 30},
	"potion_mp": {"kind": "consumable", "mana": 45.0, "icon": "potion_mp", "price": 35},
	"apple": {"kind": "consumable", "food": 22.0, "heal": 6.0, "icon": "apple", "price": 3},
	"bread": {"kind": "consumable", "food": 38.0, "heal": 8.0, "icon": "bread", "price": 6},
	"meat": {"kind": "consumable", "food": 45.0, "heal": 10.0, "icon": "meat", "price": 8},
	"fish": {"kind": "consumable", "food": 30.0, "heal": 8.0, "icon": "fish", "price": 5},
	"wood": {"kind": "material", "icon": "wood", "price": 2},
	"stone": {"kind": "material", "icon": "stone", "price": 2},
	"herb": {"kind": "material", "icon": "herb", "price": 4},
	"gem": {"kind": "material", "icon": "gem", "price": 45},
	"scroll": {"kind": "treasure", "icon": "scroll", "price": 70},
	"ring": {"kind": "treasure", "icon": "ring", "price": 150},
	"amulet": {"kind": "treasure", "icon": "amulet", "price": 220},
}
const ORDER := ["sword", "sword2", "dagger", "axe", "spear", "staff", "shield", "bow", "hat", "helm", "helm2", "armor", "armor2", "boots", "arrow", "torch",
	"potion_hp", "potion_mp", "apple", "bread", "meat", "fish", "wood", "stone", "herb", "gem", "scroll", "ring", "amulet"]

# Tiendas: tipo de tienda -> objetos a la venta
const SHOPS := {
	"shop": ["apple", "bread", "arrow", "torch", "potion_hp", "potion_mp", "dagger", "boots"],
	"smith": ["sword", "sword2", "axe", "spear", "shield", "bow", "helm", "helm2", "armor", "armor2", "arrow"],
	"hut": ["potion_hp", "potion_mp", "herb", "gem", "hat"],
	"tower": ["potion_mp", "hat", "staff", "scroll"],
}
# Fabricacion: receta -> {out, n, needs}
const RECIPES := {
	"torch": {"out": "torch", "n": 3, "needs": {"wood": 2}},
	"arrow": {"out": "arrow", "n": 8, "needs": {"wood": 1, "stone": 1}},
	"potion_hp": {"out": "potion_hp", "n": 1, "needs": {"herb": 3}, "needs_known": "alchemy"},
	"potion_mp": {"out": "potion_mp", "n": 1, "needs": {"herb": 2, "gem": 1}, "needs_known": "alchemy"},
	"bread": {"out": "bread", "n": 2, "needs": {"herb": 1, "apple": 1}},
}
const RECIPE_ORDER := ["torch", "arrow", "bread", "potion_hp", "potion_mp"]


static func icon_path(id: String) -> String:
	var it: Dictionary = ITEMS[id]
	if it.has("icon_path"):
		return str(it["icon_path"])
	return ICON % str(it["icon"])


static func slot_of(id: String) -> String:
	if ITEMS.has(id) and str(ITEMS[id]["kind"]) == "equip":
		return str(ITEMS[id]["slot"])
	return ""
