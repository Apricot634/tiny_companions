extends RefCounted
## Seleccion de dialogos: depende del rol, la reputacion, la hora y de cuantas veces hablaste con ese habitante.

const POOL := {"villager": 6, "farmer": 4, "guard": 4, "merchant": 3, "innkeeper": 3, "smith": 3, "mage": 3, "witch": 3,
	"healer": 2, "bard": 4, "elder": 3}
const HOSTILE_N := 4
const FRIEND_N := 3
const NIGHT_N := 3
const RUMOR_N := 6


## Devuelve la clave de texto (sin formato) para saludar. rep = reputacion, talks = veces que se hablo.
static func greeting_key(role: String, rep: int, night: bool, talks: int, salt: int) -> String:
	var r := RandomNumberGenerator.new()
	r.seed = salt * 31 + talks * 7 + 5
	if rep < -30:
		return "d_hostile_%d" % (r.randi() % HOSTILE_N + 1)
	if rep > 30 and r.randf() < 0.4:
		return "d_friend_%d" % (r.randi() % FRIEND_N + 1)
	if night and role in ["villager", "farmer", "bard"] and r.randf() < 0.5:
		return "d_night_%d" % (r.randi() % NIGHT_N + 1)
	var n: int = int(POOL.get(role, 6))
	return "d_%s_%d" % [role if POOL.has(role) else "villager", r.randi() % n + 1]


static func rumor_key(talks: int, salt: int) -> int:
	var r := RandomNumberGenerator.new()
	r.seed = salt * 17 + talks * 3 + 1
	return r.randi() % RUMOR_N + 1
