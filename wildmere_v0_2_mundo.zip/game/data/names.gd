extends RefCounted
## Nombres propios generados por semilla (personas y lugares).

const FIRST := ["Aldo", "Brisa", "Cleo", "Dario", "Elia", "Fidel", "Gala", "Hugo", "Irma", "Joan", "Kira", "Lino", "Mara", "Nico", "Olga", "Pablo",
	"Quino", "Rosa", "Saul", "Tina", "Ulises", "Vera", "Wilo", "Xenia", "Yago", "Zoe", "Bruno", "Dalia", "Emil", "Flor", "Gael", "Inés", "Luz", "Mateo", "Nora", "Omar"]
const LAST := ["del Roble", "Piedrafina", "Cuervo", "Valle", "Brasas", "Nieblas", "Trigal", "Arroyo", "Bosquejo", "Mielera", "Hierro", "Luna", "Cardo", "Alba", "Tormenta", "Sal"]
const PLACE_A := ["Piedra", "Roble", "Brisa", "Ceniza", "Musgo", "Alba", "Cuervo", "Trigo", "Niebla", "Lago", "Sol", "Luna", "Hierro", "Zarza", "Bruma"]
const PLACE_B := ["alta", "honda", "mar", "fría", "dorada", "vieja", "verde", "negra", "clara", "brava", "dulce", "seca"]


static func person(r: RandomNumberGenerator) -> String:
	return "%s %s" % [FIRST[r.randi() % FIRST.size()], LAST[r.randi() % LAST.size()]]


static func first_name(r: RandomNumberGenerator) -> String:
	return str(FIRST[r.randi() % FIRST.size()])


static func place(r: RandomNumberGenerator) -> String:
	return "%s%s" % [PLACE_A[r.randi() % PLACE_A.size()], PLACE_B[r.randi() % PLACE_B.size()]]
