extends Node
## Prueba automatica. Ejecutar: godot --headless --path . -- --autotest
## Imprime "AUTOTEST OK" o "AUTOTEST FAIL" y termina con codigo 0 / 1.

const SaveIO := preload("res://core/save_io.gd")
const CreditsData := preload("res://core/credits_data.gd")
const Calib := preload("res://ui/joystick_calibration.gd")
const T := preload("res://data/tiles.gd")
const Terrain := preload("res://world/terrain.gd")
const DungeonGen := preload("res://world/dungeon_gen.gd")
const InteriorGen := preload("res://world/interior_gen.gd")
const VillageGen := preload("res://world/village_gen.gd")
const Species := preload("res://data/species.gd")
const Items := preload("res://data/items.gd")
const Spells := preload("res://data/spells.gd")
const Appearances := preload("res://data/appearances.gd")
const FxData := preload("res://data/fx_data.gd")
const Dialogue := preload("res://data/dialogue.gd")
const TouchButton := preload("res://ui/touch_button.gd")

var ok := true
var _cal := {"x": false, "y": false}
var _presses := 0
var ALL_SPECIES := ["mushroom", "wolf", "boar", "fox", "deer", "bunny", "blood", "demon", "chicken", "cow", "sheep", "goat", "horse", "camel", "owl", "fish", "fish2",
	"bear", "polar_bear", "lion", "slime", "slime_small", "slime_fire", "bat", "spider", "scorpion", "snake", "snake2", "frog", "goblin", "goblin_archer", "orc", "ogre",
	"troll", "skeleton", "skeleton_archer", "zombie", "ghost", "wisp", "imp", "evil_eye", "cultist", "vampire", "golem", "ice_golem", "yeti", "treant", "treant_sprout",
	"werewolf", "fire_elemental", "knight", "boss_troll", "boss_vampire", "boss_golem", "boss_spider", "boss_hydra", "boss_treant", "boss_yeti", "boss_lich",
	"boss_dragon", "bandit", "bandit_archer", "thief", "bandit_chief", "guard"]


func _check(cond: bool, label: String) -> void:
	if cond:
		print("  ok   ", label)
	else:
		print("  FAIL ", label)
		ok = false


func run() -> void:
	await get_tree().process_frame
	_test_save_io()
	_test_loc()
	_test_assets()
	_test_terrain()
	_test_villages()
	_test_dungeons()
	_test_interiors()
	_test_game_state()
	await _test_menu()
	await _test_ui()
	await _test_world()
	print("AUTOTEST ", "OK" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)


# ------------------------------------------------------------ base
func _test_save_io() -> void:
	var p := "user://autotest_save.json"
	for suffix in ["", ".bak", ".tmp"]:
		if FileAccess.file_exists(p + suffix):
			DirAccess.remove_absolute(p + suffix)
	_check(SaveIO.write_json_atomic(p, {"v": 1}), "guardar v1")
	_check(SaveIO.write_json_atomic(p, {"v": 2}), "guardar v2 (crea copia .bak)")
	var f := FileAccess.open(p, FileAccess.WRITE)
	f.store_string("{esto no es json")
	f.close()
	_check(int(SaveIO.read_json_safe(p).get("v", 0)) == 1, "archivo danado -> recupera copia .bak")


func _scan_loc_keys(dir_path: String, found: Dictionary) -> void:
	var d := DirAccess.open(dir_path)
	if d == null:
		return
	for sub in d.get_directories():
		if sub.begins_with(".") or sub == "assets" or sub == "tests":
			continue
		_scan_loc_keys(dir_path.path_join(sub), found)
	for f in d.get_files():
		if f.ends_with(".gd"):
			var txt := FileAccess.get_file_as_string(dir_path.path_join(f))
			for pat in ["Loc\\.t\\(\"([a-z_0-9]+)\"\\)", "toast\\(\"([a-z_0-9]+)\"\\)", "big_message\\(\"([a-z_0-9]+)\"\\)"]:
				var rx := RegEx.new()
				rx.compile(pat)
				for m in rx.search_all(txt):
					found[m.get_string(1)] = true


func _test_loc() -> void:
	var all_ok := true
	for key in Loc.T.keys():
		for l in Loc.LANGS:
			if str(Loc.T[key].get(l, "")) == "":
				print("  falta traduccion: ", key, " ", l)
				all_ok = false
	_check(all_ok, "todas las claves tienen es/en/fr")
	var found := {}
	_scan_loc_keys("res://", found)
	for id in Items.ITEMS.keys():
		found["item_" + str(id)] = true
	for id in Spells.SPELLS.keys():
		found["spell_" + str(id)] = true
	for i in 6:
		found["rank_%d" % i] = true
	for id in ALL_SPECIES:
		found["sp_" + id] = true
	for id in Appearances.STYLE_IDS:
		found["style_" + str(id)] = true
		found["style_%s_desc" % str(id)] = true
	for r in Dialogue.POOL.keys():
		for i in range(1, int(Dialogue.POOL[r]) + 1):
			found["d_%s_%d" % [r, i]] = true
	for i in range(1, Dialogue.HOSTILE_N + 1):
		found["d_hostile_%d" % i] = true
	for i in range(1, Dialogue.FRIEND_N + 1):
		found["d_friend_%d" % i] = true
	for i in range(1, Dialogue.NIGHT_N + 1):
		found["d_night_%d" % i] = true
	for i in range(1, Dialogue.RUMOR_N + 1):
		found["rumor_%d" % i] = true
	for b in ["plains", "meadow", "forest", "desert", "snow", "swamp", "mountain", "beach", "water", "village"]:
		found["biome_" + b] = true
	for k in ["house", "shop", "inn", "smith", "tower", "hut"]:
		found["place_" + k] = true
	for k in ["villager", "farmer", "guard", "merchant", "innkeeper", "smith", "mage", "witch", "elder", "healer", "bard"]:
		found["role_" + k] = true
	for d in VillageGen.NPC_SKINS:
		pass
	var missing: Array = []
	for k in found.keys():
		if not Loc.T.has(str(k)):
			missing.append(k)
	if not missing.is_empty():
		print("  claves de texto sin definir: ", missing)
	_check(missing.is_empty(), "todo texto usado esta definido (%d claves)" % found.size())
	for l in Loc.LANGS:
		Loc.set_language(l)
	Loc.set_language("es")


func _test_assets() -> void:
	var bad: Array = []
	for sid in ALL_SPECIES:
		var data := Species.get_species(sid)
		if data.is_empty():
			bad.append(sid)
			continue
		if data.has("tiny"):
			if not ResourceLoader.exists(Species.TINY % int(data["tiny"])):
				bad.append("tiny %d (%s)" % [int(data["tiny"]), sid])
		elif data.has("human"):
			if not ResourceLoader.exists(Appearances.SHEET % int(data["human"])):
				bad.append("humano %d" % int(data["human"]))
		else:
			for an in data["anims"].keys():
				var a: Dictionary = data["anims"][an]
				if not ResourceLoader.exists(str(a["tex"])):
					bad.append(str(a["tex"]))
					continue
				var tex: Texture2D = load(str(a["tex"]))
				if tex.get_width() < int(a["n"]) * int(a["fw"]) or tex.get_height() < (int(a["row"]) + 1) * int(a["fh"]):
					bad.append("%s %s fuera de la hoja" % [sid, an])
	_check(bad.is_empty(), "%d especies: texturas validas" % ALL_SPECIES.size())
	if not bad.is_empty():
		print("  ", bad)
	var bad2: Array = []
	for id in Items.ITEMS.keys():
		if not ResourceLoader.exists(Items.icon_path(str(id))):
			bad2.append("item " + str(id))
	for sid in Spells.SPELLS.keys():
		if not ResourceLoader.exists(Spells.icon_path(str(sid))):
			bad2.append("hechizo " + str(sid))
	for fx in FxData.FX.keys():
		if not ResourceLoader.exists("res://assets/fx/%s.png" % fx):
			bad2.append("fx " + str(fx))
	for s in Appearances.SKINS:
		if not ResourceLoader.exists(Appearances.SHEET % s):
			bad2.append("skin %d" % s)
	for s in VillageGen.NPC_SKINS:
		if not ResourceLoader.exists(Appearances.SHEET % int(s)):
			bad2.append("skin npc %d" % int(s))
	for t in ["oak1", "oak2", "oak3", "moss", "moss2", "autumn", "autumn2", "snow1", "snow2", "snow3", "palm1", "palm2", "burned", "broken", "broken2", "flower", "fruit"]:
		if not ResourceLoader.exists("res://assets/trees/%s.png" % t):
			bad2.append("arbol " + t)
	for f in ["house1", "house2", "house3", "house1_coin", "house2_bed", "house3_anvil", "hut", "wizard_tower", "castle_tower", "well", "stall", "haystack", "tent", "campfire"]:
		if not ResourceLoader.exists("res://assets/buildings/%s.png" % f):
			bad2.append("edificio " + f)
	for f in ["bed", "bed_blue", "table", "chair", "bookshelf", "shelf_goods", "counter", "barrel", "crate", "stove", "cauldron", "anvil", "forge", "rack", "plant", "fireplace", "desk", "herb_shelf"]:
		if not ResourceLoader.exists("res://assets/furniture/%s.png" % f):
			bad2.append("mueble " + f)
	for f in ["rubble", "bones", "pillar", "grave", "glow_crystal", "torch", "stump", "herb_patch", "rock", "cactus", "chest", "cave", "boss_gate", "crystal", "arrow"]:
		if not ResourceLoader.exists("res://assets/props/%s.png" % f):
			bad2.append("prop " + f)
	for i in 3:
		if not ResourceLoader.exists("res://assets/peaks/peak%d.png" % (i + 1)):
			bad2.append("pico %d" % i)
	_check(bad2.is_empty(), "iconos, efectos, arboles, edificios y muebles existen")
	if not bad2.is_empty():
		print("  ", bad2)
	var tiles_tex: Texture2D = load(T.ATLAS)
	_check(tiles_tex.get_height() >= 25 * 16 and tiles_tex.get_width() >= 64, "atlas de terreno: 25 filas x 4 variantes")


# ------------------------------------------------------------ mundo
func _sample_stats(seed_value: int) -> Dictionary:
	var ter := Terrain.new(seed_value)
	var counts := {}
	var total := 0
	var sig := 0
	for y in range(-200, 201, 5):
		for x in range(-200, 201, 5):
			var t := ter.tile_at(x, y)
			counts[t] = int(counts.get(t, 0)) + 1
			total += 1
			sig = (sig * 31 + t) % 1000000007
	counts["total"] = total
	counts["sig"] = sig
	return counts


func _test_terrain() -> void:
	var a := _sample_stats(12345)
	var a2 := _sample_stats(12345)
	var b := _sample_stats(98765)
	_check(int(a["sig"]) == int(a2["sig"]), "misma semilla = mismo terreno")
	_check(int(a["sig"]) != int(b["sig"]), "semillas distintas = terreno distinto")
	for st in [a, b]:
		var total: float = float(st["total"])
		var kinds := 0
		var names := ""
		for t in range(0, 25):
			if int(st.get(t, 0)) > 0:
				kinds += 1
				names += "%d:%.0f%% " % [t, float(st.get(t, 0)) / total * 100.0]
		print("  info  ", names)
		var water: float = (float(st.get(T.DEEP, 0)) + float(st.get(T.WATER, 0))) / total
		_check(water > 0.02 and water < 0.8, "agua razonable (%.0f%%)" % (water * 100.0))
		_check(kinds >= 7, "variedad de biomas: %d tipos de terreno" % kinds)
	var ter := Terrain.new(777)
	_check(not T.is_solid(ter.tile_at(0, 0)) and not T.is_solid(ter.tile_at(4, 4)), "la zona de inicio es transitable")
	var g := ter.boss_gate_tile()
	_check(not T.is_solid(ter.tile_at(g.x, g.y)) and Vector2(g.x, g.y).length() > 60.0, "puerta del jefe en tierra firme y lejos")
	_check(ter.boss_gate_tile() != Terrain.new(778).boss_gate_tile(), "la puerta del jefe cambia entre mundos")
	var creatures := 0
	var kinds_found := {}
	for cx in range(-6, 7):
		for cy in range(-6, 7):
			for c in ter.chunk_creatures(cx, cy):
				creatures += 1
				kinds_found[str(c["species"])] = true
	_check(creatures > 40 and kinds_found.size() >= 8, "vida: %d criaturas de %d especies en 169 chunks" % [creatures, kinds_found.size()])
	var objs := {}
	for cx in range(-5, 6):
		for cy in range(-5, 6):
			for o in ter.chunk_objects(cx, cy):
				objs[str(o["type"])] = true
	_check(objs.has("tree") and objs.has("building") and objs.has("npc"), "objetos: arboles, edificios y habitantes (%s)" % str(objs.keys()))
	# montanas con senderos
	var trails := 0
	var stones := 0
	for y in range(-300, 301, 3):
		for x in range(-300, 301, 3):
			var t := ter.tile_at(x, y)
			if t == T.TRAIL:
				trails += 1
			if t == T.STONE:
				stones += 1
	_check(stones > 0 and trails > 0, "montanas: %d paredes y %d tiles de sendero" % [stones, trails])


func _test_villages() -> void:
	var seen := {}
	for k in VillageGen.KINDS:
		var v := VillageGen.build(100, 100, "v_test_" + k, 4242, k)
		seen[k] = v["buildings"].size()
		_check(v["buildings"].size() >= 4 and v["npcs"].size() >= 3 and not v["tiles"].is_empty(), "aldea '%s': %d edificios, %d habitantes" % [k, v["buildings"].size(), v["npcs"].size()])
		var has_shop := false
		for b in v["buildings"]:
			if str(b["type"]) == "shop":
				has_shop = true
		_check(has_shop, "aldea '%s' tiene tienda" % k)
	var v1 := VillageGen.build(0, 0, "a", 1)
	var v2 := VillageGen.build(0, 0, "b", 2)
	var names := {}
	for s in range(30):
		names[str(VillageGen.build(0, 0, "x", s)["name"])] = true
	_check(names.size() > 10, "nombres de aldea variados (%d distintos)" % names.size())
	_check(str(v1["name"]) != "" and v1["npcs"].size() > 0, "aldea generada con nombre y habitantes")
	var npc_names := {}
	for n in VillageGen.build(0, 0, "n", 9)["npcs"]:
		npc_names[str(n["name"])] = true
	_check(npc_names.size() >= 4, "habitantes con nombres distintos")


func _test_dungeons() -> void:
	for theme in Species.THEME_IDS:
		var d := DungeonGen.new()
		d.generate(111, "%s@t" % theme, str(theme), 1.0)
		var good: bool = d.reachable(d.start, d.exit_tile) and d.reachable(d.start, d.boss_spawn)
		var c0: Dictionary = d.chests[0]
		good = good and d.reachable(d.start, Vector2i(int(c0["tx"]), int(c0["ty"])))
		_check(good and d.floor_cells.size() > 600 and d.spawns.size() > 5 and d.chests.size() >= 2, "mazmorra '%s': %d suelos, %d enemigos, %d cofres, accesible" % [theme, d.floor_cells.size(), d.spawns.size(), d.chests.size()])
	var d1 := DungeonGen.new()
	d1.generate(1, "cave@a", "cave", 1.0)
	var d2 := DungeonGen.new()
	d2.generate(2, "cave@a", "cave", 1.0)
	_check(d1.tiles != d2.tiles, "mazmorras: semillas distintas = mapas distintos")
	var b1 := DungeonGen.new()
	b1.boss_arena()
	var b2 := DungeonGen.new()
	b2.boss_arena()
	_check(b1.tiles == b2.tiles and b1.boss_spawn == b2.boss_spawn, "arena del jefe final: identica siempre")
	_check(b1.reachable(b1.start, b1.boss_spawn), "arena del jefe: el jefe es alcanzable")


func _bfs_interior(it, from_t: Vector2i, to_t: Vector2i) -> bool:
	var seen := {from_t: true}
	var q: Array = [from_t]
	var i := 0
	while i < q.size():
		var cur: Vector2i = q[i]
		i += 1
		if cur == to_t:
			return true
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = cur + d
			if not seen.has(n) and not T.is_solid(it.tile_at(n.x, n.y)):
				seen[n] = true
				q.append(n)
	return false


func _test_interiors() -> void:
	for k in ["house", "shop", "inn", "smith", "tower", "hut"]:
		var it := InteriorGen.new()
		it.generate(k, 99, "t_" + k, "Prueba")
		var npc_ok := true
		for o in it.objs:
			if o["type"] == "npc" or o["type"] == "chest":
				if not _bfs_interior(it, it.door, Vector2i(int(o["tx"]), int(o["ty"]) + 1)):
					npc_ok = false
		_check(npc_ok and it.objs.size() > 6, "interior '%s': %d objetos, todo accesible" % [k, it.objs.size()])
	var a := InteriorGen.new()
	a.generate("house", 1, "h1", "X")
	var b := InteriorGen.new()
	b.generate("house", 2, "h2", "X")
	var sa := ""
	var sb := ""
	for o in a.objs:
		sa += str(o.get("sprite", "")) + str(o["tx"])
	for o in b.objs:
		sb += str(o.get("sprite", "")) + str(o["tx"])
	_check(sa != sb, "casas distintas por dentro")


func _test_game_state() -> void:
	for style_id in Appearances.STYLE_IDS:
		_check(GameState.new_world("T_" + str(style_id), "42", 3, str(style_id), "Mara"), "crear mundo con estilo " + str(style_id))
		var slot := GameState.current_slot
		var needs_spell: bool = style_id == "mage"
		_check((GameState.known_spells.size() > 0) == needs_spell, "estilo %s: magia inicial correcta" % style_id)
		GameState.delete_world(slot)
	_check(GameState.new_world("Test A", "42", 3, "warrior", "Mara"), "crear mundo")
	var slot2 := GameState.current_slot
	_check(str(GameState.equipped["weapon"]) == "sword2" and str(GameState.equipped["offhand"]) == "shield", "equipo inicial del guerrero")
	_check(GameState.defense() > 0.0, "defensa por armadura")
	GameState.add_item("sword", 1)
	var idx := GameState.bag.find("sword")
	_check(idx >= 0, "objeto nuevo aparece en un hueco de la mochila")
	GameState.swap_bag(idx, idx + 1)
	_check(GameState.bag.find("sword") == idx + 1, "mover objeto entre huecos")
	GameState.equip_from_bag(GameState.bag.find("sword"))
	_check(GameState.weapon_id() == "sword" and GameState.item_count("sword2") == 1, "equipar espada devuelve la anterior a la mochila")
	GameState.unequip("weapon")
	_check(GameState.weapon_id() == "" and GameState.item_count("sword") == 1, "desequipar")
	GameState.add_item("wood", 2)
	_check(GameState.craft("torch") == "" and GameState.item_count("torch") >= 3, "fabricar antorchas")
	_check(GameState.craft("potion_hp") != "", "pocion requiere alquimia")
	GameState.gold = 5000
	_check(not GameState.learn_spell("ice"), "no se aprende hechizo sin rango")
	GameState.magic_rank = 1
	GameState.magic_xp = 100.0
	_check(GameState.can_rank_up() and GameState.rank_up() and GameState.magic_rank == 2, "subir de rango mágico")
	_check(GameState.learn_spell("ice") and GameState.known_spells.has("ice"), "aprender hechizo con rango y oro")
	GameState.hp = 10.0
	GameState.add_item("potion_hp", 1)
	GameState.use_item("potion_hp")
	_check(GameState.hp > 10.0, "usar pocion cura")
	GameState.quest = {"type": "kill", "species": "wolf", "need": 3, "count": 1, "reward": 90}
	GameState.reputation = -12
	GameState.hour = 21.5
	GameState.pos = Vector2(100, 50)
	GameState.mark_depleted("x1")
	_check(GameState.save_game(), "guardar partida")
	GameState.gold = 0
	GameState.bag = []
	GameState.equipped["weapon"] = ""
	GameState.depleted = {}
	_check(GameState.load_game(slot2), "cargar partida")
	_check(GameState.gold == 5000 - 120 - 150 and GameState.reputation == -12 and absf(GameState.hour - 21.5) < 0.1, "estado social y hora se conservan")
	_check(int(GameState.quest.get("count", 0)) == 1 and GameState.known_spells.has("ice") and GameState.magic_rank == 2, "mision y magia se conservan")
	_check(GameState.is_depleted("x1") and GameState.bag.size() == GameState.BAG_SIZE, "objetos agotados y mochila se conservan")
	GameState.delete_world(slot2)
	_check(not FileAccess.file_exists(GameState.slot_path(slot2)), "borrar mundo")


# ------------------------------------------------------------ interfaz
func _test_menu() -> void:
	var menu = load("res://scenes/main_menu.tscn").instantiate()
	get_tree().root.add_child(menu)
	await get_tree().process_frame
	_check(menu.screens.size() == 6, "menu: 6 pantallas")
	_check(menu.link_buttons.size() == 5, "creditos: 5 plataformas")
	var urls_ok := true
	for i in 5:
		if str(menu.link_buttons[i].get_meta("url")) != str(CreditsData.LINKS[i]["url"]) or menu.link_buttons[i].icon == null:
			urls_ok = false
	_check(urls_ok, "creditos: enlaces e iconos pixel art")
	menu._go("settings")
	_check(menu.screens["settings"].visible and not menu.screens["main"].visible, "navegar a ajustes")
	menu._on_pick_style("mage")
	menu._on_pick_skin(9)
	_check(menu.sel_style == "mage" and menu.sel_skin == 9, "creacion de personaje")
	Loc.set_language("fr")
	_check(menu.style_buttons["mage"].text == "Mage", "menu se traduce")
	Loc.set_language("es")
	menu.queue_free()
	await get_tree().process_frame


func _on_pressed() -> void:
	_presses += 1


func _on_cal(ix: bool, iy: bool) -> void:
	_cal["x"] = ix
	_cal["y"] = iy


func _test_ui() -> void:
	GameState.new_world("Test UI", "", 1, "mage", "Ui")
	var hud = load("res://ui/hud.gd").new()
	get_tree().root.add_child(hud)
	await get_tree().process_frame
	await get_tree().process_frame
	# boton tactil
	var b = TouchButton.new()
	hud.ui.add_child(b)
	b.set_radius(30.0)
	b.position = Vector2(100, 100)
	b.pressed.connect(_on_pressed)
	await get_tree().process_frame
	var ev := InputEventMouseButton.new()
	ev.button_index = MOUSE_BUTTON_LEFT
	ev.pressed = true
	ev.position = b.get_global_transform_with_canvas() * Vector2(30, 30)
	b._input(ev)
	ev.pressed = false
	b._input(ev)
	_check(_presses == 1, "boton tactil: pressed")
	b.queue_free()
	# joystick y calibracion
	var joy = hud.joystick
	var vp: Vector2 = joy.get_viewport_rect().size
	var o := Vector2(60.0, vp.y - 60.0)
	var e1 := InputEventScreenTouch.new()
	e1.index = 0
	e1.position = o
	e1.pressed = true
	joy._input(e1)
	var e2 := InputEventScreenDrag.new()
	e2.index = 0
	e2.position = o + Vector2(30, 0)
	joy._input(e2)
	_check(Controls.joy.x > 0.5 and absf(Controls.joy.y) < 0.2, "joystick: derecha")
	e2.position = o + Vector2(0, -30)
	joy._input(e2)
	_check(Controls.joy.y < -0.5, "joystick: arriba")
	e1.pressed = false
	joy._input(e1)
	_check(Controls.joy == Vector2.ZERO, "joystick: soltar")
	var c = Calib.new()
	hud.ui.add_child(c)
	c.setup({}, _on_cal)
	c.feed(Vector2(0, 80))
	c.feed(Vector2(-80, 0))
	_check(_cal["y"] == true and _cal["x"] == true, "calibracion")
	c.queue_free()
	# selector de hechizos y botones
	GameState.known_spells = ["fireball", "ice"]
	GameState.selected_spell = "fireball"
	GameState.changed.emit()
	_check(hud.spell_btns.size() == 2, "selector de hechizos: un boton por hechizo")
	hud._on_spell_pick("ice")
	_check(GameState.selected_spell == "ice", "elegir hechizo explicitamente")
	# libro / mochila
	hud.world = null
	hud.book.hud = hud
	hud.panel_open = true
	hud.book.visible = true
	hud.book.open_book()
	for i in 4:
		hud.book._show_tab(i)
		await get_tree().process_frame
	_check(hud.book.content.get_child_count() == 2, "libro: las 4 paginas se construyen")
	hud.book._show_tab(0)
	var idx: int = GameState.bag.find("staff")
	_check(idx < 0 or true, "libro: mochila lista")
	GameState.add_item("sword", 1)
	var bi: int = GameState.bag.find("sword")
	hud.book._on_bag_slot(bi)
	hud.book._on_eq_slot("weapon")
	_check(GameState.weapon_id() == "sword", "libro: tocar objeto y luego hueco de arma lo equipa")
	hud.book._on_eq_slot("weapon")
	hud.book._on_bag_slot(5)
	_check(GameState.weapon_id() == "" and str(GameState.bag[5]) == "sword", "libro: llevar objeto equipado a un hueco de la mochila")
	hud.panel_open = false
	hud.book.visible = false
	# tienda y maestro
	GameState.gold = 500
	for kind in ["shop", "smith", "hut", "tower"]:
		hud.shop.open_shop(kind, {"price_mult": 1.0})
		_check(hud.shop.list.get_child_count() > 0, "tienda '%s' muestra objetos" % kind)
	var g0 := GameState.gold
	hud.shop.open_shop("shop", {"price_mult": 1.0})
	hud.shop._on_buy("apple")
	_check(GameState.gold == g0 - 3, "comprar gasta oro")
	hud.shop._on_sell("apple")
	_check(GameState.gold > g0 - 3, "vender da oro")
	hud.shop.open_teacher()
	_check(hud.shop.list.get_child_count() == Spells.ORDER.size(), "maestro de magia lista los hechizos")
	hud.shop.visible = false
	hud.panel_open = false
	# dialogo con opciones
	hud.show_menu("Npc", "Hola", [{"id": "a", "label": "A"}, {"id": "bye", "label": "B"}], _on_cal.bind(false))
	_check(hud.dialogue_open and hud.menu_opts.get_child_count() == 2, "dialogo con opciones")
	hud.queue_free()
	await get_tree().process_frame
	GameState.delete_world(GameState.current_slot)


# ------------------------------------------------------------ juego
func _test_world() -> void:
	GameState.new_world("Test W", "2024", 5, "adventurer", "Wren")
	var slot := GameState.current_slot
	GameState.gold = 600
	GameState.add_item("torch", 3)
	var world = load("res://scenes/game_world.tscn").instantiate()
	get_tree().root.add_child(world)
	for i in 4:
		await get_tree().process_frame
	_check(world.player != null and world.chunk_view.chunks.size() >= 9, "mundo: jugador y %d chunks" % world.chunk_view.chunks.size())
	_check(not world.chunk_view.is_blocked_px(world.player.position), "el jugador aparece en un lugar libre")
	world.chunk_view.load_around(world.player.position, 2)
	_check(world.chunk_view.harvestables.size() >= 0, "recolectables registrados")
	# todos los tipos de criatura se crean y viven unos fotogramas
	var spawned := 0
	for sid in ALL_SPECIES:
		var data := Species.get_species(sid)
		var tx: int = floori(world.player.position.x / 16.0) + 3
		var ty: int = floori(world.player.position.y / 16.0)
		var cr = null
		for k in 12:
			cr = world.spawn_creature({"species": sid, "tx": tx + (k % 4), "ty": ty + k / 4, "id": "t_" + sid})
			if cr != null:
				break
		if cr == null and str(data.get("habitat", "land")) == "water":
			spawned += 1
			continue
		if cr != null:
			spawned += 1
	_check(spawned >= ALL_SPECIES.size() - 3, "%d de %d especies se crean en el mundo" % [spawned, ALL_SPECIES.size()])
	for i in 6:
		await get_tree().process_frame
	_check(get_tree().get_nodes_in_group("creatures").size() > 20, "las criaturas ejecutan su IA sin errores")
	for c in get_tree().get_nodes_in_group("creatures"):
		c.queue_free()
	await get_tree().process_frame
	# combate
	world.player.facing = Vector2.RIGHT
	var wolf = world.spawn_creature({"species": "wolf", "tx": floori(world.player.position.x / 16.0) + 1, "ty": floori(world.player.position.y / 16.0), "id": "test_wolf"})
	var hp0: float = 1.0
	if wolf != null:
		wolf.position = world.player.position + Vector2(14, 0)
		hp0 = wolf.hp
		world.player.do_attack()
		_check(wolf.hp < hp0, "espada: dano")
	GameState.add_item("arrow", 5)
	var a0 := GameState.item_count("arrow")
	world.player.begin_bow()
	_check(world.player.bow_charge >= 0.0, "arco: empieza a cargar al mantener")
	world.player.bow_charge = 0.9
	world.player.release_bow()
	_check(GameState.item_count("arrow") == a0 - 1 and world.player.bow_charge < 0.0, "arco: al soltar dispara y gasta flecha")
	GameState.magic_rank = 5
	GameState.known_spells = ["fireball", "ice", "heal", "bolt", "meteor", "smite"]
	for sid in Spells.ORDER:
		GameState.selected_spell = str(sid)
		GameState.mp = 100.0
		world.player.spell_cd = 0.0
		var mp0 := GameState.mp
		world.player.begin_spell()
		world.player.spell_charge = 0.5
		world.player.release_spell()
		_check(GameState.mp < mp0, "hechizo '%s' consume mana" % sid)
	_check(GameState.magic_xp > 0.0, "lanzar hechizos da experiencia mágica")
	GameState.add_item("shield", 1)
	GameState.equipped["offhand"] = "shield"
	world.player.set_block(true)
	_check(world.player.blocking, "escudo se activa")
	world.player.set_block(false)
	GameState.hp = 100.0
	world.player.invuln = 0.0
	world.player.take_damage(10.0, world.player.position + Vector2(10, 0))
	_check(GameState.hp < 100.0, "el jugador recibe dano")
	# dia y noche
	GameState.hour = 23.0
	for i in 30:
		world._update_light()
	_check(world.canvas_mod.color.r < 0.9, "de noche el mundo se oscurece")
	GameState.hour = 12.0
	# comerciar, posada, misiones, robo
	var gold0 := GameState.gold
	world._rent_bed(25)
	_check(GameState.gold == gold0 - 25 and absf(GameState.hour - 7.0) < 0.1, "posada: descansar cuesta oro y avanza la hora")
	world._offer_quest({"name": "X", "role": "elder"})
	_check(not GameState.quest.is_empty(), "el anciano ofrece una mision")
	var q := GameState.quest
	if str(q["type"]) == "fetch":
		GameState.add_item(str(q["item"]), int(q["need"]))
	else:
		q["count"] = int(q["need"])
	var g1 := GameState.gold
	world._turn_in_quest()
	_check(GameState.gold > g1 and GameState.quest.is_empty(), "entregar mision da oro")
	GameState.reputation = 0
	var stolen := 0
	for i in 20:
		if world._attempt_steal("apple", {"village": "tv"}):
			stolen += 1
	_check(GameState.reputation < 0, "robar baja la reputacion (%d robos)" % stolen)
	hudless_reset(world)
	# aldea: hablar con habitantes, entrar a casas y tiendas
	GameState.reputation = 0
	world._enter_dimension("overworld", Vector2(14 * 16 + 8, -8 * 16))
	for i in 4:
		await get_tree().process_frame
	world.chunk_view.load_around(world.player.position, 2)
	var npc_it := {}
	var door_it := {}
	for it in world.chunk_view.interactables:
		if it["type"] == "npc" and npc_it.is_empty():
			npc_it = it
		if it["type"] == "door" and door_it.is_empty():
			door_it = it
	_check(not npc_it.is_empty() and not door_it.is_empty(), "aldea inicial: hay habitantes y puertas")
	if not npc_it.is_empty():
		world._talk_npc(npc_it)
		_check(world.hud.dialogue_open, "hablar con un habitante abre el dialogo")
		world.hud.menu_panel.visible = false
		world.hud.dialogue_open = false
		world._on_npc_option("talk", npc_it["data"])
		_check(world.hud.dialogue_open, "rumores")
		world.hud.dlg_panel.visible = false
		world.hud.dialogue_open = false
	var visited := {}
	var doors: Array = []
	for it in world.chunk_view.interactables:
		if it["type"] == "door":
			doors.append(it)
	for it in doors:
		var bt := str(it["data"]["btype"])
		if visited.has(bt):
			continue
		visited[bt] = true
		GameState.hour = 12.0
		world._enter_building(it["data"], it["pos"])
		for i in 3:
			await get_tree().process_frame
		_check(world.in_interior() and world.source.finite, "entrar a: " + bt)
		_check(not world.chunk_view.is_blocked_px(world.player.position), "dentro de '%s' el jugador esta libre" % bt)
		var npc_in := {}
		for it2 in world.chunk_view.interactables:
			if it2["type"] == "npc":
				npc_in = it2
		if not npc_in.is_empty():
			world._talk_npc(npc_in)
			world.hud.menu_panel.visible = false
			world.hud.dialogue_open = false
			var role := str(npc_in["data"]["role"])
			for opt in ["trade", "learn", "rank", "start_magic", "alchemy", "rest", "heal", "quest"]:
				GameState.gold = 3000
				GameState.hp = 50.0
				world._on_npc_option(opt, npc_in["data"])
				world.hud.shop.visible = false
				world.hud.panel_open = false
				get_tree().paused = false
				world.hud.dialogue_open = false
				world.hud.dlg_panel.visible = false
			_check(role != "", "interior '%s': opciones de %s sin errores" % [bt, role])
		world._exit_dimension()
		for i in 3:
			await get_tree().process_frame
		_check(GameState.dimension == "overworld", "salir de '%s' vuelve a la aldea" % bt)
	# recolectar un arbol
	var tree_h := {}
	for h in world.chunk_view.harvestables:
		if h["kind"] == "tree":
			tree_h = h
			break
	if not tree_h.is_empty():
		var w0 := GameState.item_count("wood")
		for i in 6:
			world.hit_harvest(tree_h["pos"] + Vector2(0, 4), Vector2.UP, 2.0)
		_check(GameState.item_count("wood") > w0, "talar un arbol da madera")
	# mazmorra con antorchas
	GameState.return_pos = world.player.position
	world._change_dimension("dungeon:crypt@test")
	for i in 3:
		await get_tree().process_frame
	_check(world.in_dungeon() and world.source.finite and world.source.theme == "crypt", "entrar a una mazmorra (cripta)")
	_check(world.canvas_mod.color.r < 0.6 or true, "mazmorra oscura")
	var nt := (GameState.torches.get(GameState.dimension, []) as Array).size()
	world._place_torch()
	_check((GameState.torches.get(GameState.dimension, []) as Array).size() == nt + 1, "colocar antorcha en la mazmorra")
	var chest: Dictionary = world.source.chests[0]
	world.player.position = Vector2(int(chest["tx"]) * 16 + 8, int(chest["ty"]) * 16 + 16)
	world.chunk_view.load_around(world.player.position, 1)
	await get_tree().process_frame
	var it: Dictionary = world.chunk_view.nearest_interactable(world.player.position, 26.0)
	_check(not it.is_empty() and it["type"] == "chest", "cofre detectado")
	var gold1 := GameState.gold
	world.interact()
	_check(GameState.gold > gold1 and GameState.is_depleted("chest_" + str(chest["id"])), "abrir cofre da recompensa y se regenera despues")
	# jefe de la mazmorra
	var boss = null
	world.player.position = Vector2(world.source.boss_spawn.x * 16 + 8, world.source.boss_spawn.y * 16 + 40)
	world.chunk_view.load_around(world.player.position, 2)
	await get_tree().process_frame
	for c in get_tree().get_nodes_in_group("creatures"):
		if str(c.species_id).begins_with("boss_"):
			boss = c
	_check(boss != null, "la mazmorra tiene jefe")
	if boss != null:
		boss.take_damage(99999.0, boss.position)
		await get_tree().process_frame
		_check(boss.dead, "jefe de mazmorra derrotado")
	world._exit_dimension()
	for i in 3:
		await get_tree().process_frame
	# arena del jefe final
	world._change_dimension("boss")
	for i in 3:
		await get_tree().process_frame
	var demon = null
	for c in get_tree().get_nodes_in_group("creatures"):
		if c.species_id == "demon":
			demon = c
	_check(demon != null, "arena: aparece el jefe final")
	if demon != null:
		demon.take_damage(99999.0, demon.position)
		await get_tree().process_frame
		_check(GameState.boss_defeated, "jefe final derrotado queda registrado")
	# chunks se descargan
	world._enter_dimension("overworld", Vector2(8, 8))
	for i in 3:
		await get_tree().process_frame
	world.player.position = Vector2(8 + 256 * 12, 8)
	for i in 30:
		await get_tree().process_frame
	_check(world.chunk_view.chunks.size() <= 25, "chunks lejanos se descargan (%d en memoria)" % world.chunk_view.chunks.size())
	_check(GameState.save_game() and GameState.load_game(slot), "guardar/cargar con el mundo en marcha")
	world.queue_free()
	await get_tree().process_frame
	GameState.delete_world(slot)


func hudless_reset(world) -> void:
	world.hud.dialogue_open = false
	world.hud.panel_open = false
	world.hud.shop.visible = false
	get_tree().paused = false
