extends RefCounted
## Datos de creditos. Los enlaces del creador son los proporcionados por el propio creador.
## "?" en autor o licencia = pendiente de confirmar (se muestra traducido). Solo se listan recursos incluidos.

const CREATOR := "Apricot634"

const LINKS := [
	{"name": "Instagram", "url": "https://instagram.com/apricot_634", "icon": "res://assets/ui/icon_instagram.png"},
	{"name": "Kick", "url": "https://kick.com/hjapri", "icon": "res://assets/ui/icon_kick.png"},
	{"name": "Twitch", "url": "https://m.twitch.tv/hj_apri/home", "icon": "res://assets/ui/icon_twitch.png"},
	{"name": "YouTube", "url": "https://www.youtube.com/@Apricot634", "icon": "res://assets/ui/icon_youtube.png"},
	{"name": "TikTok", "url": "https://tiktok.com/@apricot.634", "icon": "res://assets/ui/icon_tiktok.png"},
]

const THIRD_PARTY := [
	{"name": "Godot Engine", "author": "Godot Engine contributors", "license": "MIT"},
	{"name": "Interface Sounds", "author": "Kenney", "license": "CC0 1.0"},
	{"name": "Super Retro World - Character Pack", "author": "Gif (@gif_not_jif), Noiracide (@Noiracide), Romi (@DessRomaric)", "license": "Credit required"},
	{"name": "MiniFolks - Forest Animals", "author": "LYASeeK", "license": "Free use, no resale"},
	{"name": "PVFX Foundry (effects)", "author": "PVFX", "license": "CC0"},
	{"name": "Houses Pack", "author": "Szadi art", "license": "Free use, no resale of the pack"},
	{"name": "Tiny Creatures (monstruos y animales)", "author": "Clint Bellanger", "license": "CC0 1.0"},
	{"name": "Forest Monsters FREE", "author": "monopixelart", "license": "?"},
	{"name": "Free Top-Down Trees", "author": "Craftpix", "license": "?"},
	{"name": "Tiny RPG Character Asset Pack 02", "author": "?", "license": "?"},
	{"name": "16x16 RPG Item Pack", "author": "?", "license": "?"},
	{"name": "Harvest Sumer (trees)", "author": "?", "license": "?"},
]
