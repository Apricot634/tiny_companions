extends Node
## Estado de la partida: personaje, equipo, mochila, magia, reputacion, hora, misiones y guardado por mundos.
## Guardado atomico con copia .bak (SaveIO). Cada mundo guarda su semilla para regenerar el terreno igual.

signal changed

const SaveIO := preload("res://core/save_io.gd")
const Items := preload("res://data/items.gd")
const Appearances := preload("res://data/appearances.gd")
const Spells := preload("res://data/spells.gd")

const MAX_WORLDS := 8
const SAVE_VERSION := 3
const RESPAWN_SECONDS := 900.0
const START_POS := Vector2(8, 8)
const BAG_SIZE := 24
const DAY_SPEED := 0.02          # horas de juego por segundo real (un dia = 20 min)

var active := false
var current_slot := 0
var world_name := ""
var world_seed := 0
var player_name := "Heroe"
var appearance := 1
var style := "adventurer"
var hp := 100.0
var max_hp := 100.0
var mp := 30.0
var max_mp := 30.0
var hunger := 100.0
var gold := 0
var inventory := {}                  # objetos en la mochila (los equipados NO cuentan aqui)
var equipped := {"weapon": "", "offhand": "", "ranged": "", "head": "", "body": "", "feet": ""}
var bag: Array = []                  # orden de los huecos de la mochila
var known_spells: Array = []
var selected_spell := ""
var magic_rank := 0                  # 0 = sin magia, 1 Aprendiz ... 5 Santo
var magic_xp := 0.0
var reputation := 0
var wanted_until := 0.0
var hour := 8.0
var known_recipes: Array = ["torch", "arrow", "bread"]
var quest := {}
var quests_done := 0
var torches := {}                    # dimension -> [[x, y], ...]
var interior_ctx := {}
var shop_ban := {}                   # id de aldea -> game_time hasta el que no te atienden
var talk_counts := {}
var pos := START_POS
var dimension := "overworld"
var return_pos := START_POS
var depleted := {}
var boss_defeated := false
var play_seconds := 0.0
var game_time := 0.0
var _emit_t := 0.0
var _autosave_t := 0.0


func slot_path(slot: int, kind: String = "") -> String:
	return "user://wildmere_world_%d%s.json" % [slot, kind]


# ------------------------------------------------------------ creacion
func _free_slot() -> int:
	for s in range(1, MAX_WORLDS + 1):
		if not FileAccess.file_exists(slot_path(s)) and not FileAccess.file_exists(slot_path(s, ".bak")):
			return s
	return 0


func new_world(wname: String, seed_text: String, skin: int, style_id: String, pname: String) -> bool:
	var slot := _free_slot()
	if slot == 0:
		return false
	current_slot = slot
	randomize()
	var t := seed_text.strip_edges()
	if t == "":
		world_seed = randi() % 2000000000
	elif t.is_valid_int():
		world_seed = absi(int(t)) % 2000000000
	else:
		world_seed = absi(t.hash()) % 2000000000
	world_name = wname.strip_edges()
	if world_name == "":
		world_name = "Mundo %d" % slot
	player_name = pname.strip_edges()
	if player_name == "":
		player_name = "Heroe"
	appearance = skin
	style = style_id if Appearances.STYLES.has(style_id) else "adventurer"
	var st: Dictionary = Appearances.STYLES[style]
	max_hp = float(st["hp"])
	max_mp = float(st["mp"])
	hp = max_hp
	mp = max_mp
	hunger = 100.0
	gold = 20
	inventory = {}
	equipped = {"weapon": "", "offhand": "", "ranged": "", "head": "", "body": "", "feet": ""}
	var kit: Dictionary = st["items"]
	for k in kit.keys():
		inventory[k] = int(kit[k])
	var eq: Dictionary = st["equip"]
	for slot_name in eq.keys():
		var id := str(eq[slot_name])
		equipped[slot_name] = id
		inventory[id] = int(inventory.get(id, 1)) - 1
		if int(inventory[id]) <= 0:
			inventory.erase(id)
	bag = []
	_sync_bag()
	known_spells = []
	for sp in st["spells"]:
		known_spells.append(str(sp))
	selected_spell = str(known_spells[0]) if not known_spells.is_empty() else ""
	magic_rank = int(st["rank"])
	magic_xp = 0.0
	reputation = 0
	wanted_until = 0.0
	hour = 8.0
	known_recipes = ["torch", "arrow", "bread"]
	quest = {}
	quests_done = 0
	torches = {}
	interior_ctx = {}
	shop_ban = {}
	talk_counts = {}
	pos = START_POS
	return_pos = START_POS
	dimension = "overworld"
	depleted = {}
	boss_defeated = false
	play_seconds = 0.0
	game_time = 0.0
	active = true
	save_game()
	return true


# ------------------------------------------------------------ inventario y equipo
func owns(id: String) -> bool:
	if int(inventory.get(id, 0)) > 0:
		return true
	for s in equipped.keys():
		if str(equipped[s]) == id:
			return true
	return false


func has_item(id: String) -> bool:
	return owns(id)


func item_count(id: String) -> int:
	return int(inventory.get(id, 0))


func _sync_bag() -> void:
	while bag.size() < BAG_SIZE:
		bag.append("")
	for i in bag.size():
		var id := str(bag[i])
		if id != "" and int(inventory.get(id, 0)) <= 0:
			bag[i] = ""
	for id in inventory.keys():
		if int(inventory[id]) > 0 and not bag.has(id):
			var placed := false
			for i in bag.size():
				if str(bag[i]) == "":
					bag[i] = id
					placed = true
					break
			if not placed:
				bag.append(id)


func add_item(id: String, n: int = 1) -> void:
	inventory[id] = int(inventory.get(id, 0)) + n
	_sync_bag()
	changed.emit()


func remove_item(id: String, n: int = 1) -> bool:
	if int(inventory.get(id, 0)) >= n:
		inventory[id] = int(inventory[id]) - n
		if int(inventory[id]) <= 0:
			inventory.erase(id)
		_sync_bag()
		changed.emit()
		return true
	return false


func swap_bag(i: int, j: int) -> void:
	if i < 0 or j < 0 or i >= bag.size() or j >= bag.size():
		return
	var tmp = bag[i]
	bag[i] = bag[j]
	bag[j] = tmp
	changed.emit()


func equip_from_bag(i: int) -> String:
	var id := str(bag[i])
	var slot := Items.slot_of(id)
	if id == "" or slot == "" or int(inventory.get(id, 0)) <= 0:
		return ""
	var prev := str(equipped[slot])
	inventory[id] = int(inventory[id]) - 1
	if int(inventory[id]) <= 0:
		inventory.erase(id)
	equipped[slot] = id
	if prev != "":
		inventory[prev] = int(inventory.get(prev, 0)) + 1
	_sync_bag()
	changed.emit()
	return slot


func unequip(slot: String) -> void:
	var id := str(equipped.get(slot, ""))
	if id == "":
		return
	equipped[slot] = ""
	inventory[id] = int(inventory.get(id, 0)) + 1
	_sync_bag()
	changed.emit()


func weapon_id() -> String:
	return str(equipped["weapon"])


func defense() -> float:
	var d := 0.0
	for s in equipped.keys():
		var id := str(equipped[s])
		if id != "" and Items.ITEMS.has(id):
			d += float(Items.ITEMS[id].get("def", 0.0))
	return d


func spell_bonus() -> float:
	var b := 1.0
	for s in equipped.keys():
		var id := str(equipped[s])
		if id != "" and Items.ITEMS.has(id):
			b *= float(Items.ITEMS[id].get("spell_bonus", 1.0))
	return b


func speed_bonus() -> float:
	var b := 0.0
	for s in equipped.keys():
		var id := str(equipped[s])
		if id != "" and Items.ITEMS.has(id):
			b += float(Items.ITEMS[id].get("speed", 0.0))
	return b


func heal(amount: float) -> void:
	hp = minf(max_hp, hp + amount)
	changed.emit()


func spend(n: int) -> bool:
	if gold < n:
		return false
	gold -= n
	changed.emit()
	return true


## Usa un objeto de la mochila. Devuelve la clave de resultado ("" si no hay).
func use_item(id: String) -> String:
	if not Items.ITEMS.has(id) or int(inventory.get(id, 0)) <= 0:
		return ""
	var it: Dictionary = Items.ITEMS[id]
	if str(it["kind"]) == "consumable":
		remove_item(id, 1)
		if it.has("heal"):
			hp = minf(max_hp, hp + float(it["heal"]))
		if it.has("mana"):
			mp = minf(max_mp, mp + float(it["mana"]))
		if it.has("food"):
			hunger = minf(100.0, hunger + float(it["food"]))
		changed.emit()
		return "used"
	if str(it["kind"]) == "equip":
		var idx := bag.find(id)
		if idx >= 0:
			equip_from_bag(idx)
			return "equipped"
	return ""


## Fabrica un objeto si hay materiales. Devuelve "" si salio bien o la clave del problema.
func craft(recipe_id: String) -> String:
	if not Items.RECIPES.has(recipe_id):
		return "craft_missing"
	var r: Dictionary = Items.RECIPES[recipe_id]
	if r.has("needs_known") and not known_recipes.has(str(r["needs_known"])):
		return "needs_alchemy"
	var needs: Dictionary = r["needs"]
	for k in needs.keys():
		if int(inventory.get(k, 0)) < int(needs[k]):
			return "craft_missing"
	for k in needs.keys():
		remove_item(str(k), int(needs[k]))
	add_item(str(r["out"]), int(r["n"]))
	return ""


func sell_price(id: String) -> int:
	return maxi(1, int(float(Items.ITEMS[id]["price"]) * 0.4))


# ------------------------------------------------------------ magia
func add_magic_xp(x: float) -> void:
	if magic_rank > 0:
		magic_xp += x


func can_rank_up() -> bool:
	return magic_rank < 5 and magic_xp >= float(Spells.RANK_XP[magic_rank + 1])


func rank_up_cost() -> int:
	return int(Spells.RANK_GOLD[mini(5, magic_rank + 1)])


func rank_up() -> bool:
	if not can_rank_up() or not spend(rank_up_cost()):
		return false
	magic_rank += 1
	changed.emit()
	return true


func learn_spell(id: String) -> bool:
	if known_spells.has(id) or magic_rank < int(Spells.SPELLS[id]["rank"]):
		return false
	if not spend(int(Spells.SPELLS[id]["learn"])):
		return false
	known_spells.append(id)
	if selected_spell == "":
		selected_spell = id
	changed.emit()
	return true


# ------------------------------------------------------------ mundo social
func change_rep(d: int) -> void:
	reputation = clampi(reputation + d, -100, 100)


func is_wanted() -> bool:
	return game_time < wanted_until


func is_night() -> bool:
	return hour >= 20.0 or hour < 5.5


func is_depleted(id: String) -> bool:
	if not depleted.has(id):
		return false
	if game_time - float(depleted[id]) > RESPAWN_SECONDS:
		depleted.erase(id)
		return false
	return true


func mark_depleted(id: String) -> void:
	depleted[id] = game_time


func clock_text() -> String:
	return "%02d:%02d" % [int(hour), int((hour - floor(hour)) * 60.0)]


# ------------------------------------------------------------ bucle
func _process(delta: float) -> void:
	if not active:
		return
	play_seconds += delta
	game_time += delta
	hour = fposmod(hour + delta * DAY_SPEED, 24.0)
	hunger = maxf(0.0, hunger - 0.04 * delta)
	mp = minf(max_mp, mp + 1.6 * delta)
	if hunger <= 0.0:
		hp = maxf(1.0, hp - 0.6 * delta)
	elif hunger > 50.0 and hp > 0.0:
		hp = minf(max_hp, hp + 0.35 * delta)
	_emit_t += delta
	if _emit_t >= 0.25:
		_emit_t = 0.0
		changed.emit()
	_autosave_t += delta
	if _autosave_t >= 45.0:
		_autosave_t = 0.0
		save_game()


# ------------------------------------------------------------ guardado
func to_dict() -> Dictionary:
	return {
		"version": SAVE_VERSION, "saved_unix": Time.get_unix_time_from_system(),
		"world_name": world_name, "seed": world_seed, "player_name": player_name,
		"appearance": appearance, "style": style, "hp": hp, "max_hp": max_hp, "mp": mp, "max_mp": max_mp,
		"hunger": hunger, "gold": gold, "inventory": inventory, "equipped": equipped, "bag": bag,
		"known_spells": known_spells, "selected_spell": selected_spell, "magic_rank": magic_rank, "magic_xp": magic_xp,
		"reputation": reputation, "wanted_until": wanted_until, "hour": hour, "known_recipes": known_recipes,
		"quest": quest, "quests_done": quests_done, "torches": torches, "interior_ctx": interior_ctx,
		"shop_ban": shop_ban, "talk_counts": talk_counts, "pos": [pos.x, pos.y],
		"return_pos": [return_pos.x, return_pos.y], "dimension": dimension, "depleted": depleted,
		"boss_defeated": boss_defeated, "play_seconds": play_seconds, "game_time": game_time,
	}


func _read_slot(slot: int) -> Dictionary:
	var d := SaveIO.read_json_safe(slot_path(slot))
	if d.has("seed") and d.has("appearance"):
		return d
	return {}


func list_worlds() -> Array:
	var out: Array = []
	for s in range(1, MAX_WORLDS + 1):
		var d := _read_slot(s)
		if d.is_empty():
			continue
		out.append({"slot": s, "name": str(d.get("world_name", "Mundo %d" % s)),
			"player": str(d.get("player_name", "?")), "style": str(d.get("style", "adventurer")),
			"skin": int(d.get("appearance", 1)), "play_seconds": float(d.get("play_seconds", 0.0))})
	return out


func has_save() -> bool:
	return not list_worlds().is_empty()


func save_game() -> bool:
	if not active or current_slot <= 0:
		return false
	return SaveIO.write_json_atomic(slot_path(current_slot), to_dict())


func _vec(a, fallback: Vector2) -> Vector2:
	if a is Array and a.size() >= 2:
		return Vector2(float(a[0]), float(a[1]))
	return fallback


func load_game(slot: int) -> bool:
	var d := _read_slot(slot)
	if d.is_empty():
		return false
	current_slot = slot
	world_name = str(d.get("world_name", "Mundo"))
	world_seed = int(d["seed"])
	player_name = str(d.get("player_name", "Heroe"))
	appearance = int(d["appearance"])
	style = str(d.get("style", "adventurer"))
	if not Appearances.STYLES.has(style):
		style = "adventurer"
	max_hp = float(d.get("max_hp", 100.0))
	max_mp = float(d.get("max_mp", 30.0))
	hp = clampf(float(d.get("hp", max_hp)), 1.0, max_hp)
	mp = clampf(float(d.get("mp", max_mp)), 0.0, max_mp)
	hunger = clampf(float(d.get("hunger", 100.0)), 0.0, 100.0)
	gold = int(d.get("gold", 0))
	inventory = {}
	var inv: Dictionary = d.get("inventory", {})
	for k in inv.keys():
		if Items.ITEMS.has(str(k)) and int(inv[k]) > 0:
			inventory[str(k)] = int(inv[k])
	equipped = {"weapon": "", "offhand": "", "ranged": "", "head": "", "body": "", "feet": ""}
	var eq: Dictionary = d.get("equipped", {})
	for k in eq.keys():
		if equipped.has(str(k)) and Items.ITEMS.has(str(eq[k])):
			equipped[str(k)] = str(eq[k])
	if not d.has("equipped"):
		_migrate_equipment(d)
	bag = []
	for b in d.get("bag", []):
		bag.append(str(b))
	_sync_bag()
	known_spells = []
	for s in d.get("known_spells", d.get("spells", [])):
		if Spells.SPELLS.has(str(s)):
			known_spells.append(str(s))
	selected_spell = str(d.get("selected_spell", ""))
	if not known_spells.has(selected_spell):
		selected_spell = str(known_spells[0]) if not known_spells.is_empty() else ""
	magic_rank = int(d.get("magic_rank", 1 if not known_spells.is_empty() else 0))
	magic_xp = float(d.get("magic_xp", 0.0))
	reputation = int(d.get("reputation", 0))
	wanted_until = float(d.get("wanted_until", 0.0))
	hour = float(d.get("hour", 8.0))
	known_recipes = []
	for r in d.get("known_recipes", ["torch", "arrow", "bread"]):
		known_recipes.append(str(r))
	quest = d.get("quest", {})
	quests_done = int(d.get("quests_done", 0))
	torches = d.get("torches", {})
	interior_ctx = d.get("interior_ctx", {})
	shop_ban = d.get("shop_ban", {})
	talk_counts = d.get("talk_counts", {})
	pos = _vec(d.get("pos"), START_POS)
	return_pos = _vec(d.get("return_pos"), START_POS)
	dimension = str(d.get("dimension", "overworld"))
	depleted = d.get("depleted", {})
	boss_defeated = bool(d.get("boss_defeated", false))
	play_seconds = float(d.get("play_seconds", 0.0))
	game_time = float(d.get("game_time", 0.0))
	active = true
	return true


## Guardados antiguos (v2): equipa lo que habia.
func _migrate_equipment(d: Dictionary) -> void:
	var w := str(d.get("weapon", ""))
	if w != "" and int(inventory.get(w, 0)) > 0 and Items.ITEMS.has(w):
		equipped["weapon"] = w
		inventory[w] = int(inventory[w]) - 1
		if int(inventory[w]) <= 0:
			inventory.erase(w)
	for id in ["bow", "shield"]:
		if int(inventory.get(id, 0)) > 0:
			equipped[Items.slot_of(id)] = id
			inventory[id] = int(inventory[id]) - 1
			if int(inventory[id]) <= 0:
				inventory.erase(id)


func delete_world(slot: int) -> void:
	for path in [slot_path(slot), slot_path(slot, ".bak"), slot_path(slot, ".tmp")]:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	if current_slot == slot:
		active = false


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if active:
			save_game()
