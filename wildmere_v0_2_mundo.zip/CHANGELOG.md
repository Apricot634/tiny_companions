
## Wildmere 0.2.0 (sin ejecutar en Godot por quien lo escribio)
- Mochila en forma de libro (4 paginas): equipo con muneco y huecos, mochila de 24 huecos movible, magia y rango, fabricacion, mapa y diario.
- Arco y hechizos se cargan manteniendo el boton; el hechizo se elige explicitamente (ya no cambia solo).
- Rangos de magia 1-5 (Aprendiz a Santo), 6 hechizos, maestros de magia que cobran oro; solo el mago empieza con magia.
- Aldeas con 5 disenos (cruce, plaza, calle, fortaleza, granja), nombres propios, 5 a 12 habitantes con nombre y dialogos cambiantes.
- Entrar a casas, tiendas, posadas, herrerias, torres de magia y cabanas: interiores distintos. Comprar, vender, robar, alquilar cama.
- Reputacion, busqueda y guardias; mision generica (derrotar o traer) con recompensa.
- Dia y noche; luces; mazmorras oscuras de 96x96 con 9 temas, jefes propios, cofres que se regeneran y antorchas colocables.
- Talar arboles y picar rocas; fabricar antorchas, flechas, pan y pociones.
- Mas de 60 especies (tiny creatures, humanos, bandidos, ladrones, jefes), IA que rodea obstaculos, ataques a distancia/carga/explosivos.
- Agua poco profunda transitable, montanas con senderos y cimas, biomas nuevos (nieve, pantano, pradera), arboles por bioma.
- Cinematica de jefe, emboscadas en arbustos, nombre de region al entrar a una zona.
