# Revision de licencias de assets (Etapa 0)

Alcance actual: **uso personal**. No hay lanzamiento, distribucion publica ni monetizacion.

## Condicion para el futuro (indicada por el creador)
Si el juego se publica, se distribuye publicamente o se monetiza, **todos los recursos de terceros se
sustituyen por assets originales** generados para el proyecto, con la misma direccion artistica y coherencia visual.
Hasta entonces se pueden usar los recursos existentes respetando sus licencias.

## Estado por paquete
Fuentes: archivo de licencia dentro del ZIP (ZIP) y pagina oficial del autor consultada el 2026-11-07 (WEB).

| Paquete | Autor / origen | Condiciones | Fuente | Atribucion |
|---|---|---|---|---|
| Kenney Interface Sounds | Kenney | CC0 | ZIP | Opcional (incluida) |
| Tiny Creatures | Clint Bellanger | CC0 | ZIP | Opcional |
| PVFX Foundry (13 hojas, 101 efectos) | PVFX | CC0 para hojas y manifiestos | ZIP | Opcional |
| SuperRetroWorld Character Pack | 3 autores (ver su LICENSE) | Uso comercial permitido; prohibe redistribuir assets, NFT e IA | ZIP | **Obligatoria** a los tres autores |
| Seeker Lite | Primitive Pixels | Uso en juegos; no revender ni redistribuir; no entrenar modelos | ZIP | Segun su LICENSE |
| Houses Pack | Szadi art | Editar y usar en juegos; no vender el pack | ZIP | Apreciada |
| MiniFolks Forest Animals | LYASeeK (lyaseek.itch.io) | "Usalo como quieras, no lo revendas"; credito no requerido pero apreciado; el autor confirma uso comercial y no comercial | WEB | Recomendada |
| SATYR sprite sheet ("Free character - Satyr") | LuckyLoops (lucky-loops.itch.io) | Pagina indica CC BY 4.0 | WEB | **Obligatoria** (CC BY) |
| PixelSpaces Free Pack (lote 1) | Netherzapdos | **Solo no comercial**; no redistribuir | ZIP | Segun su readme |

## Pendientes de verificar (no se usan en el juego nuevo hasta confirmarlos)
- **Forest Monsters FREE** (monopixelart.itch.io): la pagina no muestra texto de licencia en lo consultado.
- **Pixel Art Top Down - Basic**: sin licencia en el ZIP; una lista de terceros lo clasifica como gratuito, pero eso no basta.
- **Pixel Holy Spell Effect 32x32**, **Top-Down Retro Interior**, **16x16 RPG Item Pack**, **Tiny RPG Character 02**, **FreeButtons.png**: sin licencia en el ZIP; no se localizo su pagina con certeza.
- **Controllers and Keyboard** (Vryell): el texto sugiere pack de pago; sin licencia incluida.
- **Craftpix** (arboles cenitales, UI RPG): el ZIP remite a la pagina de licencias de Craftpix, que no se pudo consultar.
- Lote 1: Tiny Wonder Farm y Harvest Sumer: sin licencia verificada.

Nota: el creador indica que algunos paquetes vienen de la biblioteca de assets de Godot y otros de Lyaseek (itch.io).
Para cerrar cada pendiente basta indicar de cual de los dos viene o abrir su pagina original.

## Reglas de trabajo
1. Un recurso entra al juego nuevo solo con su fila en `PROVENANCE.csv` (origen, autor, licencia, uso).
2. Los creditos del juego se actualizan en `game/core/credits_data.gd` con cada recurso incorporado.
3. Los assets del prototipo anterior viven en `archive/` y no forman parte del juego nuevo por defecto.

## Recursos incluidos en game/ (v0.1) - uso local de prueba
Ver `game/assets/_docs/PROVENANCE.csv` (una fila por archivo). Pendientes de confirmar y aun incluidos solo para pruebas locales:
Forest Monsters FREE, Tiny RPG Character Asset Pack 02, 16x16 RPG Item Pack y Harvest Sumer (arboles).
Arte original generado por codigo (terreno, props, logo, iconos de redes, cueva, portal): propio del proyecto.
