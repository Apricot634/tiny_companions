# Etapas

## Hecho
Etapa 0 (base) y v0.1 jugable.

## v0.2 (esta entrega) - "mundo vivo"
Ver CHANGELOG. Pendiente de verificacion en Godot (prueba automatica en GitHub + prueba en telefono).

## Siguiente
- Registros persistentes de criaturas y simulacion fuera de zona.
- Montañas con niveles de altura reales, barcos/puentes, pesca, domesticar criaturas.
- Mas misiones encadenadas y lore, musica, equipo visible por capas, vista lateral.
