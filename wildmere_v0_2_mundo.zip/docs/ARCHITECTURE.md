# Arquitectura (v0.1 jugable)

```
game/
├─ core/      settings, loc (es/en/fr), audio (por eventos), controls, save_io, game_state, credits_data
├─ data/      tiles, species, items, spells, appearances, fx_data (todo el contenido es DATOS)
├─ world/     terrain (mundo abierto), dungeon_gen (cuevas + arena fija del jefe), chunk_view (carga/descarga), game_world (escena)
├─ entities/  player, creature (IA), npc, projectile, fx_sprite
├─ ui/        main_menu, boot, hud, touch_button (multitoque), virtual_joystick, joystick_calibration, wild_theme
├─ tests/     autotest (se ejecuta en GitHub Actions)
└─ assets/    tiles, characters, creatures, fx, items, props, houses, ui, audio (+ _docs/PROVENANCE.csv)
```

## Mundo y chunks
- Semilla -> ruido (altura, humedad, temperatura, rios) -> bioma por tile. Misma semilla = mismo mundo.
- Chunk = 16x16 tiles (256 px) dibujado como UNA textura; objetos y criaturas se crean al cargar el chunk y se liberan al descargarlo.
- Radio de carga 2 (25 chunks), descarga a mas de 3. Se carga como maximo un chunk por fotograma.
- Aldeas y cuevas: una por celda de 48x48 tiles segun hash de la semilla (+ una aldea y una cueva fijas cerca del inicio).
- Puerta del jefe final: a 80+ tiles del inicio, en una direccion distinta por mundo. La ARENA del jefe es identica en todos.
- Cuevas: mazmorra procedural por semilla (salas + pasillos, cofres, enemigos, mini jefe a veces).
- Colision por tiles (sin fisica): terreno solido + tiles bloqueados por objetos.

## Pendiente respecto a la propuesta tecnica
- Registros persistentes de criaturas y simulacion fuera de zona (hoy las criaturas se regeneran al volver al chunk; las derrotadas quedan registradas 15 min de juego).
- Guardado de diferencias por chunk (hoy solo cofres, arbustos y criaturas derrotadas).
- Alquimia, fabricacion, personalizacion por capas de equipo, vista lateral, misiones mas alla de la primera.
