# Wildmere (nombre provisional)

RPG 2D pixel art de mundo abierto en Godot 4.3. Proyecto de uso personal por ahora.

- `game/` el juego (v0.1 jugable) · `archive/` prototipo anterior (v0.2 intacto y v0.2.1 con calibracion) · `docs/`

## Controles
- Movil: joystick a la izquierda; a la derecha ataque (espada), arco, hechizo, escudo (mantener), esquiva, ciclo de hechizo y "Usar".
- PC: WASD/flechas mover · J o Espacio atacar · K arco · L hechizo · Q cambiar hechizo · Mayus escudo · Ctrl esquiva · E usar · I mochila · Esc pausa.

## Compilar sin computadora
1. Sube el archivo `wildmere_v0_1_jugable.zip` a la raiz del repositorio (si hay varios wildmere*.zip se usa el de nombre mayor).
2. Actions > "Build Wildmere". En **Artifacts**: `Wildmere-Android-APK`, `Prototipo-0.2.1-Android-APK` y `Wildmere-Windows`.
3. El **Summary** de la ejecucion muestra el resultado de la prueba automatica.
